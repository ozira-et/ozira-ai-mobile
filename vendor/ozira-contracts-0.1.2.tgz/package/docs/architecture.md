# ozira-contracts — architecture

Phase 1 of the OZIRA AI Operating Platform migration (see the read-only
Architecture Discovery & Change Assessment this package follows up on).
Status: **implemented, not yet wired into any live request path.**

## 1. Purpose

`packages/ozira-contracts` is the canonical home for the shared, versioned,
runtime-validated shapes that every OZIRA product experience (Chat, Code,
Cowork, Design, Forward), the P intelligence layer, and future connectors/
MCP tools/workers/audit/notifications will eventually speak.

It exists so that when Phase 2+ extracts the durable-queue/policy/worker
primitives that OZIRA Code's execution control plane already proves out
(`request -> policy -> authority -> approval -> durable queue -> worker ->
authoritative result -> audit`), every consumer of that runtime agrees on one
vocabulary instead of each product inventing its own request/result/approval
shape.

**This package contains only pure functions.** No infrastructure, no
database client, no network calls, no provider SDK, no secrets. It is safe
for the server, workers, product modules, and a future P runtime to all
depend on it without pulling in anything else.

## 2. Contracts

| Contract | File | Purpose |
|---|---|---|
| `Principal` | `src/principal.js` | Canonical identity/security context. Never carries auth material — enforced by a strict field allowlist. |
| `EventEnvelope` | `src/event.js` | Future cross-product event shape. No event bus exists yet. |
| `ActionRequest` | `src/action.js` | Generalizes "run a command" to "perform an authorized action." The most important Phase 1 contract. |
| `ActionResult` | `src/action.js` | Normalized result status (`PENDING`/`RUNNING`/`SUCCEEDED`/`FAILED`/`CANCELLED`/`TIMED_OUT`/`DENIED`) — a projection, not a replacement, of a product's richer internal lifecycle. |
| `AuthorityDecision` | `src/action.js` | Result of policy/authority evaluation (`ALLOW`/`REQUIRE_APPROVAL`/`DENY`). |
| `ApprovalRequest` | `src/approval.js` | Canonical human-approval request. Designed to represent both Code's `execution.*` approvals and the phase0 `store.approvals` table without migrating either. |
| `ToolInvocation` / `ToolResult` | `src/tool.js` | Provider-neutral MCP/tool capability call. `ToolResult.output` is untrusted content by default. |
| `ConnectorExecution` | `src/connector.js` | Tracking contract for trusted external connector side effects. No provider-specific fields, no OAuth tokens — contract only, no runtime. |
| `AuditEvent` | `src/audit.js` | One shared audit envelope for execution/action/connector/approval audit to eventually converge on. |
| `Notification` | `src/notification.js` | Delivery-channel-neutral notification (not Telegram/email/push specific). |
| `PAgentIntent` / `PAgentResponse` | `src/p2p.js` | Minimum-necessary-disclosure P-to-P negotiation envelopes. See §5. |

Every contract is exposed through `src/index.js` as `validate<Name>(input)`,
which returns a frozen, normalized object or throws `ContractError` (with
`.code` and `.field`).

## 3. Ownership

| Contract | Owner |
|---|---|
| `Principal`, `EventEnvelope`, `AuditEvent`, `Notification` | Shared platform |
| `ActionRequest`, `ActionResult`, `AuthorityDecision`, `ApprovalRequest` | Shared platform (agent action runtime) |
| `ToolInvocation`, `ToolResult` | Shared platform (MCP/tool gateway) |
| `ConnectorExecution` | Shared platform (connector broker) — **contract only in Phase 1**, no broker exists |
| `PAgentIntent`, `PAgentResponse` | P / Intelligence |

## 4. Trust rules

```
TRUSTED            authenticated owner instruction; validated platform state
CONDITIONALLY       internal service output (e.g. sandbox result); provider API result
  TRUSTED
UNTRUSTED           webpages, documents, emails, tool/MCP output, other-P intents,
                    sandbox output, arbitrary external metadata
```

**Untrusted content is data, never instructions.** Validating a contract
proves its *envelope* is well-formed and secret-free. It never proves the
*content* of a `payload`/`input`/`output`/`metadata` field is safe to act on.
`ActionRequest.payload`, `ToolInvocation.input`, `ToolResult.output`, and
`EventEnvelope.payload` are explicitly documented as such in their source
files. Only the module authorized for a specific `actionType`/`toolId` may
interpret that content, and only after policy/authority evaluation — never
before, and never in place of it.

**Secret-safety guard.** Every object-shaped field (`payload`, `input`,
`output`, `metadata`, `resultMetadata`) is walked recursively and rejects:
exact-match forbidden key names (`accessToken`, `refreshToken`,
`clientSecret`, `privateKey`, `password`, `apiKey`, `token`, `secret`,
`credential`, ...) and string values shaped like known secret material
(`sk-...`, `gh?_...`, `AKIA...`, PEM private keys, JWTs, `Bearer ...`,
credentials embedded in a URL). A *reference* field such as
`credentialRef` normalizes to a name that is **not** on the forbidden list
and is allowed through by design — this is the same `credential_ref`
boundary already validated in the P PoC (`p_connector_accounts`). See
`src/validation.js`.

**P-to-P minimum disclosure** (`src/p2p.js`) goes further: `payload` is
restricted to a shallow, bounded set of primitive values (≤8 keys, no
nested objects/arrays, bounded string length). This is a **structural**
minimum, not a semantic privacy system — it prevents smuggling raw context
(a calendar event, a memory blob) as "just a field," but an explicit
allowlist of permitted `(intentType -> payload keys)` pairs and a
recipient-side policy gate remain Phase 2+ work.

## 5. Versioning

Every contract carries `schemaVersion: 1` (a number, not a string).
Validators reject any other value with `SCHEMA_VERSION_UNSUPPORTED` rather
than attempting to coerce or silently accept it. Unknown top-level fields are
rejected (`FIELD_UNSUPPORTED`) rather than silently dropped — this makes a
caller's mistake visible immediately instead of producing a contract that
quietly lost data.

When a `v2` of a contract is needed: add a new validator (e.g.
`validateActionRequestV2`) rather than mutating the existing one in place,
and have callers opt in. `schemaVersion` inside the object is redundant with
the function name in this scheme, but is kept because a raw JSON payload
(e.g. logged, or received over a future wire protocol) needs to
self-describe its version without out-of-band context.

## 6. How Code currently adapts (Phase 1)

`lib/executioncontracts.js` is a new, standalone, **read-only/projection-only**
adapter module. It is not called from any live request path in
`lib/executiongateway.js`, `lib/executionrepository.js`, or
`lib/executionworker.js` — none of those files were modified. It proves Code
*can* produce/consume the contracts without forcing Code to change its
internal representation:

- `executionToActionRequest(execution)` — maps a Code execution row to `ActionRequest`.
- `executionToActionResult(execution)` — maps execution status/result/error to `ActionResult`.
- `approvalToApprovalRequest(approval, execution)` — maps a Code approval row to `ApprovalRequest`.
- `auditToAuditEvent(audit)` — maps a Code audit row (both the in-memory
  `actor`/`timestamp` shape and the durable `actorId`/`createdAt` shape) to
  `AuditEvent`.

Two deliberate, documented, **lossy projections** live in this adapter, not
in the contracts themselves:

- `authorityForExecution(execution)` — Code's internal risk model is
  green/yellow/red (see `packages/ozira-code/src/policyEngine.js`), not
  P's `OBSERVE..DECIDE` scale. Every Code execution kind performs a real
  action, so the projection is `deploy -> DECIDE`, everything else ->
  `EXECUTE`. This is *not* proof Code already reasons in P's authority
  terms — it is the adapter's best-effort, documented mapping.
- `auditOutcomeFor(outcome)` — collapses Code's richer audit outcomes
  (`queued`, `retry`, `idempotent`, ...) into the contract's four
  normalized buckets (`SUCCESS`/`FAILURE`/`DENIED`/`PENDING`). Code's own
  `store.audit_events` / `execution.*` audit rows keep their original,
  unmodified outcome — this mapping is for shared, normalized reporting only.

`test/executioncontracts.test.js` (repo root) exercises the adapter against
fixtures shaped exactly like real Code execution/approval/audit rows,
including both the in-memory and durable-projected shapes.

## 7. What remains for Phase 2

- Extract the actual policy/queue/worker primitives behind these contracts
  (this phase only defines the shapes).
- Wire `lib/executioncontracts.js` (or its successor) into a real call path,
  once Phase 2 decides where the boundary should live.
- Build the P runtime that produces/consumes `PAgentIntent`/`PAgentResponse`
  and `ActionRequest` for real (still simulated only in the Lakebase PoC
  today).
- Design the explicit allowlist / purpose-specific validators for P-to-P
  payloads that `src/p2p.js` deliberately defers.
- Decide the real service boundary for a connector broker before
  `ConnectorExecution` gets a runtime.

## 8. Connector vs. sandbox — security domain separation

`ConnectorExecution` describes **trusted connector side effects** (Calendar,
Email, Drive, Slack, ...) executed on the user's behalf through a future
credential broker. It is a different security domain from
`services/execution-runner`, which executes **untrusted code** in OCI/Docker
isolation for OZIRA Code.

They may eventually share control-plane *concepts* — contracts, queue
semantics, leases, retries, idempotency, audit conventions, policy
abstractions. They must **never** share:

- credential exposure (a sandbox process must never see a connector's OAuth material),
- execution trust (a sandbox result is not an authoritative connector result),
- runtime/security domain (one runtime must not execute the other's workload).

No connector runtime, credential broker, or provider call exists anywhere in
this repository as of Phase 1. `ConnectorExecution` is a contract only.
