'use strict';

// HQ-0 contracts — OZIRA HQ Intelligence (the company-operating-system
// layer). These are additive to the Phase 1 contract catalog, not a
// replacement: HQ reuses ActionRequest/ActionResult/AuthorityDecision/
// ApprovalRequest/AuditEvent exactly as Code and P do (see hqActionAdapter.js
// / hqResultAdapter.js / hqAuditAdapter.js in packages/ozira-hq-runtime).
// The eight shapes below exist only for the company-intelligence-specific
// data those generic contracts don't have a place for: signals, metrics,
// risks, opportunities, recommendations, decision cards, briefs, and
// per-department snapshots.
//
// Every one of these contracts carries `contextScope` (see HQ_CONTEXT_SCOPES
// in enums.js) — the explicit personal/company/financial/security/customer
// classification every piece of HQ-visible data must declare, so a caller
// can enforce the PERSONAL-memory boundary (§41/§65 of the HQ-0 program)
// without re-deriving it from department or content.
//
// Same rules as every other contract in this package: pure validation only,
// no infrastructure, no side effects, and the shared secret-safety guard
// (assertNoSecretFields, via requirePlainObject) applies to every object
// field here exactly as it does everywhere else.

const {
  requireString, optionalString, requireEnum, optionalEnum, requireTimestamp, optionalTimestamp,
  requirePlainObject, optionalPlainObject, requireBoolean, requireArray,
  onlyKeys, freezeResult, contractError, ID_PATTERN,
} = require('./validation');
const {
  AUTHORITY_LEVELS, HQ_DEPARTMENTS, HQ_CONTEXT_SCOPES, HQ_SEVERITY_LEVELS,
  HQ_SIGNAL_CATEGORIES, HQ_DECISION_STATUSES, HQ_DEPARTMENT_STATUSES,
} = require('./enums');

// -------------------------------------------------------------------------
// Local primitives (kept local to this file — no other contract needs a
// bounded number or a bounded string array yet; see validation.js's own
// header note that shared primitives live there once more than one
// contract needs them).
// -------------------------------------------------------------------------

function requireNumber(value, field, options) {
  options ||= {};
  if (typeof value !== 'number' || !Number.isFinite(value)) {
    throw contractError(field + ' must be a finite number.', 'FIELD_INVALID', field);
  }
  if (options.min != null && value < options.min) throw contractError(field + ' must be >= ' + options.min + '.', 'FIELD_INVALID', field);
  if (options.max != null && value > options.max) throw contractError(field + ' must be <= ' + options.max + '.', 'FIELD_INVALID', field);
  return value;
}

function optionalNumber(value, field, options) {
  if (value === undefined || value === null) return undefined;
  return requireNumber(value, field, options);
}

function stringArray(value, field, options) {
  options ||= {};
  const max = options.max || 20;
  const itemMax = options.itemMax || 300;
  const array = requireArray(value, field, { max });
  return array.map((item, index) => requireString(item, field + '[' + index + ']', { min: 1, max: itemMax }));
}

function optionalStringArray(value, field, options) {
  if (value === undefined || value === null) return undefined;
  return stringArray(value, field, options);
}

const CONFIDENCE_OPTS = { min: 0, max: 1 };

// -------------------------------------------------------------------------
// HQSignal
// -------------------------------------------------------------------------

const SIGNAL_FIELDS = new Set([
  'schemaVersion', 'signalId', 'department', 'category', 'severity', 'title',
  'summary', 'evidenceRefs', 'contextScope', 'detectedAt',
]);

function validateHQSignal(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw contractError('HQSignal is required and must be an object.', 'FIELD_REQUIRED', 'hqSignal');
  }
  onlyKeys(input, SIGNAL_FIELDS, 'hqSignal');
  const schemaVersion = input.schemaVersion == null ? 1 : input.schemaVersion;
  if (schemaVersion !== 1) throw contractError('Unsupported HQSignal schemaVersion.', 'SCHEMA_VERSION_UNSUPPORTED', 'hqSignal.schemaVersion');

  const signalId = requireString(input.signalId, 'hqSignal.signalId', { min: 6, max: 200, pattern: ID_PATTERN });
  const department = requireEnum(input.department, 'hqSignal.department', HQ_DEPARTMENTS);
  const category = requireEnum(input.category, 'hqSignal.category', HQ_SIGNAL_CATEGORIES);
  const severity = requireEnum(input.severity, 'hqSignal.severity', HQ_SEVERITY_LEVELS);
  const title = requireString(input.title, 'hqSignal.title', { min: 1, max: 200 });
  const summary = requireString(input.summary, 'hqSignal.summary', { min: 1, max: 2000 });
  const evidenceRefs = optionalStringArray(input.evidenceRefs, 'hqSignal.evidenceRefs');
  const contextScope = requireEnum(input.contextScope, 'hqSignal.contextScope', HQ_CONTEXT_SCOPES);
  const detectedAt = requireTimestamp(input.detectedAt, 'hqSignal.detectedAt');

  return freezeResult({
    schemaVersion: 1, signalId, department, category, severity, title, summary,
    ...(evidenceRefs !== undefined ? { evidenceRefs } : {}),
    contextScope, detectedAt,
  });
}

// -------------------------------------------------------------------------
// HQMetric
// -------------------------------------------------------------------------

const METRIC_FIELDS = new Set([
  'schemaVersion', 'metricId', 'department', 'name', 'value', 'unit',
  'previousValue', 'changePct', 'contextScope', 'asOf',
]);

function validateHQMetric(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw contractError('HQMetric is required and must be an object.', 'FIELD_REQUIRED', 'hqMetric');
  }
  onlyKeys(input, METRIC_FIELDS, 'hqMetric');
  const schemaVersion = input.schemaVersion == null ? 1 : input.schemaVersion;
  if (schemaVersion !== 1) throw contractError('Unsupported HQMetric schemaVersion.', 'SCHEMA_VERSION_UNSUPPORTED', 'hqMetric.schemaVersion');

  const metricId = requireString(input.metricId, 'hqMetric.metricId', { min: 6, max: 200, pattern: ID_PATTERN });
  const department = requireEnum(input.department, 'hqMetric.department', HQ_DEPARTMENTS);
  const name = requireString(input.name, 'hqMetric.name', { min: 1, max: 120 });
  const value = requireNumber(input.value, 'hqMetric.value');
  const unit = optionalString(input.unit, 'hqMetric.unit', { min: 1, max: 40 });
  const previousValue = optionalNumber(input.previousValue, 'hqMetric.previousValue');
  const changePct = optionalNumber(input.changePct, 'hqMetric.changePct');
  const contextScope = requireEnum(input.contextScope, 'hqMetric.contextScope', HQ_CONTEXT_SCOPES);
  const asOf = requireTimestamp(input.asOf, 'hqMetric.asOf');

  return freezeResult({
    schemaVersion: 1, metricId, department, name, value,
    ...(unit !== undefined ? { unit } : {}),
    ...(previousValue !== undefined ? { previousValue } : {}),
    ...(changePct !== undefined ? { changePct } : {}),
    contextScope, asOf,
  });
}

// -------------------------------------------------------------------------
// HQRisk
// -------------------------------------------------------------------------

const RISK_FIELDS = new Set([
  'schemaVersion', 'riskId', 'department', 'title', 'description', 'severity',
  'likelihood', 'impact', 'evidenceRefs', 'contextScope', 'detectedAt',
]);

function validateHQRisk(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw contractError('HQRisk is required and must be an object.', 'FIELD_REQUIRED', 'hqRisk');
  }
  onlyKeys(input, RISK_FIELDS, 'hqRisk');
  const schemaVersion = input.schemaVersion == null ? 1 : input.schemaVersion;
  if (schemaVersion !== 1) throw contractError('Unsupported HQRisk schemaVersion.', 'SCHEMA_VERSION_UNSUPPORTED', 'hqRisk.schemaVersion');

  const riskId = requireString(input.riskId, 'hqRisk.riskId', { min: 6, max: 200, pattern: ID_PATTERN });
  const department = requireEnum(input.department, 'hqRisk.department', HQ_DEPARTMENTS);
  const title = requireString(input.title, 'hqRisk.title', { min: 1, max: 200 });
  const description = requireString(input.description, 'hqRisk.description', { min: 1, max: 2000 });
  const severity = requireEnum(input.severity, 'hqRisk.severity', HQ_SEVERITY_LEVELS);
  const likelihood = optionalEnum(input.likelihood, 'hqRisk.likelihood', HQ_SEVERITY_LEVELS);
  const impact = optionalEnum(input.impact, 'hqRisk.impact', HQ_SEVERITY_LEVELS);
  const evidenceRefs = optionalStringArray(input.evidenceRefs, 'hqRisk.evidenceRefs');
  const contextScope = requireEnum(input.contextScope, 'hqRisk.contextScope', HQ_CONTEXT_SCOPES);
  const detectedAt = requireTimestamp(input.detectedAt, 'hqRisk.detectedAt');

  return freezeResult({
    schemaVersion: 1, riskId, department, title, description, severity,
    ...(likelihood !== undefined ? { likelihood } : {}),
    ...(impact !== undefined ? { impact } : {}),
    ...(evidenceRefs !== undefined ? { evidenceRefs } : {}),
    contextScope, detectedAt,
  });
}

// -------------------------------------------------------------------------
// HQOpportunity
// -------------------------------------------------------------------------

const OPPORTUNITY_FIELDS = new Set([
  'schemaVersion', 'opportunityId', 'department', 'title', 'description',
  'estimatedBenefit', 'confidence', 'contextScope', 'detectedAt',
]);

function validateHQOpportunity(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw contractError('HQOpportunity is required and must be an object.', 'FIELD_REQUIRED', 'hqOpportunity');
  }
  onlyKeys(input, OPPORTUNITY_FIELDS, 'hqOpportunity');
  const schemaVersion = input.schemaVersion == null ? 1 : input.schemaVersion;
  if (schemaVersion !== 1) throw contractError('Unsupported HQOpportunity schemaVersion.', 'SCHEMA_VERSION_UNSUPPORTED', 'hqOpportunity.schemaVersion');

  const opportunityId = requireString(input.opportunityId, 'hqOpportunity.opportunityId', { min: 6, max: 200, pattern: ID_PATTERN });
  const department = requireEnum(input.department, 'hqOpportunity.department', HQ_DEPARTMENTS);
  const title = requireString(input.title, 'hqOpportunity.title', { min: 1, max: 200 });
  const description = requireString(input.description, 'hqOpportunity.description', { min: 1, max: 2000 });
  const estimatedBenefit = optionalString(input.estimatedBenefit, 'hqOpportunity.estimatedBenefit', { min: 1, max: 300 });
  const confidence = requireNumber(input.confidence, 'hqOpportunity.confidence', CONFIDENCE_OPTS);
  const contextScope = requireEnum(input.contextScope, 'hqOpportunity.contextScope', HQ_CONTEXT_SCOPES);
  const detectedAt = requireTimestamp(input.detectedAt, 'hqOpportunity.detectedAt');

  return freezeResult({
    schemaVersion: 1, opportunityId, department, title, description,
    ...(estimatedBenefit !== undefined ? { estimatedBenefit } : {}),
    confidence, contextScope, detectedAt,
  });
}

// -------------------------------------------------------------------------
// HQRecommendation
// -------------------------------------------------------------------------

const RECOMMENDATION_FIELDS = new Set([
  'schemaVersion', 'recommendationId', 'department', 'title', 'problem',
  'evidenceRefs', 'recommendedAction', 'alternatives', 'estimatedCost',
  'estimatedBenefit', 'riskLevel', 'confidence', 'authorityRequired',
  'approvalRequired', 'deadline', 'contextScope', 'createdAt',
]);

function validateHQRecommendation(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw contractError('HQRecommendation is required and must be an object.', 'FIELD_REQUIRED', 'hqRecommendation');
  }
  onlyKeys(input, RECOMMENDATION_FIELDS, 'hqRecommendation');
  const schemaVersion = input.schemaVersion == null ? 1 : input.schemaVersion;
  if (schemaVersion !== 1) throw contractError('Unsupported HQRecommendation schemaVersion.', 'SCHEMA_VERSION_UNSUPPORTED', 'hqRecommendation.schemaVersion');

  const recommendationId = requireString(input.recommendationId, 'hqRecommendation.recommendationId', { min: 6, max: 200, pattern: ID_PATTERN });
  const department = requireEnum(input.department, 'hqRecommendation.department', HQ_DEPARTMENTS);
  const title = requireString(input.title, 'hqRecommendation.title', { min: 1, max: 200 });
  const problem = requireString(input.problem, 'hqRecommendation.problem', { min: 1, max: 2000 });
  const evidenceRefs = optionalStringArray(input.evidenceRefs, 'hqRecommendation.evidenceRefs');
  const recommendedAction = requireString(input.recommendedAction, 'hqRecommendation.recommendedAction', { min: 1, max: 1000 });
  const alternatives = optionalStringArray(input.alternatives, 'hqRecommendation.alternatives');
  const estimatedCost = optionalString(input.estimatedCost, 'hqRecommendation.estimatedCost', { min: 1, max: 300 });
  const estimatedBenefit = optionalString(input.estimatedBenefit, 'hqRecommendation.estimatedBenefit', { min: 1, max: 300 });
  const riskLevel = requireEnum(input.riskLevel, 'hqRecommendation.riskLevel', HQ_SEVERITY_LEVELS);
  const confidence = requireNumber(input.confidence, 'hqRecommendation.confidence', CONFIDENCE_OPTS);
  const authorityRequired = requireEnum(input.authorityRequired, 'hqRecommendation.authorityRequired', AUTHORITY_LEVELS);
  const approvalRequired = requireBoolean(input.approvalRequired, 'hqRecommendation.approvalRequired');
  const deadline = optionalTimestamp(input.deadline, 'hqRecommendation.deadline');
  const contextScope = requireEnum(input.contextScope, 'hqRecommendation.contextScope', HQ_CONTEXT_SCOPES);
  const createdAt = requireTimestamp(input.createdAt, 'hqRecommendation.createdAt');

  return freezeResult({
    schemaVersion: 1, recommendationId, department, title, problem,
    ...(evidenceRefs !== undefined ? { evidenceRefs } : {}),
    recommendedAction,
    ...(alternatives !== undefined ? { alternatives } : {}),
    ...(estimatedCost !== undefined ? { estimatedCost } : {}),
    ...(estimatedBenefit !== undefined ? { estimatedBenefit } : {}),
    riskLevel, confidence, authorityRequired, approvalRequired,
    ...(deadline !== undefined ? { deadline } : {}),
    contextScope, createdAt,
  });
}

// -------------------------------------------------------------------------
// HQDecisionRequest (the CEO "decision card", §57)
// -------------------------------------------------------------------------

const DECISION_FIELDS = new Set([
  'schemaVersion', 'decisionId', 'title', 'department', 'problem', 'evidence',
  'impact', 'urgency', 'recommendedAction', 'alternatives', 'estimatedCost',
  'estimatedBenefit', 'riskLevel', 'confidence', 'authorityRequired',
  'approvalRequired', 'deadline', 'status', 'supportingReferences',
  'contextScope', 'createdAt',
]);

function validateHQDecisionRequest(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw contractError('HQDecisionRequest is required and must be an object.', 'FIELD_REQUIRED', 'hqDecisionRequest');
  }
  onlyKeys(input, DECISION_FIELDS, 'hqDecisionRequest');
  const schemaVersion = input.schemaVersion == null ? 1 : input.schemaVersion;
  if (schemaVersion !== 1) throw contractError('Unsupported HQDecisionRequest schemaVersion.', 'SCHEMA_VERSION_UNSUPPORTED', 'hqDecisionRequest.schemaVersion');

  const decisionId = requireString(input.decisionId, 'hqDecisionRequest.decisionId', { min: 6, max: 200, pattern: ID_PATTERN });
  const title = requireString(input.title, 'hqDecisionRequest.title', { min: 1, max: 200 });
  const department = requireEnum(input.department, 'hqDecisionRequest.department', HQ_DEPARTMENTS);
  const problem = requireString(input.problem, 'hqDecisionRequest.problem', { min: 1, max: 2000 });
  const evidence = optionalStringArray(input.evidence, 'hqDecisionRequest.evidence');
  const impact = requireString(input.impact, 'hqDecisionRequest.impact', { min: 1, max: 500 });
  const urgency = requireEnum(input.urgency, 'hqDecisionRequest.urgency', HQ_SEVERITY_LEVELS);
  const recommendedAction = requireString(input.recommendedAction, 'hqDecisionRequest.recommendedAction', { min: 1, max: 1000 });
  const alternatives = optionalStringArray(input.alternatives, 'hqDecisionRequest.alternatives');
  const estimatedCost = optionalString(input.estimatedCost, 'hqDecisionRequest.estimatedCost', { min: 1, max: 300 });
  const estimatedBenefit = optionalString(input.estimatedBenefit, 'hqDecisionRequest.estimatedBenefit', { min: 1, max: 300 });
  const riskLevel = requireEnum(input.riskLevel, 'hqDecisionRequest.riskLevel', HQ_SEVERITY_LEVELS);
  const confidence = requireNumber(input.confidence, 'hqDecisionRequest.confidence', CONFIDENCE_OPTS);
  const authorityRequired = requireEnum(input.authorityRequired, 'hqDecisionRequest.authorityRequired', AUTHORITY_LEVELS);
  const approvalRequired = requireBoolean(input.approvalRequired, 'hqDecisionRequest.approvalRequired');
  const deadline = optionalTimestamp(input.deadline, 'hqDecisionRequest.deadline');
  const status = requireEnum(input.status, 'hqDecisionRequest.status', HQ_DECISION_STATUSES);
  const supportingReferences = optionalStringArray(input.supportingReferences, 'hqDecisionRequest.supportingReferences');
  const contextScope = requireEnum(input.contextScope, 'hqDecisionRequest.contextScope', HQ_CONTEXT_SCOPES);
  const createdAt = requireTimestamp(input.createdAt, 'hqDecisionRequest.createdAt');

  return freezeResult({
    schemaVersion: 1, decisionId, title, department, problem,
    ...(evidence !== undefined ? { evidence } : {}),
    impact, urgency, recommendedAction,
    ...(alternatives !== undefined ? { alternatives } : {}),
    ...(estimatedCost !== undefined ? { estimatedCost } : {}),
    ...(estimatedBenefit !== undefined ? { estimatedBenefit } : {}),
    riskLevel, confidence, authorityRequired, approvalRequired,
    ...(deadline !== undefined ? { deadline } : {}),
    status,
    ...(supportingReferences !== undefined ? { supportingReferences } : {}),
    contextScope, createdAt,
  });
}

// -------------------------------------------------------------------------
// HQDepartmentSnapshot
// -------------------------------------------------------------------------

const SNAPSHOT_FIELDS = new Set([
  'schemaVersion', 'snapshotId', 'department', 'generatedAt', 'status',
  'metricRefs', 'signalRefs', 'confidence', 'contextScope', 'notes',
]);

function validateHQDepartmentSnapshot(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw contractError('HQDepartmentSnapshot is required and must be an object.', 'FIELD_REQUIRED', 'hqDepartmentSnapshot');
  }
  onlyKeys(input, SNAPSHOT_FIELDS, 'hqDepartmentSnapshot');
  const schemaVersion = input.schemaVersion == null ? 1 : input.schemaVersion;
  if (schemaVersion !== 1) throw contractError('Unsupported HQDepartmentSnapshot schemaVersion.', 'SCHEMA_VERSION_UNSUPPORTED', 'hqDepartmentSnapshot.schemaVersion');

  const snapshotId = requireString(input.snapshotId, 'hqDepartmentSnapshot.snapshotId', { min: 6, max: 200, pattern: ID_PATTERN });
  const department = requireEnum(input.department, 'hqDepartmentSnapshot.department', HQ_DEPARTMENTS);
  const generatedAt = requireTimestamp(input.generatedAt, 'hqDepartmentSnapshot.generatedAt');
  const status = requireEnum(input.status, 'hqDepartmentSnapshot.status', HQ_DEPARTMENT_STATUSES);
  const metricRefs = optionalStringArray(input.metricRefs, 'hqDepartmentSnapshot.metricRefs', { max: 50 });
  const signalRefs = optionalStringArray(input.signalRefs, 'hqDepartmentSnapshot.signalRefs', { max: 50 });
  const confidence = requireNumber(input.confidence, 'hqDepartmentSnapshot.confidence', CONFIDENCE_OPTS);
  const contextScope = requireEnum(input.contextScope, 'hqDepartmentSnapshot.contextScope', HQ_CONTEXT_SCOPES);
  const notes = optionalString(input.notes, 'hqDepartmentSnapshot.notes', { min: 1, max: 1000 });

  return freezeResult({
    schemaVersion: 1, snapshotId, department, generatedAt, status,
    ...(metricRefs !== undefined ? { metricRefs } : {}),
    ...(signalRefs !== undefined ? { signalRefs } : {}),
    confidence, contextScope,
    ...(notes !== undefined ? { notes } : {}),
  });
}

// -------------------------------------------------------------------------
// HQBrief (the CEO morning brief / while-you-were-away output, §56)
// -------------------------------------------------------------------------

const BRIEF_FIELDS = new Set([
  'schemaVersion', 'briefId', 'generatedAt', 'sections', 'departmentStatuses',
  'riskRefs', 'opportunityRefs', 'decisionRefs', 'whileYouWereAway',
  'contextScope', 'confidence',
]);

const BRIEF_SECTION_KEYS = new Set([
  'companyHealth', 'finance', 'product', 'infrastructure', 'security',
  'support', 'growth',
]);

function validateBriefSections(value, field) {
  const sections = requirePlainObject(value, field, { maxKeys: BRIEF_SECTION_KEYS.size });
  for (const key of Object.keys(sections)) {
    if (!BRIEF_SECTION_KEYS.has(key)) {
      throw contractError(field + ' contains an unsupported section: ' + key + '.', 'FIELD_UNSUPPORTED', field + '.' + key);
    }
    requireString(sections[key], field + '.' + key, { min: 1, max: 4000 });
  }
  return sections;
}

function validateDepartmentStatuses(value, field) {
  const statuses = requirePlainObject(value, field, { maxKeys: HQ_DEPARTMENTS.length });
  for (const [department, status] of Object.entries(statuses)) {
    if (!HQ_DEPARTMENTS.includes(department)) {
      throw contractError(field + ' contains an unknown department: ' + department + '.', 'FIELD_INVALID', field + '.' + department);
    }
    requireEnum(status, field + '.' + department, HQ_DEPARTMENT_STATUSES);
  }
  return statuses;
}

function validateHQBrief(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw contractError('HQBrief is required and must be an object.', 'FIELD_REQUIRED', 'hqBrief');
  }
  onlyKeys(input, BRIEF_FIELDS, 'hqBrief');
  const schemaVersion = input.schemaVersion == null ? 1 : input.schemaVersion;
  if (schemaVersion !== 1) throw contractError('Unsupported HQBrief schemaVersion.', 'SCHEMA_VERSION_UNSUPPORTED', 'hqBrief.schemaVersion');

  const briefId = requireString(input.briefId, 'hqBrief.briefId', { min: 6, max: 200, pattern: ID_PATTERN });
  const generatedAt = requireTimestamp(input.generatedAt, 'hqBrief.generatedAt');
  const sections = validateBriefSections(input.sections, 'hqBrief.sections');
  const departmentStatuses = validateDepartmentStatuses(input.departmentStatuses, 'hqBrief.departmentStatuses');
  const riskRefs = optionalStringArray(input.riskRefs, 'hqBrief.riskRefs', { max: 50 });
  const opportunityRefs = optionalStringArray(input.opportunityRefs, 'hqBrief.opportunityRefs', { max: 50 });
  const decisionRefs = optionalStringArray(input.decisionRefs, 'hqBrief.decisionRefs', { max: 50 });
  const whileYouWereAway = optionalStringArray(input.whileYouWereAway, 'hqBrief.whileYouWereAway', { max: 50 });
  const contextScope = requireEnum(input.contextScope, 'hqBrief.contextScope', HQ_CONTEXT_SCOPES);
  const confidence = optionalNumber(input.confidence, 'hqBrief.confidence', CONFIDENCE_OPTS);

  return freezeResult({
    schemaVersion: 1, briefId, generatedAt, sections, departmentStatuses,
    ...(riskRefs !== undefined ? { riskRefs } : {}),
    ...(opportunityRefs !== undefined ? { opportunityRefs } : {}),
    ...(decisionRefs !== undefined ? { decisionRefs } : {}),
    ...(whileYouWereAway !== undefined ? { whileYouWereAway } : {}),
    contextScope,
    ...(confidence !== undefined ? { confidence } : {}),
  });
}

module.exports = {
  validateHQSignal,
  validateHQMetric,
  validateHQRisk,
  validateHQOpportunity,
  validateHQRecommendation,
  validateHQDecisionRequest,
  validateHQDepartmentSnapshot,
  validateHQBrief,
};
