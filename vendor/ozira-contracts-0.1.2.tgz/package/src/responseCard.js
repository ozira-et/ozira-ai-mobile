'use strict';

// Versioned, provider-neutral response-card envelope. The payload is data,
// never instructions; renderers must still treat it as untrusted content.
const {
  requireString, optionalString, requireEnum, requirePlainObject, optionalArray,
  optionalTimestamp, onlyKeys, freezeResult, contractError, ID_PATTERN,
} = require('./validation');

const RESPONSE_CARD_TYPES = Object.freeze([
  'general_text', 'search', 'place', 'map', 'route', 'current_weather',
  'forecast', 'nearby', 'fact', 'code', 'table', 'action', 'error',
]);
const RESPONSE_CARD_LIFECYCLES = Object.freeze(['loading', 'success', 'partial', 'empty', 'error']);
const RESPONSE_CARD_ACTIONS = Object.freeze(['open_url', 'open_map', 'copy', 'retry', 'confirm']);
const CARD_FIELDS = new Set([
  'schemaVersion', 'cardId', 'type', 'lifecycle', 'title', 'label', 'payload',
  'fallbackText', 'sources', 'createdAt', 'updatedAt', 'provider', 'actions',
]);

function validateCardSource(value, field) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw contractError(field + ' must be an object.', 'FIELD_INVALID', field);
  }
  onlyKeys(value, new Set(['label', 'href', 'verified']), field);
  const label = requireString(value.label, field + '.label', { min: 1, max: 160 });
  const href = optionalString(value.href, field + '.href', { min: 1, max: 2000 });
  if (href) {
    let parsed;
    try { parsed = new URL(href); } catch (_) { throw contractError(field + '.href must be a valid URL.', 'FIELD_INVALID', field + '.href'); }
    if (!safeCardUrl(href)) {
      throw contractError(field + '.href must be a public HTTPS URL.', 'FIELD_INVALID', field + '.href');
    }
  }
  return { label, ...(href ? { href } : {}), ...(value.verified === true ? { verified: true } : {}) };
}

function validateResponseCard(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw contractError('ResponseCard is required and must be an object.', 'FIELD_REQUIRED', 'responseCard');
  }
  onlyKeys(input, CARD_FIELDS, 'responseCard');
  const schemaVersion = input.schemaVersion;
  if (schemaVersion !== 1) throw contractError('Unsupported ResponseCard schemaVersion.', 'SCHEMA_VERSION_UNSUPPORTED', 'responseCard.schemaVersion');
  const cardId = requireString(input.cardId, 'responseCard.cardId', { min: 6, max: 200, pattern: ID_PATTERN });
  const type = requireEnum(input.type, 'responseCard.type', RESPONSE_CARD_TYPES);
  const lifecycle = requireEnum(input.lifecycle, 'responseCard.lifecycle', RESPONSE_CARD_LIFECYCLES);
  const title = requireString(input.title, 'responseCard.title', { min: 1, max: 240 });
  const label = optionalString(input.label, 'responseCard.label', { min: 1, max: 240 });
  const payload = requirePlainObject(input.payload, 'responseCard.payload', { maxKeys: 128 });
  if (['success', 'partial'].includes(lifecycle)) validatePayload(type, payload);
  const fallbackText = optionalString(input.fallbackText, 'responseCard.fallbackText', { min: 1, max: 4000 });
  const sources = (optionalArray(input.sources, 'responseCard.sources', { max: 8 }) || []).map((source, index) => validateCardSource(source, `responseCard.sources[${index}]`));
  const createdAt = optionalTimestamp(input.createdAt, 'responseCard.createdAt');
  const updatedAt = optionalTimestamp(input.updatedAt, 'responseCard.updatedAt');
  const provider = optionalString(input.provider, 'responseCard.provider', { min: 1, max: 120 });
  const actions = (optionalArray(input.actions, 'responseCard.actions', { max: 8 }) || []).map((action, index) => {
    const field = `responseCard.actions[${index}]`;
    if (!action || typeof action !== 'object' || Array.isArray(action)) throw contractError(field + ' must be an object.', 'FIELD_INVALID', field);
    onlyKeys(action, new Set(['id', 'type', 'label', 'href']), field);
    const id = requireString(action.id, field + '.id', { min: 2, max: 80, pattern: /^[A-Za-z0-9_.:-]+$/ });
    const actionType = requireEnum(action.type, field + '.type', RESPONSE_CARD_ACTIONS);
    const actionLabel = requireString(action.label, field + '.label', { min: 1, max: 120 });
    const href = optionalString(action.href, field + '.href', { min: 1, max: 2000 });
    if (href) {
      let parsed;
      try { parsed = new URL(href); } catch (_) { throw contractError(field + '.href must be a valid URL.', 'FIELD_INVALID', field + '.href'); }
      if (!safeCardUrl(href)) throw contractError(field + '.href must be a public HTTPS URL.', 'FIELD_INVALID', field + '.href');
    }
    return { id, type: actionType, label: actionLabel, ...(href ? { href } : {}) };
  });
  if (lifecycle === 'error' && !fallbackText) throw contractError('Error cards require fallbackText.', 'FIELD_REQUIRED', 'responseCard.fallbackText');
  return freezeResult({
    schemaVersion: 1, cardId, type, lifecycle, title,
    ...(label ? { label } : {}), payload,
    ...(fallbackText ? { fallbackText } : {}),
    ...(sources.length ? { sources } : {}),
    ...(createdAt ? { createdAt } : {}), ...(updatedAt ? { updatedAt } : {}),
    ...(provider ? { provider } : {}), ...(actions.length ? { actions } : {}),
  });
}

module.exports = {
  RESPONSE_CARD_TYPES,
  RESPONSE_CARD_LIFECYCLES,
  RESPONSE_CARD_ACTIONS,
  validateResponseCard,
  responseCardsForMessage,
  safeCardUrl,
};

function safeCardUrl(value) {
  try {
    const u = new URL(value);
    if (u.protocol !== 'https:' || u.username || u.password || u.hash) return null;
    const host = u.hostname.toLowerCase();
    if (!host.includes('.') || host.includes(':') || /^[0-9.]+$/.test(host) || /(^|\.)(localhost|local|internal|test)$/.test(host)) return null;
    if ([...u.searchParams.keys()].some(k => /token|key|secret|signature|credential|auth/i.test(k))) return null;
    return u.href;
  } catch (_) { return null; }
}

function validatePayload(type, p) {
  const number = (key, min, max) => {
    if (p[key] != null && (typeof p[key] !== 'number' || !Number.isFinite(p[key]) || p[key] < min || p[key] > max)) throw contractError('Invalid card measurement.', 'FIELD_INVALID', key);
  };
  if (type === 'current_weather') {
    requireString(p.location, 'payload.location', { max: 240 });
    number('temperatureC', -100, 70);
    for (const k of ['feelsLikeC', 'highC', 'lowC']) number(k, -100, 70);
    for (const k of ['humidityPercent', 'precipitationPercent']) number(k, 0, 100);
    number('windKph', 0, 500);
    if (p.condition != null) requireString(p.condition, 'payload.condition', { max: 160 });
    if (p.dateLabel != null) requireString(p.dateLabel, 'payload.dateLabel', { max: 160 });
  }
  if (type === 'place') {
    requireString(p.name, 'payload.name', { max: 240 });
    for (const k of ['address', 'type']) if (p[k] != null) requireString(p[k], 'payload.' + k, { min: 0, max: 600 });
    number('latitude', -90, 90); number('longitude', -180, 180);
    for (const k of ['mapsUrl', 'websiteUrl']) if (p[k] && !safeCardUrl(p[k])) throw contractError('Unsafe card URL.', 'FIELD_INVALID', k);
  }
}

function responseCardsForMessage(message) {
  if (message && message.role && message.role !== 'assistant') return [];
  const m = message && message.metadata || {};
  const cards = new Map();
  const accept = raw => {
    try {
      const card = validateResponseCard(raw);
      if ((card.sources || []).some(s => s.href && !safeCardUrl(s.href))) return;
      if ((card.actions || []).some(a => a.href && !safeCardUrl(a.href))) return;
      cards.set(card.cardId, card);
    } catch (_) { /* Text stays visible; diagnostics contain no payload. */ }
  };
  if (Array.isArray(m.responseCards)) m.responseCards.slice(0, 32).forEach(accept);
  if (cards.size) return [...cards.values()];
  for (const [key, type] of [['weather', 'current_weather'], ['place', 'place']]) {
    const p = m[key];
    if (!p || typeof p !== 'object') continue;
    accept({ schemaVersion: 1, cardId: 'legacy_' + type, type, lifecycle: 'partial',
      title: p.location || p.name, payload: p, fallbackText: p.summary || p.location || p.name,
      ...(Array.isArray(m.sources) ? { sources: m.sources } : {}) });
  }
  return [...cards.values()];
}
