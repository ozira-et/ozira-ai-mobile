'use strict';

// ToolInvocation / ToolResult — provider-neutral invocation of an MCP/tool
// capability. Mirrors the shape already declared by skills/*/ozira.skill.json
// (toolId ~ skill id, e.g. "system.echo").
//
// ToolResult.output is UNTRUSTED CONTENT BY DEFAULT: validating this contract
// only proves the envelope is well-formed and secret-free. It does not make
// the tool's output safe to treat as an instruction. Callers must keep output
// on the "data, never instructions" side of the trust boundary.

const {
  requireString, optionalString, requireEnum, requirePlainObject, optionalPlainObject,
  optionalTimestamp, onlyKeys, freezeResult, contractError, ID_PATTERN,
} = require('./validation');
const { TOOL_RESULT_STATUSES } = require('./enums');
const { validatePrincipal } = require('./principal');

const TOOL_ID_PATTERN = /^[a-z][a-z0-9]*(?:\.[a-z][a-z0-9]*)+$/;
const IDEMPOTENCY_KEY_PATTERN = /^[A-Za-z0-9._:-]{8,160}$/;

// -------------------------------------------------------------------------
// ToolInvocation
// -------------------------------------------------------------------------

const TOOL_INVOCATION_FIELDS = new Set([
  'schemaVersion', 'invocationId', 'toolId', 'principal', 'input', 'correlationId', 'idempotencyKey',
]);

function validateToolInvocation(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw contractError('ToolInvocation is required and must be an object.', 'FIELD_REQUIRED', 'toolInvocation');
  }
  onlyKeys(input, TOOL_INVOCATION_FIELDS, 'toolInvocation');
  const schemaVersion = input.schemaVersion == null ? 1 : input.schemaVersion;
  if (schemaVersion !== 1) throw contractError('Unsupported ToolInvocation schemaVersion.', 'SCHEMA_VERSION_UNSUPPORTED', 'toolInvocation.schemaVersion');

  const invocationId = requireString(input.invocationId, 'toolInvocation.invocationId', { min: 6, max: 200, pattern: ID_PATTERN });
  const toolId = requireString(input.toolId, 'toolInvocation.toolId', { min: 3, max: 120, pattern: TOOL_ID_PATTERN });
  const principal = validatePrincipal(input.principal);
  const inputPayload = requirePlainObject(input.input, 'toolInvocation.input', { maxKeys: 64 });
  const correlationId = optionalString(input.correlationId, 'toolInvocation.correlationId', { min: 1, max: 200, pattern: ID_PATTERN });
  const idempotencyKey = optionalString(input.idempotencyKey, 'toolInvocation.idempotencyKey', { min: 8, max: 160, pattern: IDEMPOTENCY_KEY_PATTERN });

  return freezeResult({
    schemaVersion: 1,
    invocationId,
    toolId,
    principal,
    input: inputPayload,
    ...(correlationId !== undefined ? { correlationId } : {}),
    ...(idempotencyKey !== undefined ? { idempotencyKey } : {}),
  });
}

// -------------------------------------------------------------------------
// ToolResult
// -------------------------------------------------------------------------

const TOOL_RESULT_FIELDS = new Set(['schemaVersion', 'invocationId', 'status', 'output', 'error', 'providerReference', 'completedAt']);

function validateToolError(value, field) {
  if (value === undefined || value === null) return undefined;
  if (typeof value !== 'object' || Array.isArray(value)) throw contractError(field + ' must be an object.', 'FIELD_INVALID', field);
  onlyKeys(value, new Set(['code', 'message']), field);
  return {
    code: requireString(value.code, field + '.code', { min: 1, max: 120, pattern: /^[A-Za-z0-9_.:-]+$/ }),
    ...(value.message !== undefined ? { message: requireString(value.message, field + '.message', { min: 0, max: 2000 }) } : {}),
  };
}

function validateToolResult(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw contractError('ToolResult is required and must be an object.', 'FIELD_REQUIRED', 'toolResult');
  }
  onlyKeys(input, TOOL_RESULT_FIELDS, 'toolResult');
  const schemaVersion = input.schemaVersion == null ? 1 : input.schemaVersion;
  if (schemaVersion !== 1) throw contractError('Unsupported ToolResult schemaVersion.', 'SCHEMA_VERSION_UNSUPPORTED', 'toolResult.schemaVersion');

  const invocationId = requireString(input.invocationId, 'toolResult.invocationId', { min: 6, max: 200, pattern: ID_PATTERN });
  const status = requireEnum(input.status, 'toolResult.status', TOOL_RESULT_STATUSES);
  const output = optionalPlainObject(input.output, 'toolResult.output', { maxKeys: 128 });
  const error = validateToolError(input.error, 'toolResult.error');
  const providerReference = optionalString(input.providerReference, 'toolResult.providerReference', { min: 1, max: 200 });
  const completedAt = optionalTimestamp(input.completedAt, 'toolResult.completedAt');

  return freezeResult({
    schemaVersion: 1,
    invocationId,
    status,
    ...(output !== undefined ? { output } : {}),
    ...(error !== undefined ? { error } : {}),
    ...(providerReference !== undefined ? { providerReference } : {}),
    ...(completedAt !== undefined ? { completedAt } : {}),
  });
}

module.exports = { validateToolInvocation, validateToolResult };
