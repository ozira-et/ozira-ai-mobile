'use strict';

// ApprovalRequest — canonical human-approval request. Designed to represent
// both the existing execution.* command-scoped approval rows and the phase0
// generic store.approvals table without forcing either storage model to
// migrate in Phase 1 (see docs/architecture.md, "Approval model convergence
// — contract only"). Adapters translate; storage stays put.

const {
  requireString, requireEnum, requireTimestamp, optionalTimestamp,
  onlyKeys, freezeResult, contractError, ID_PATTERN,
} = require('./validation');
const { AUTHORITY_LEVELS, APPROVAL_STATUSES } = require('./enums');
const { validatePrincipal } = require('./principal');

const ALLOWED_FIELDS = new Set([
  'schemaVersion', 'approvalId', 'actionId', 'principal', 'requestedAuthority',
  'reason', 'status', 'createdAt', 'expiresAt',
]);

function validateApprovalRequest(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw contractError('ApprovalRequest is required and must be an object.', 'FIELD_REQUIRED', 'approvalRequest');
  }
  onlyKeys(input, ALLOWED_FIELDS, 'approvalRequest');
  const schemaVersion = input.schemaVersion == null ? 1 : input.schemaVersion;
  if (schemaVersion !== 1) throw contractError('Unsupported ApprovalRequest schemaVersion.', 'SCHEMA_VERSION_UNSUPPORTED', 'approvalRequest.schemaVersion');

  const approvalId = requireString(input.approvalId, 'approvalRequest.approvalId', { min: 6, max: 200, pattern: ID_PATTERN });
  const actionId = requireString(input.actionId, 'approvalRequest.actionId', { min: 6, max: 200, pattern: ID_PATTERN });
  const principal = validatePrincipal(input.principal);
  const requestedAuthority = requireEnum(input.requestedAuthority, 'approvalRequest.requestedAuthority', AUTHORITY_LEVELS);
  const reason = requireString(input.reason, 'approvalRequest.reason', { min: 1, max: 500 });
  const status = requireEnum(input.status, 'approvalRequest.status', APPROVAL_STATUSES);
  const createdAt = requireTimestamp(input.createdAt, 'approvalRequest.createdAt');
  const expiresAt = optionalTimestamp(input.expiresAt, 'approvalRequest.expiresAt');
  if (expiresAt !== undefined && Date.parse(expiresAt) <= Date.parse(createdAt)) {
    throw contractError('approvalRequest.expiresAt must be after createdAt.', 'FIELD_INVALID', 'approvalRequest.expiresAt');
  }

  return freezeResult({
    schemaVersion: 1,
    approvalId,
    actionId,
    principal,
    requestedAuthority,
    reason,
    status,
    createdAt,
    ...(expiresAt !== undefined ? { expiresAt } : {}),
  });
}

module.exports = { validateApprovalRequest };
