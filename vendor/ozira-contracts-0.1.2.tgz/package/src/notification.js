'use strict';

// Notification — canonical platform notification, deliberately uncoupled
// from any delivery provider (Telegram, email, push, in-app). A delivery
// adapter maps this contract onto a specific channel; this phase does not
// implement one.

const {
  requireString, optionalString, requireEnum, requireTimestamp, requireArray,
  onlyKeys, freezeResult, contractError, ID_PATTERN,
} = require('./validation');
const { NOTIFICATION_URGENCY, NOTIFICATION_STATUSES } = require('./enums');
const { validatePrincipal } = require('./principal');

const ALLOWED_FIELDS = new Set([
  'schemaVersion', 'notificationId', 'principal', 'type', 'title', 'body', 'urgency',
  'status', 'actions', 'relatedActionId', 'createdAt',
]);

function validateNotificationAction(value, index) {
  const field = 'notification.actions[' + index + ']';
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw contractError(field + ' must be an object.', 'FIELD_INVALID', field);
  onlyKeys(value, new Set(['label', 'actionId']), field);
  return {
    label: requireString(value.label, field + '.label', { min: 1, max: 60 }),
    actionId: requireString(value.actionId, field + '.actionId', { min: 6, max: 200, pattern: ID_PATTERN }),
  };
}

function validateNotification(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw contractError('Notification is required and must be an object.', 'FIELD_REQUIRED', 'notification');
  }
  onlyKeys(input, ALLOWED_FIELDS, 'notification');
  const schemaVersion = input.schemaVersion == null ? 1 : input.schemaVersion;
  if (schemaVersion !== 1) throw contractError('Unsupported Notification schemaVersion.', 'SCHEMA_VERSION_UNSUPPORTED', 'notification.schemaVersion');

  const notificationId = requireString(input.notificationId, 'notification.notificationId', { min: 6, max: 200, pattern: ID_PATTERN });
  const principal = validatePrincipal(input.principal);
  const type = requireString(input.type, 'notification.type', { min: 1, max: 80, pattern: /^[a-z][a-z0-9.:_-]*$/ });
  const title = requireString(input.title, 'notification.title', { min: 1, max: 200 });
  const body = requireString(input.body, 'notification.body', { min: 1, max: 2000 });
  const urgency = requireEnum(input.urgency, 'notification.urgency', NOTIFICATION_URGENCY);
  const status = requireEnum(input.status, 'notification.status', NOTIFICATION_STATUSES);
  const actions = input.actions === undefined ? undefined : requireArray(input.actions, 'notification.actions', { max: 5 }).map(validateNotificationAction);
  const relatedActionId = optionalString(input.relatedActionId, 'notification.relatedActionId', { min: 6, max: 200, pattern: ID_PATTERN });
  const createdAt = requireTimestamp(input.createdAt, 'notification.createdAt');

  return freezeResult({
    schemaVersion: 1,
    notificationId,
    principal,
    type,
    title,
    body,
    urgency,
    status,
    ...(actions !== undefined ? { actions } : {}),
    ...(relatedActionId !== undefined ? { relatedActionId } : {}),
    createdAt,
  });
}

module.exports = { validateNotification };
