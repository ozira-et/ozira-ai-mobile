'use strict';

// PAgentIntent / PAgentResponse — minimum-necessary-disclosure envelopes for
// P-to-P coordination. This is the one contract pair where structural
// validation itself enforces part of the privacy invariant, rather than only
// checking shape:
//
//   P agents exchange minimum necessary intent, not raw personal context.
//
// `payload` here is therefore NOT an arbitrary object like other contracts'
// payload fields. It is restricted to a shallow (depth-1), bounded set of
// primitive values — e.g. { purpose: "lunch", proposedTime: "...", timezone:
// "Asia/Dubai" }. That structurally prevents a raw memory object, calendar
// event, or message history from being smuggled across the P-to-P boundary
// as "just a field". It is NOT a complete privacy system: this is a
// structural minimum, not a semantic one. A future explicit allowlist of
// permitted (intentType -> payload keys) pairs, purpose-specific validators,
// and a recipient-side policy gate remain Phase 2+ work (see
// docs/architecture.md). Do not use this contract to justify skipping that
// work — it only bounds what is STRUCTURALLY possible to send.

const {
  requireString, requireEnum, requireTimestamp, optionalTimestamp,
  onlyKeys, freezeResult, contractError, assertNoSecretFields, ID_PATTERN,
} = require('./validation');
const { DISCLOSURE_SCOPES, P2P_INTENT_STATUSES, P2P_RESPONSE_STATUSES } = require('./enums');
const { validatePrincipal } = require('./principal');

const INTENT_TYPE_PATTERN = /^[A-Z][A-Z0-9_]{2,60}$/;
const REF_PATTERN = /^[A-Za-z0-9][A-Za-z0-9_.:-]{2,200}$/;
const MAX_PAYLOAD_KEYS = 8;
const MAX_PAYLOAD_STRING_LENGTH = 300;

function requireMinimalDisclosurePayload(value, field, disclosureScope) {
  if (disclosureScope === 'NONE') {
    if (value !== undefined && value !== null && Object.keys(value).length > 0) {
      throw contractError(field + ' must be empty when disclosureScope is NONE.', 'FIELD_INVALID', field);
    }
    return {};
  }
  if (value === undefined || value === null || typeof value !== 'object' || Array.isArray(value)) {
    throw contractError(field + ' is required and must be a flat object of primitive values.', 'FIELD_REQUIRED', field);
  }
  const prototype = Object.getPrototypeOf(value);
  if (prototype !== Object.prototype && prototype !== null) {
    throw contractError(field + ' must be a plain object.', 'FIELD_INVALID', field);
  }
  const keys = Object.keys(value);
  if (keys.length === 0) throw contractError(field + ' must not be empty.', 'FIELD_INVALID', field);
  if (keys.length > MAX_PAYLOAD_KEYS) {
    throw contractError(field + ' may carry at most ' + MAX_PAYLOAD_KEYS + ' fields (minimum-necessary-disclosure).', 'FIELD_INVALID', field);
  }
  for (const key of keys) {
    if (!/^[a-zA-Z][a-zA-Z0-9]{0,39}$/.test(key)) {
      throw contractError(field + '.' + key + ' has an invalid field name.', 'FIELD_INVALID', field + '.' + key);
    }
    const item = value[key];
    const type = typeof item;
    if (item === null) continue;
    if (type === 'string') {
      if (/[\x00\r\n]/.test(item) || Buffer.byteLength(item, 'utf8') > MAX_PAYLOAD_STRING_LENGTH) {
        throw contractError(field + '.' + key + ' string value is invalid or too long.', 'FIELD_INVALID', field + '.' + key);
      }
      continue;
    }
    if (type === 'number') {
      if (!Number.isFinite(item)) throw contractError(field + '.' + key + ' must be a finite number.', 'FIELD_INVALID', field + '.' + key);
      continue;
    }
    if (type === 'boolean') continue;
    throw contractError(
      field + '.' + key + ' must be a primitive value (nested objects/arrays are not permitted in a minimum-disclosure payload).',
      'FIELD_INVALID',
      field + '.' + key,
    );
  }
  assertNoSecretFields(value, field);
  return value;
}

// -------------------------------------------------------------------------
// PAgentIntent
// -------------------------------------------------------------------------

const INTENT_FIELDS = new Set([
  'schemaVersion', 'intentId', 'senderPrincipal', 'recipientRef', 'intentType',
  'payload', 'disclosureScope', 'status', 'createdAt', 'expiresAt',
]);

function validatePAgentIntent(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw contractError('PAgentIntent is required and must be an object.', 'FIELD_REQUIRED', 'pAgentIntent');
  }
  onlyKeys(input, INTENT_FIELDS, 'pAgentIntent');
  const schemaVersion = input.schemaVersion == null ? 1 : input.schemaVersion;
  if (schemaVersion !== 1) throw contractError('Unsupported PAgentIntent schemaVersion.', 'SCHEMA_VERSION_UNSUPPORTED', 'pAgentIntent.schemaVersion');

  const intentId = requireString(input.intentId, 'pAgentIntent.intentId', { min: 6, max: 200, pattern: ID_PATTERN });
  const senderPrincipal = validatePrincipal(input.senderPrincipal);
  const recipientRef = requireString(input.recipientRef, 'pAgentIntent.recipientRef', { min: 3, max: 200, pattern: REF_PATTERN });
  const intentType = requireString(input.intentType, 'pAgentIntent.intentType', { min: 3, max: 60, pattern: INTENT_TYPE_PATTERN });
  const disclosureScope = requireEnum(input.disclosureScope, 'pAgentIntent.disclosureScope', DISCLOSURE_SCOPES);
  const payload = requireMinimalDisclosurePayload(input.payload, 'pAgentIntent.payload', disclosureScope);
  const status = requireEnum(input.status, 'pAgentIntent.status', P2P_INTENT_STATUSES);
  const createdAt = requireTimestamp(input.createdAt, 'pAgentIntent.createdAt');
  const expiresAt = optionalTimestamp(input.expiresAt, 'pAgentIntent.expiresAt');
  if (expiresAt !== undefined && Date.parse(expiresAt) <= Date.parse(createdAt)) {
    throw contractError('pAgentIntent.expiresAt must be after createdAt.', 'FIELD_INVALID', 'pAgentIntent.expiresAt');
  }

  return freezeResult({
    schemaVersion: 1,
    intentId,
    senderPrincipal,
    recipientRef,
    intentType,
    payload,
    disclosureScope,
    status,
    createdAt,
    ...(expiresAt !== undefined ? { expiresAt } : {}),
  });
}

// -------------------------------------------------------------------------
// PAgentResponse
// -------------------------------------------------------------------------

const RESPONSE_FIELDS = new Set([
  'schemaVersion', 'responseId', 'intentId', 'responderRef', 'responseType',
  'payload', 'disclosureScope', 'status', 'createdAt',
]);

function validatePAgentResponse(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw contractError('PAgentResponse is required and must be an object.', 'FIELD_REQUIRED', 'pAgentResponse');
  }
  onlyKeys(input, RESPONSE_FIELDS, 'pAgentResponse');
  const schemaVersion = input.schemaVersion == null ? 1 : input.schemaVersion;
  if (schemaVersion !== 1) throw contractError('Unsupported PAgentResponse schemaVersion.', 'SCHEMA_VERSION_UNSUPPORTED', 'pAgentResponse.schemaVersion');

  const responseId = requireString(input.responseId, 'pAgentResponse.responseId', { min: 6, max: 200, pattern: ID_PATTERN });
  const intentId = requireString(input.intentId, 'pAgentResponse.intentId', { min: 6, max: 200, pattern: ID_PATTERN });
  const responderRef = requireString(input.responderRef, 'pAgentResponse.responderRef', { min: 3, max: 200, pattern: REF_PATTERN });
  const responseType = requireString(input.responseType, 'pAgentResponse.responseType', { min: 3, max: 60, pattern: INTENT_TYPE_PATTERN });
  const disclosureScope = requireEnum(input.disclosureScope, 'pAgentResponse.disclosureScope', DISCLOSURE_SCOPES);
  const payload = requireMinimalDisclosurePayload(input.payload, 'pAgentResponse.payload', disclosureScope);
  const status = requireEnum(input.status, 'pAgentResponse.status', P2P_RESPONSE_STATUSES);
  const createdAt = requireTimestamp(input.createdAt, 'pAgentResponse.createdAt');

  return freezeResult({
    schemaVersion: 1,
    responseId,
    intentId,
    responderRef,
    responseType,
    payload,
    disclosureScope,
    status,
    createdAt,
  });
}

module.exports = { validatePAgentIntent, validatePAgentResponse };
