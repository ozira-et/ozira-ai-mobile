'use strict';

// Canonical cross-client Assistant run envelope. This is deliberately a
// contract, not a database client: Website, Mobile, Desktop, and adapters
// must all be able to validate the same durable state.
const {
  contractError, isPlainObject, assertNoSecretFields, requireId,
  requireString, requireEnum, requireTimestamp, optionalId,
} = require('./validation');

const RUN_STATUSES = Object.freeze([
  'queued', 'running', 'awaiting_approval', 'completed', 'failed',
  'cancelled', 'denied',
]);
const STATE_FIELDS = new Set([
  'contextSnapshot', 'memoryScope', 'fileReferences', 'modelRouteHistory',
  'toolState', 'checkpoint', 'pendingAction', 'approvalState',
  'costMetadata', 'outcome', 'auditMetadata',
]);

function objectOrNull(value, field) {
  if (value === undefined || value === null) return null;
  if (!isPlainObject(value)) throw contractError(field + ' must be an object.', 'FIELD_INVALID', field);
  return value;
}

function arrayOrEmpty(value, field) {
  if (value === undefined || value === null) return [];
  if (!Array.isArray(value)) throw contractError(field + ' must be an array.', 'FIELD_INVALID', field);
  if (value.length > 200) throw contractError(field + ' has too many entries.', 'PAYLOAD_TOO_LARGE', field);
  return value;
}

function validatePersistentRun(input) {
  if (!isPlainObject(input)) throw contractError('persistentRun must be an object.', 'FIELD_REQUIRED', 'persistentRun');
  const runId = requireId(input.runId, 'persistentRun.runId');
  const userId = requireId(input.userId, 'persistentRun.userId');
  const conversationId = optionalId(input.conversationId, 'persistentRun.conversationId');
  const objective = requireString(input.objective, 'persistentRun.objective', { min: 1, max: 2000 });
  const runStatus = requireEnum(input.runStatus, 'persistentRun.runStatus', RUN_STATUSES);
  if (!Number.isSafeInteger(input.stateVersion) || input.stateVersion < 0) {
    throw contractError('persistentRun.stateVersion must be a non-negative integer.', 'FIELD_INVALID', 'persistentRun.stateVersion');
  }
  const createdAt = requireTimestamp(input.createdAt, 'persistentRun.createdAt');
  const updatedAt = requireTimestamp(input.updatedAt, 'persistentRun.updatedAt');
  const state = {};
  for (const field of STATE_FIELDS) {
    if (field === 'fileReferences' || field === 'modelRouteHistory') state[field] = arrayOrEmpty(input[field], 'persistentRun.' + field);
    else state[field] = objectOrNull(input[field], 'persistentRun.' + field);
  }
  assertNoSecretFields(state, 'persistentRun.state');
  return Object.freeze({
    schemaVersion: 1, runId, userId, ...(conversationId ? { conversationId } : {}),
    objective, runStatus, stateVersion: input.stateVersion, ...state, createdAt, updatedAt,
  });
}

module.exports = { RUN_STATUSES, validatePersistentRun };
