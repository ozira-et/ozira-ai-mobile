'use strict';

// ConnectorExecution — canonical tracking contract for trusted external
// connector side effects (Calendar, Email, Drive, Slack, ...). Deliberately
// provider-neutral: no Google-specific fields, no OAuth tokens. This is a
// CONTRACT only — no connector runtime, credential broker, or provider call
// exists yet (see docs/architecture.md, "Connectors — out of scope").
//
// Untrusted-code sandbox execution (services/execution-runner) and trusted
// connector execution (this contract) are different security domains. This
// contract must never be used to describe sandbox command execution, and a
// sandbox result must never be projected into a ConnectorExecution.

const {
  requireString, optionalString, requireEnum, optionalPlainObject,
  requireTimestamp, optionalTimestamp, onlyKeys, freezeResult, contractError, ID_PATTERN,
} = require('./validation');
const { CONNECTOR_STATUSES } = require('./enums');

const IDEMPOTENCY_KEY_PATTERN = /^[A-Za-z0-9._:-]{8,160}$/;
const CONNECTOR_TYPE_PATTERN = /^[a-z][a-z0-9_]{1,60}$/;
const CAPABILITY_PATTERN = /^[A-Z][A-Z0-9_]{1,60}$/;

const ALLOWED_FIELDS = new Set([
  'schemaVersion', 'connectorExecutionId', 'actionId', 'connectorType', 'capability', 'status',
  'externalReference', 'idempotencyKey', 'resultMetadata', 'error', 'createdAt', 'completedAt',
]);

function validateConnectorError(value, field) {
  if (value === undefined || value === null) return undefined;
  if (typeof value !== 'object' || Array.isArray(value)) throw contractError(field + ' must be an object.', 'FIELD_INVALID', field);
  onlyKeys(value, new Set(['code', 'message']), field);
  return {
    code: requireString(value.code, field + '.code', { min: 1, max: 120, pattern: /^[A-Za-z0-9_.:-]+$/ }),
    ...(value.message !== undefined ? { message: requireString(value.message, field + '.message', { min: 0, max: 2000 }) } : {}),
  };
}

function validateConnectorExecution(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw contractError('ConnectorExecution is required and must be an object.', 'FIELD_REQUIRED', 'connectorExecution');
  }
  onlyKeys(input, ALLOWED_FIELDS, 'connectorExecution');
  const schemaVersion = input.schemaVersion == null ? 1 : input.schemaVersion;
  if (schemaVersion !== 1) throw contractError('Unsupported ConnectorExecution schemaVersion.', 'SCHEMA_VERSION_UNSUPPORTED', 'connectorExecution.schemaVersion');

  const connectorExecutionId = requireString(input.connectorExecutionId, 'connectorExecution.connectorExecutionId', { min: 6, max: 200, pattern: ID_PATTERN });
  const actionId = requireString(input.actionId, 'connectorExecution.actionId', { min: 6, max: 200, pattern: ID_PATTERN });
  const connectorType = requireString(input.connectorType, 'connectorExecution.connectorType', { min: 2, max: 60, pattern: CONNECTOR_TYPE_PATTERN });
  const capability = requireString(input.capability, 'connectorExecution.capability', { min: 2, max: 60, pattern: CAPABILITY_PATTERN });
  const status = requireEnum(input.status, 'connectorExecution.status', CONNECTOR_STATUSES);
  const externalReference = optionalString(input.externalReference, 'connectorExecution.externalReference', { min: 1, max: 300 });
  if (status === 'PENDING' && externalReference !== undefined) {
    throw contractError('connectorExecution.externalReference must be absent while status is PENDING.', 'FIELD_INVALID', 'connectorExecution.externalReference');
  }
  const idempotencyKey = requireString(input.idempotencyKey, 'connectorExecution.idempotencyKey', { min: 8, max: 160, pattern: IDEMPOTENCY_KEY_PATTERN });
  const resultMetadata = optionalPlainObject(input.resultMetadata, 'connectorExecution.resultMetadata', { maxKeys: 64 });
  const error = validateConnectorError(input.error, 'connectorExecution.error');
  const createdAt = requireTimestamp(input.createdAt, 'connectorExecution.createdAt');
  const completedAt = optionalTimestamp(input.completedAt, 'connectorExecution.completedAt');

  return freezeResult({
    schemaVersion: 1,
    connectorExecutionId,
    actionId,
    connectorType,
    capability,
    status,
    ...(externalReference !== undefined ? { externalReference } : {}),
    idempotencyKey,
    ...(resultMetadata !== undefined ? { resultMetadata } : {}),
    ...(error !== undefined ? { error } : {}),
    createdAt,
    ...(completedAt !== undefined ? { completedAt } : {}),
  });
}

module.exports = { validateConnectorExecution };
