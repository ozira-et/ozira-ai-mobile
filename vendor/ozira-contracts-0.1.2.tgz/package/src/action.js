'use strict';

// ActionRequest / ActionResult / AuthorityDecision — the generalized shape of
// the pattern already proven by the OZIRA Code execution control plane:
//   request -> policy -> authority -> approval -> durable queue -> worker ->
//   authoritative result -> audit
//
// ActionRequest generalizes "run a command" to "perform an authorized
// action" without requiring Code (or any other product) to change its
// internal representation — see src/adapters/execution.js for how Code's
// existing execution rows map onto these contracts.
//
// IMPORTANT: a structurally valid ActionRequest is not a trusted one. Policy
// and authority evaluation happen after validation, never instead of it.
// `payload` here is the same "data, never instructions" boundary documented
// throughout OZIRA: it may only be interpreted by the module authorized to
// act on this specific actionType.

const {
  requireString, optionalString, requireEnum, requireTimestamp, optionalTimestamp,
  requirePlainObject, optionalPlainObject, requireBoolean, onlyKeys, freezeResult, contractError, ID_PATTERN,
} = require('./validation');
const { SOURCES, AUTHORITY_LEVELS, AUTHORITY_DECISIONS, ACTION_STATUSES } = require('./enums');
const { validatePrincipal } = require('./principal');

const IDEMPOTENCY_KEY_PATTERN = /^[A-Za-z0-9._:-]{8,160}$/;
const ACTION_TYPE_PATTERN = /^[a-z][a-z0-9.:_-]{2,80}$/;

// -------------------------------------------------------------------------
// ActionRequest
// -------------------------------------------------------------------------

const ACTION_REQUEST_FIELDS = new Set([
  'schemaVersion', 'actionId', 'actionType', 'source', 'principal', 'authorityRequired',
  'payload', 'idempotencyKey', 'correlationId', 'causationId', 'createdAt', 'expiresAt',
]);

function validateActionRequest(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw contractError('ActionRequest is required and must be an object.', 'FIELD_REQUIRED', 'actionRequest');
  }
  onlyKeys(input, ACTION_REQUEST_FIELDS, 'actionRequest');
  const schemaVersion = input.schemaVersion == null ? 1 : input.schemaVersion;
  if (schemaVersion !== 1) throw contractError('Unsupported ActionRequest schemaVersion.', 'SCHEMA_VERSION_UNSUPPORTED', 'actionRequest.schemaVersion');

  const actionId = requireString(input.actionId, 'actionRequest.actionId', { min: 6, max: 200, pattern: ID_PATTERN });
  const actionType = requireString(input.actionType, 'actionRequest.actionType', { min: 3, max: 80, pattern: ACTION_TYPE_PATTERN });
  const source = requireEnum(input.source, 'actionRequest.source', SOURCES);
  const principal = validatePrincipal(input.principal);
  const authorityRequired = requireEnum(input.authorityRequired, 'actionRequest.authorityRequired', AUTHORITY_LEVELS);
  const payload = requirePlainObject(input.payload, 'actionRequest.payload', { maxKeys: 128 });
  const idempotencyKey = requireString(input.idempotencyKey, 'actionRequest.idempotencyKey', { min: 8, max: 160, pattern: IDEMPOTENCY_KEY_PATTERN });
  const correlationId = optionalString(input.correlationId, 'actionRequest.correlationId', { min: 1, max: 200, pattern: ID_PATTERN });
  const causationId = optionalString(input.causationId, 'actionRequest.causationId', { min: 1, max: 200, pattern: ID_PATTERN });
  const createdAt = requireTimestamp(input.createdAt, 'actionRequest.createdAt');
  const expiresAt = optionalTimestamp(input.expiresAt, 'actionRequest.expiresAt');
  if (expiresAt !== undefined && Date.parse(expiresAt) <= Date.parse(createdAt)) {
    throw contractError('actionRequest.expiresAt must be after createdAt.', 'FIELD_INVALID', 'actionRequest.expiresAt');
  }

  return freezeResult({
    schemaVersion: 1,
    actionId,
    actionType,
    source,
    principal,
    authorityRequired,
    payload,
    idempotencyKey,
    ...(correlationId !== undefined ? { correlationId } : {}),
    ...(causationId !== undefined ? { causationId } : {}),
    createdAt,
    ...(expiresAt !== undefined ? { expiresAt } : {}),
  });
}

// -------------------------------------------------------------------------
// ActionResult
// -------------------------------------------------------------------------

const ACTION_RESULT_FIELDS = new Set([
  'schemaVersion', 'actionId', 'status', 'result', 'error', 'startedAt', 'completedAt',
  'correlationId', 'authoritativeSource',
]);

function validateActionError(value, field) {
  if (value === undefined || value === null) return undefined;
  if (typeof value !== 'object' || Array.isArray(value)) throw contractError(field + ' must be an object.', 'FIELD_INVALID', field);
  onlyKeys(value, new Set(['code', 'message']), field);
  return {
    code: requireString(value.code, field + '.code', { min: 1, max: 120, pattern: /^[A-Za-z0-9_.:-]+$/ }),
    ...(value.message !== undefined ? { message: requireString(value.message, field + '.message', { min: 0, max: 2000 }) } : {}),
  };
}

function validateActionResult(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw contractError('ActionResult is required and must be an object.', 'FIELD_REQUIRED', 'actionResult');
  }
  onlyKeys(input, ACTION_RESULT_FIELDS, 'actionResult');
  const schemaVersion = input.schemaVersion == null ? 1 : input.schemaVersion;
  if (schemaVersion !== 1) throw contractError('Unsupported ActionResult schemaVersion.', 'SCHEMA_VERSION_UNSUPPORTED', 'actionResult.schemaVersion');

  const actionId = requireString(input.actionId, 'actionResult.actionId', { min: 6, max: 200, pattern: ID_PATTERN });
  const status = requireEnum(input.status, 'actionResult.status', ACTION_STATUSES);
  const result = optionalPlainObject(input.result, 'actionResult.result', { maxKeys: 128 });
  const error = validateActionError(input.error, 'actionResult.error');
  const startedAt = optionalTimestamp(input.startedAt, 'actionResult.startedAt');
  const completedAt = optionalTimestamp(input.completedAt, 'actionResult.completedAt');
  const correlationId = optionalString(input.correlationId, 'actionResult.correlationId', { min: 1, max: 200, pattern: ID_PATTERN });
  const authoritativeSource = optionalString(input.authoritativeSource, 'actionResult.authoritativeSource', { min: 1, max: 120 });

  return freezeResult({
    schemaVersion: 1,
    actionId,
    status,
    ...(result !== undefined ? { result } : {}),
    ...(error !== undefined ? { error } : {}),
    ...(startedAt !== undefined ? { startedAt } : {}),
    ...(completedAt !== undefined ? { completedAt } : {}),
    ...(correlationId !== undefined ? { correlationId } : {}),
    ...(authoritativeSource !== undefined ? { authoritativeSource } : {}),
  });
}

// -------------------------------------------------------------------------
// AuthorityDecision
// -------------------------------------------------------------------------

const AUTHORITY_DECISION_FIELDS = new Set([
  'schemaVersion', 'actionId', 'requiredAuthority', 'decision', 'reason', 'requiresHumanApproval', 'policyVersion',
]);

function validateAuthorityDecision(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw contractError('AuthorityDecision is required and must be an object.', 'FIELD_REQUIRED', 'authorityDecision');
  }
  onlyKeys(input, AUTHORITY_DECISION_FIELDS, 'authorityDecision');
  const schemaVersion = input.schemaVersion == null ? 1 : input.schemaVersion;
  if (schemaVersion !== 1) throw contractError('Unsupported AuthorityDecision schemaVersion.', 'SCHEMA_VERSION_UNSUPPORTED', 'authorityDecision.schemaVersion');

  const actionId = requireString(input.actionId, 'authorityDecision.actionId', { min: 6, max: 200, pattern: ID_PATTERN });
  const requiredAuthority = requireEnum(input.requiredAuthority, 'authorityDecision.requiredAuthority', AUTHORITY_LEVELS);
  const decision = requireEnum(input.decision, 'authorityDecision.decision', AUTHORITY_DECISIONS);
  const reason = requireString(input.reason, 'authorityDecision.reason', { min: 1, max: 500 });
  const requiresHumanApproval = requireBoolean(input.requiresHumanApproval, 'authorityDecision.requiresHumanApproval');
  const policyVersion = optionalString(input.policyVersion, 'authorityDecision.policyVersion', { min: 1, max: 80 });

  if (decision === 'DENY' && requiresHumanApproval) {
    throw contractError('A denied action cannot also require human approval.', 'FIELD_INVALID', 'authorityDecision.requiresHumanApproval');
  }
  if (decision === 'REQUIRE_APPROVAL' && !requiresHumanApproval) {
    throw contractError('REQUIRE_APPROVAL decisions must set requiresHumanApproval to true.', 'FIELD_INVALID', 'authorityDecision.requiresHumanApproval');
  }

  return freezeResult({
    schemaVersion: 1,
    actionId,
    requiredAuthority,
    decision,
    reason,
    requiresHumanApproval,
    ...(policyVersion !== undefined ? { policyVersion } : {}),
  });
}

module.exports = { validateActionRequest, validateActionResult, validateAuthorityDecision };
