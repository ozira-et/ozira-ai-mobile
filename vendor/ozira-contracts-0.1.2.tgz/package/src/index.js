'use strict';

// ozira-contracts — canonical, versioned, runtime-validated contracts shared
// across every OZIRA product experience and the OZIRA AI Operating Platform.
//
// This package contains ONLY pure validation functions and enumerations. No
// infrastructure, no database client, no network calls, no provider SDK, no
// secrets. See docs/architecture.md for the full contract catalog, trust
// rules, and versioning strategy.

const { ContractError, contractError } = require('./validation');
const enums = require('./enums');
const { validatePrincipal } = require('./principal');
const { validateEventEnvelope } = require('./event');
const { validateActionRequest, validateActionResult, validateAuthorityDecision } = require('./action');
const { validateApprovalRequest } = require('./approval');
const { validateToolInvocation, validateToolResult } = require('./tool');
const { validateResponseCard, RESPONSE_CARD_TYPES, RESPONSE_CARD_LIFECYCLES, RESPONSE_CARD_ACTIONS } = require('./responseCard');
const { validateConnectorExecution } = require('./connector');
const { validateAuditEvent } = require('./audit');
const { validateNotification } = require('./notification');
const { validatePersistentRun, RUN_STATUSES } = require('./persistentRun');
const { validatePAgentIntent, validatePAgentResponse } = require('./p2p');
const {
  validateHQSignal, validateHQMetric, validateHQRisk, validateHQOpportunity,
  validateHQRecommendation, validateHQDecisionRequest, validateHQDepartmentSnapshot, validateHQBrief,
} = require('./hq');

module.exports = {
  ...require('./responseCard'),
  ContractError,
  contractError,
  ...enums,
  validatePrincipal,
  validateEventEnvelope,
  validateActionRequest,
  validateActionResult,
  validateAuthorityDecision,
  validateApprovalRequest,
  validateToolInvocation,
  validateToolResult,
  validateResponseCard,
  RESPONSE_CARD_TYPES,
  RESPONSE_CARD_LIFECYCLES,
  RESPONSE_CARD_ACTIONS,
  validateConnectorExecution,
  validateAuditEvent,
  validateNotification,
  validatePersistentRun,
  RUN_STATUSES,
  validatePAgentIntent,
  validatePAgentResponse,
  validateHQSignal,
  validateHQMetric,
  validateHQRisk,
  validateHQOpportunity,
  validateHQRecommendation,
  validateHQDecisionRequest,
  validateHQDepartmentSnapshot,
  validateHQBrief,
};
