'use strict';

// Shared enumerations reused across multiple contracts. Kept in one place so
// "source" or "authority" mean the same thing everywhere they appear.

// Where an event/action originates. SYSTEM covers platform-internal actors
// (schedulers, reconciliation jobs) that are not a specific product surface.
const SOURCES = Object.freeze(['CHAT', 'CODE', 'COWORK', 'DESIGN', 'FORWARD', 'P', 'SYSTEM']);

// P authority scale (architectural invariant — see docs/architecture.md).
// Human remains the default authority for DECIDE unless explicitly delegated.
const AUTHORITY_LEVELS = Object.freeze(['OBSERVE', 'ORGANIZE', 'PREPARE', 'COMMUNICATE', 'EXECUTE', 'DECIDE']);

const AUTHORITY_DECISIONS = Object.freeze(['ALLOW', 'REQUIRE_APPROVAL', 'DENY']);

// Normalized platform-wide result status. Deliberately smaller than Code's
// internal execution state machine (see docs/architecture.md — ActionResult
// is a projection, not a replacement, of richer internal lifecycle state).
const ACTION_STATUSES = Object.freeze(['PENDING', 'RUNNING', 'SUCCEEDED', 'FAILED', 'CANCELLED', 'TIMED_OUT', 'DENIED']);

const APPROVAL_STATUSES = Object.freeze(['PENDING', 'APPROVED', 'REJECTED', 'CANCELLED', 'EXPIRED']);

const TOOL_RESULT_STATUSES = Object.freeze(['SUCCEEDED', 'FAILED', 'DENIED', 'TIMED_OUT']);

const CONNECTOR_STATUSES = Object.freeze(['PENDING', 'RUNNING', 'SUCCEEDED', 'FAILED', 'CANCELLED']);

const AUDIT_OUTCOMES = Object.freeze(['SUCCESS', 'FAILURE', 'DENIED', 'PENDING']);

const NOTIFICATION_URGENCY = Object.freeze(['CRITICAL', 'IMPORTANT', 'NORMAL', 'SILENT']);

const NOTIFICATION_STATUSES = Object.freeze(['PENDING', 'SENT', 'READ', 'DISMISSED']);

const SUBJECT_TYPES = Object.freeze(['USER', 'AGENT', 'SYSTEM', 'SERVICE']);

const P2P_INTENT_STATUSES = Object.freeze(['PENDING', 'RESPONDED', 'EXPIRED', 'CANCELLED']);

const P2P_RESPONSE_STATUSES = Object.freeze(['PROVISIONAL', 'FINAL']);

// Minimum-necessary-disclosure principle: a P-to-P envelope declares how much
// context it carries. MINIMAL is the only scope intended for real use in
// Phase 1-era negotiation; NONE is for pure status pings with no payload.
const DISCLOSURE_SCOPES = Object.freeze(['NONE', 'MINIMAL']);

// HQ-0 (company intelligence) enums. HQ reuses AUTHORITY_LEVELS/SOURCES
// above rather than inventing parallel ones — these are HQ-specific
// additions only. See docs/architecture.md "HQ contracts" for the full
// rationale (Phase HQ-0).
const HQ_DEPARTMENTS = Object.freeze([
  'CEO', 'FINANCE', 'ACCOUNTING', 'OPERATIONS', 'ENGINEERING',
  'SECURITY', 'SUPPORT', 'PRODUCT', 'GROWTH', 'ADMIN',
]);

// Explicit context categories (§41 of the HQ-0 program). HQ cannot
// automatically consume PERSONAL-scoped data — see hqContextPolicy in
// packages/ozira-hq-runtime for the enforcement point; this enum only
// declares the vocabulary every HQ contract's contextScope field draws from.
const HQ_CONTEXT_SCOPES = Object.freeze([
  'PERSONAL', 'COMPANY_INTERNAL', 'COMPANY_CONFIDENTIAL',
  'FINANCIAL', 'SECURITY', 'CUSTOMER_PRIVATE',
]);

const HQ_SEVERITY_LEVELS = Object.freeze(['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO']);

const HQ_SIGNAL_CATEGORIES = Object.freeze(['METRIC', 'RISK', 'OPPORTUNITY', 'EVENT']);

const HQ_DECISION_STATUSES = Object.freeze(['PENDING', 'REVIEWED', 'APPROVED', 'REJECTED', 'DEFERRED', 'EXPIRED']);

// A department head that fails must say so, never fabricate health (§75).
const HQ_DEPARTMENT_STATUSES = Object.freeze(['HEALTHY', 'DEGRADED', 'UNAVAILABLE']);

module.exports = {
  SOURCES,
  AUTHORITY_LEVELS,
  AUTHORITY_DECISIONS,
  ACTION_STATUSES,
  APPROVAL_STATUSES,
  TOOL_RESULT_STATUSES,
  CONNECTOR_STATUSES,
  AUDIT_OUTCOMES,
  NOTIFICATION_URGENCY,
  NOTIFICATION_STATUSES,
  SUBJECT_TYPES,
  P2P_INTENT_STATUSES,
  P2P_RESPONSE_STATUSES,
  DISCLOSURE_SCOPES,
  HQ_DEPARTMENTS,
  HQ_CONTEXT_SCOPES,
  HQ_SEVERITY_LEVELS,
  HQ_SIGNAL_CATEGORIES,
  HQ_DECISION_STATUSES,
  HQ_DEPARTMENT_STATUSES,
};
