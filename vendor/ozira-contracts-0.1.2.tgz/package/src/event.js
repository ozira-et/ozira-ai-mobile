'use strict';

// EventEnvelope — the future cross-product event contract. This phase only
// defines the shape; no event bus or transport is introduced (see
// docs/architecture.md, "Event architecture — out of scope").

const {
  requireString, optionalString, requireEnum, requireTimestamp, requirePlainObject,
  onlyKeys, freezeResult, contractError, ID_PATTERN,
} = require('./validation');
const { SOURCES } = require('./enums');
const { validatePrincipal } = require('./principal');

const ALLOWED_FIELDS = new Set([
  'schemaVersion', 'eventId', 'eventType', 'source', 'timestamp', 'principal',
  'correlationId', 'causationId', 'payload',
]);

function validateEventEnvelope(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw contractError('EventEnvelope is required and must be an object.', 'FIELD_REQUIRED', 'event');
  }
  onlyKeys(input, ALLOWED_FIELDS, 'event');
  const schemaVersion = input.schemaVersion == null ? 1 : input.schemaVersion;
  if (schemaVersion !== 1) throw contractError('Unsupported EventEnvelope schemaVersion.', 'SCHEMA_VERSION_UNSUPPORTED', 'event.schemaVersion');

  const eventId = requireString(input.eventId, 'event.eventId', { min: 6, max: 200, pattern: ID_PATTERN });
  const eventType = requireString(input.eventType, 'event.eventType', { min: 1, max: 120, pattern: /^[a-z][a-z0-9.:_-]*$/ });
  const source = requireEnum(input.source, 'event.source', SOURCES);
  const timestamp = requireTimestamp(input.timestamp, 'event.timestamp');
  const principal = input.principal === undefined ? undefined : validatePrincipal(input.principal);
  const correlationId = optionalString(input.correlationId, 'event.correlationId', { min: 1, max: 200, pattern: ID_PATTERN });
  const causationId = optionalString(input.causationId, 'event.causationId', { min: 1, max: 200, pattern: ID_PATTERN });
  const payload = requirePlainObject(input.payload, 'event.payload', { maxKeys: 64 });

  return freezeResult({
    schemaVersion: 1,
    eventId,
    eventType,
    source,
    timestamp,
    ...(principal !== undefined ? { principal } : {}),
    ...(correlationId !== undefined ? { correlationId } : {}),
    ...(causationId !== undefined ? { causationId } : {}),
    payload,
  });
}

module.exports = { validateEventEnvelope };
