'use strict';

// AuditEvent — one shared audit envelope, designed so Code execution audit,
// P action audit, connector audit, and approval audit can eventually share
// it. Phase 1 defines the contract only; existing audit tables (store.audit_
// events, runner audit, execution.* audit rows) are NOT migrated (see
// docs/architecture.md, "Audit model convergence — contract only").

const {
  requireString, optionalString, requireEnum, optionalPlainObject,
  requireTimestamp, onlyKeys, freezeResult, contractError, ID_PATTERN,
} = require('./validation');
const { AUDIT_OUTCOMES } = require('./enums');
const { validatePrincipal } = require('./principal');

const ALLOWED_FIELDS = new Set([
  'schemaVersion', 'auditId', 'eventType', 'principal', 'actionId', 'invocationId',
  'correlationId', 'timestamp', 'outcome', 'metadata',
]);

function validateAuditEvent(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw contractError('AuditEvent is required and must be an object.', 'FIELD_REQUIRED', 'auditEvent');
  }
  onlyKeys(input, ALLOWED_FIELDS, 'auditEvent');
  const schemaVersion = input.schemaVersion == null ? 1 : input.schemaVersion;
  if (schemaVersion !== 1) throw contractError('Unsupported AuditEvent schemaVersion.', 'SCHEMA_VERSION_UNSUPPORTED', 'auditEvent.schemaVersion');

  const auditId = requireString(input.auditId, 'auditEvent.auditId', { min: 6, max: 200, pattern: ID_PATTERN });
  const eventType = requireString(input.eventType, 'auditEvent.eventType', { min: 1, max: 120, pattern: /^[a-z][a-z0-9.:_-]*$/ });
  const principal = validatePrincipal(input.principal);
  const actionId = optionalString(input.actionId, 'auditEvent.actionId', { min: 6, max: 200, pattern: ID_PATTERN });
  const invocationId = optionalString(input.invocationId, 'auditEvent.invocationId', { min: 6, max: 200, pattern: ID_PATTERN });
  const correlationId = optionalString(input.correlationId, 'auditEvent.correlationId', { min: 1, max: 200, pattern: ID_PATTERN });
  const timestamp = requireTimestamp(input.timestamp, 'auditEvent.timestamp');
  const outcome = requireEnum(input.outcome, 'auditEvent.outcome', AUDIT_OUTCOMES);
  const metadata = optionalPlainObject(input.metadata, 'auditEvent.metadata', { maxKeys: 64 });

  return freezeResult({
    schemaVersion: 1,
    auditId,
    eventType,
    principal,
    ...(actionId !== undefined ? { actionId } : {}),
    ...(invocationId !== undefined ? { invocationId } : {}),
    ...(correlationId !== undefined ? { correlationId } : {}),
    timestamp,
    outcome,
    ...(metadata !== undefined ? { metadata } : {}),
  });
}

module.exports = { validateAuditEvent };
