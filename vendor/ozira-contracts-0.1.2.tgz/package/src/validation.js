'use strict';

// Shared, dependency-free runtime validation for every OZIRA contract.
//
// No network calls, no database lookups, no infrastructure. Every function
// here is a pure check: it either returns a normalized value or throws a
// ContractError. Validating a contract makes its SHAPE trustworthy — it never
// makes the CONTENT of a payload trustworthy. Payload/input/output/metadata
// fields carried by these contracts are data, not instructions, regardless of
// how strictly the envelope around them validates.

class ContractError extends Error {
  constructor(message, code, field) {
    super(message);
    this.name = 'ContractError';
    this.code = code || 'CONTRACT_INVALID';
    this.field = field || null;
  }
}

function contractError(message, code, field) {
  return new ContractError(message, code, field);
}

function iso(value) {
  return new Date(value == null ? Date.now() : value).toISOString();
}

function isPlainObject(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
}

// ---------------------------------------------------------------------------
// Secret-safety guard. A shared contract must never intentionally carry raw
// credential material. This is a narrow, exact-name + value-shape guard, not
// a general privacy filter (P-to-P minimum disclosure is enforced separately
// and structurally in p2p.js). A reference field such as `credentialRef` or
// `providerReference` normalizes to a name that is NOT on this list and is
// allowed through — only the raw material itself is rejected.
// ---------------------------------------------------------------------------

const FORBIDDEN_KEY_NAMES = new Set([
  'accesstoken', 'refreshtoken', 'oauthtoken', 'idtoken', 'sessiontoken',
  'bearertoken', 'authtoken', 'authorization', 'clientsecret', 'privatekey',
  'password', 'passwd', 'servicerole', 'servicerolekey', 'apisecret',
  'apikey', 'secretkey', 'secretvalue', 'tokenvalue', 'credentialvalue',
  'token', 'secret', 'credential', 'credentials', 'dbpassword',
  'databasepassword', 'connectionstring', 'privatekeyvalue',
]);

const SECRET_VALUE_PATTERNS = Object.freeze([
  /\bsk-(?:proj-)?[A-Za-z0-9_-]{16,}\b/,
  /\bsb_secret_[A-Za-z0-9_-]{12,}\b/,
  /\bgh[pousr]_[A-Za-z0-9]{20,}\b/,
  /-----BEGIN [A-Z ]*PRIVATE KEY-----/,
  /\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b/,
  /\bAKIA[0-9A-Z]{16}\b/,
  /^Bearer\s+\S+/i,
  /:\/\/[^/\s:]+:[^/\s@]+@/,
]);

const MAX_PAYLOAD_DEPTH = 6;
const MAX_PAYLOAD_ARRAY_LENGTH = 200;
const MAX_PAYLOAD_SERIALIZED_BYTES = 64 * 1024;

function normalizedKeyName(key) {
  return String(key).replace(/[^a-zA-Z]/g, '').toLowerCase();
}

function walkForSecrets(node, path, depth) {
  if (depth > MAX_PAYLOAD_DEPTH) {
    throw contractError('Payload is nested too deeply.', 'PAYLOAD_TOO_DEEP', path);
  }
  if (Array.isArray(node)) {
    if (node.length > MAX_PAYLOAD_ARRAY_LENGTH) {
      throw contractError('Payload array is too large.', 'PAYLOAD_TOO_LARGE', path);
    }
    node.forEach((item, index) => walkForSecrets(item, path + '[' + index + ']', depth + 1));
    return;
  }
  if (node && typeof node === 'object') {
    for (const [key, value] of Object.entries(node)) {
      if (FORBIDDEN_KEY_NAMES.has(normalizedKeyName(key))) {
        throw contractError(
          'Field "' + key + '" may not appear in a shared OZIRA contract payload.',
          'SECRET_FIELD_REJECTED',
          path + '.' + key,
        );
      }
      walkForSecrets(value, path + '.' + key, depth + 1);
    }
    return;
  }
  if (typeof node === 'string' && SECRET_VALUE_PATTERNS.some(pattern => pattern.test(node))) {
    throw contractError(
      'A value in "' + path + '" looks like raw secret material and may not appear in a shared OZIRA contract.',
      'SECRET_VALUE_REJECTED',
      path,
    );
  }
}

function assertNoSecretFields(value, field) {
  if (value == null) return;
  let serializedLength = 0;
  try { serializedLength = JSON.stringify(value).length; } catch (_) {
    throw contractError(field + ' must be JSON-serializable.', 'PAYLOAD_INVALID', field);
  }
  if (serializedLength > MAX_PAYLOAD_SERIALIZED_BYTES) {
    throw contractError(field + ' exceeds the maximum contract payload size.', 'PAYLOAD_TOO_LARGE', field);
  }
  walkForSecrets(value, field, 0);
}

// ---------------------------------------------------------------------------
// Primitive validators
// ---------------------------------------------------------------------------

function requireString(value, field, options) {
  options ||= {};
  const min = options.min == null ? 1 : options.min;
  const max = options.max == null ? 500 : options.max;
  if (typeof value !== 'string') throw contractError(field + ' is required and must be a string.', 'FIELD_REQUIRED', field);
  if (/[\x00\r\n]/.test(value)) throw contractError(field + ' must not contain control characters.', 'FIELD_INVALID', field);
  const bytes = Array.from(value).reduce((n, char) => { const c = char.codePointAt(0); return n + (c <= 127 ? 1 : c <= 2047 ? 2 : c <= 65535 ? 3 : 4); }, 0);
  if (value.length < min || bytes > max) {
    throw contractError(field + ' must be between ' + min + ' and ' + max + ' characters.', 'FIELD_INVALID', field);
  }
  if (options.pattern && !options.pattern.test(value)) {
    throw contractError(field + ' has an invalid format.', 'FIELD_INVALID', field);
  }
  return value;
}

function optionalString(value, field, options) {
  if (value === undefined || value === null) return undefined;
  return requireString(value, field, options);
}

const ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9_.:-]{5,199}$/;

function requireId(value, field, options) {
  options ||= {};
  return requireString(value, field, { min: options.min || 6, max: options.max || 200, pattern: options.pattern || ID_PATTERN });
}

function optionalId(value, field, options) {
  if (value === undefined || value === null) return undefined;
  return requireId(value, field, options);
}

function requireEnum(value, field, allowed) {
  if (typeof value !== 'string' || !allowed.includes(value)) {
    throw contractError(field + ' must be one of: ' + allowed.join(', ') + '.', 'FIELD_INVALID', field);
  }
  return value;
}

function optionalEnum(value, field, allowed) {
  if (value === undefined || value === null) return undefined;
  return requireEnum(value, field, allowed);
}

function requireBoolean(value, field) {
  if (typeof value !== 'boolean') throw contractError(field + ' must be a boolean.', 'FIELD_INVALID', field);
  return value;
}

function optionalBoolean(value, field) {
  if (value === undefined || value === null) return undefined;
  return requireBoolean(value, field);
}

function requireTimestamp(value, field) {
  if (typeof value !== 'string' || !Number.isFinite(Date.parse(value))) {
    throw contractError(field + ' must be an ISO-8601 timestamp string.', 'FIELD_INVALID', field);
  }
  return value;
}

function optionalTimestamp(value, field) {
  if (value === undefined || value === null) return undefined;
  return requireTimestamp(value, field);
}

function requirePlainObject(value, field, options) {
  options ||= {};
  if (!isPlainObject(value)) throw contractError(field + ' must be a plain object.', 'FIELD_INVALID', field);
  const maxKeys = options.maxKeys || 64;
  if (Object.keys(value).length > maxKeys) throw contractError(field + ' has too many keys.', 'FIELD_INVALID', field);
  if (options.guardSecrets !== false) assertNoSecretFields(value, field);
  return value;
}

function optionalPlainObject(value, field, options) {
  if (value === undefined || value === null) return undefined;
  return requirePlainObject(value, field, options);
}

function requireArray(value, field, options) {
  options ||= {};
  const max = options.max || 50;
  if (!Array.isArray(value)) throw contractError(field + ' must be an array.', 'FIELD_INVALID', field);
  if (value.length > max) throw contractError(field + ' has too many entries.', 'FIELD_INVALID', field);
  return value;
}

function optionalArray(value, field, options) {
  if (value === undefined || value === null) return undefined;
  return requireArray(value, field, options);
}

function onlyKeys(value, allowed, field) {
  const extra = Object.keys(value).filter(key => !allowed.has(key));
  if (extra.length) {
    throw contractError(field + ' contains unsupported field(s): ' + extra.join(', ') + '.', 'FIELD_UNSUPPORTED', field);
  }
}

function freezeResult(value) {
  return Object.freeze(value);
}

module.exports = {
  ContractError,
  contractError,
  iso,
  isPlainObject,
  assertNoSecretFields,
  requireString,
  optionalString,
  requireId,
  optionalId,
  requireEnum,
  optionalEnum,
  requireBoolean,
  optionalBoolean,
  requireTimestamp,
  optionalTimestamp,
  requirePlainObject,
  optionalPlainObject,
  requireArray,
  optionalArray,
  onlyKeys,
  freezeResult,
  ID_PATTERN,
  FORBIDDEN_KEY_NAMES,
  SECRET_VALUE_PATTERNS,
};
