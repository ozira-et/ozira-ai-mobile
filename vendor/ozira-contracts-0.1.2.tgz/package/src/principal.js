'use strict';

// Principal — canonical identity/security context threaded through every
// OZIRA platform action. Never carries authentication material: the field
// allowlist below makes it structurally impossible for a token/secret field
// to survive validation, whether or not it was supplied.

const { requireString, optionalString, requireEnum, onlyKeys, freezeResult, contractError, ID_PATTERN } = require('./validation');
const { SUBJECT_TYPES } = require('./enums');

const ALLOWED_FIELDS = new Set(['schemaVersion', 'principalId', 'subjectType', 'tenantId', 'workspaceId', 'role']);

function validatePrincipal(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw contractError('Principal is required and must be an object.', 'FIELD_REQUIRED', 'principal');
  }
  onlyKeys(input, ALLOWED_FIELDS, 'principal');
  const schemaVersion = input.schemaVersion == null ? 1 : input.schemaVersion;
  if (schemaVersion !== 1) throw contractError('Unsupported principal schemaVersion.', 'SCHEMA_VERSION_UNSUPPORTED', 'principal.schemaVersion');

  const principalId = requireString(input.principalId, 'principal.principalId', { min: 1, max: 200, pattern: ID_PATTERN });
  const subjectType = requireEnum(input.subjectType, 'principal.subjectType', SUBJECT_TYPES);
  // tenantId/workspaceId are NOT restricted to ID_PATTERN: several existing
  // OZIRA surfaces (e.g. Code's execution.projectId) accept user-supplied
  // text rather than an internally generated id shape. Bounded length and no
  // control characters is the honest floor Code can already guarantee.
  const tenantId = optionalString(input.tenantId, 'principal.tenantId', { min: 1, max: 200 });
  const workspaceId = optionalString(input.workspaceId, 'principal.workspaceId', { min: 1, max: 200 });
  const role = optionalString(input.role, 'principal.role', { min: 1, max: 40 });

  return freezeResult({
    schemaVersion: 1,
    principalId,
    subjectType,
    ...(tenantId !== undefined ? { tenantId } : {}),
    ...(workspaceId !== undefined ? { workspaceId } : {}),
    ...(role !== undefined ? { role } : {}),
  });
}

module.exports = { validatePrincipal };
