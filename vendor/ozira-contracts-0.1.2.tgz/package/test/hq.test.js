'use strict';
/* Proves the eight HQ-0 contracts: shape validation, enum enforcement,
 * contextScope requirement, and the shared secret-safety guard.
 * Run: node test/hq.test.js   (zero dependencies) */

const assert = require('assert');
const {
  validateHQSignal, validateHQMetric, validateHQRisk, validateHQOpportunity,
  validateHQRecommendation, validateHQDecisionRequest, validateHQDepartmentSnapshot,
  validateHQBrief, ContractError,
} = require('../src/index');

let pass = 0;
function test(name, fn) {
  try { fn(); console.log('  ok  ' + name); pass++; }
  catch (e) { console.error('FAIL  ' + name + '\n      ' + e.message); process.exitCode = 1; }
}

const now = new Date().toISOString();

test('HQSignal: valid signal passes and is frozen', () => {
  const signal = validateHQSignal({
    signalId: 'hqsig_finance_001', department: 'FINANCE', category: 'METRIC', severity: 'MEDIUM',
    title: 'AI spend up 40%', summary: 'AI cost rose 40% month over month.',
    evidenceRefs: ['hqmet_ai_cost_001'], contextScope: 'FINANCIAL', detectedAt: now,
  });
  assert.strictEqual(signal.department, 'FINANCE');
  assert.ok(Object.isFrozen(signal));
});

test('HQSignal: unknown department is rejected', () => {
  assert.throws(() => validateHQSignal({
    signalId: 'hqsig_x_000001', department: 'MARKETING', category: 'METRIC', severity: 'LOW',
    title: 't', summary: 's', contextScope: 'COMPANY_INTERNAL', detectedAt: now,
  }), ContractError);
});

test('HQSignal: missing contextScope is rejected (every HQ contract must declare it)', () => {
  assert.throws(() => validateHQSignal({
    signalId: 'hqsig_x_000002', department: 'PRODUCT', category: 'EVENT', severity: 'INFO',
    title: 't', summary: 's', detectedAt: now,
  }), ContractError);
});

test('HQMetric: valid metric with delta fields', () => {
  const metric = validateHQMetric({
    metricId: 'hqmet_ai_cost_001', department: 'FINANCE', name: 'ai_spend_usd', value: 14000,
    unit: 'usd', previousValue: 10000, changePct: 40, contextScope: 'FINANCIAL', asOf: now,
  });
  assert.strictEqual(metric.changePct, 40);
});

test('HQMetric: non-finite value is rejected', () => {
  assert.throws(() => validateHQMetric({
    metricId: 'hqmet_x_000001', department: 'FINANCE', name: 'x', value: NaN,
    contextScope: 'FINANCIAL', asOf: now,
  }), ContractError);
});

test('HQRisk: valid risk with likelihood/impact', () => {
  const risk = validateHQRisk({
    riskId: 'hqrisk_sec_000001', department: 'SECURITY', title: 'Stale IAM policy',
    description: 'A staging IAM policy has not been reviewed in 180 days.', severity: 'HIGH',
    likelihood: 'MEDIUM', impact: 'HIGH', contextScope: 'SECURITY', detectedAt: now,
  });
  assert.strictEqual(risk.severity, 'HIGH');
});

test('HQOpportunity: confidence must be within [0,1]', () => {
  assert.throws(() => validateHQOpportunity({
    opportunityId: 'hqopp_x_000001', department: 'GROWTH', title: 't', description: 'd',
    confidence: 1.5, contextScope: 'COMPANY_INTERNAL', detectedAt: now,
  }), ContractError);
  const opportunity = validateHQOpportunity({
    opportunityId: 'hqopp_growth_000001', department: 'GROWTH', title: 'Expand Amharic onboarding',
    description: 'Amharic activation outperforms other locales.', estimatedBenefit: '+8% activation',
    confidence: 0.7, contextScope: 'COMPANY_INTERNAL', detectedAt: now,
  });
  assert.strictEqual(opportunity.confidence, 0.7);
});

test('HQRecommendation: valid recommendation carries authority + approval flag', () => {
  const recommendation = validateHQRecommendation({
    recommendationId: 'hqrec_admin_000001', department: 'ADMIN', title: 'Route more chat to a cheaper model',
    problem: 'AI cost rose 25% with stable quality.', recommendedAction: 'Shift 20% of fast-tier traffic to a cheaper model.',
    alternatives: ['Do nothing', 'Raise prices instead'], riskLevel: 'LOW', confidence: 0.6,
    authorityRequired: 'PREPARE', approvalRequired: true, contextScope: 'COMPANY_INTERNAL', createdAt: now,
  });
  assert.strictEqual(recommendation.approvalRequired, true);
});

test('HQBrief: a raw secret-shaped value inside sections (a requirePlainObject field) is rejected by the shared guard', () => {
  assert.throws(() => validateHQBrief({
    briefId: 'hqbrief_x_000003', generatedAt: now,
    sections: { companyHealth: 'Key leaked: sk-proj-abcd1234efgh5678ijkl' },
    departmentStatuses: {}, contextScope: 'COMPANY_INTERNAL',
  }), ContractError);
});

test('HQDecisionRequest: valid decision card round-trips every §57 field', () => {
  const decision = validateHQDecisionRequest({
    decisionId: 'hqdec_finance_000001', title: 'Approve model-routing cost optimization',
    department: 'FINANCE', problem: 'AI cost pressure on margin.', evidence: ['hqmet_ai_cost_001'],
    impact: 'Projected 12% gross margin improvement.', urgency: 'MEDIUM',
    recommendedAction: 'Approve routing change proposal.', alternatives: ['Defer to next quarter'],
    estimatedCost: '~40 eng hours', estimatedBenefit: '~$3k/mo', riskLevel: 'LOW', confidence: 0.65,
    authorityRequired: 'PREPARE', approvalRequired: true, status: 'PENDING',
    supportingReferences: ['hqrec_admin_000001'], contextScope: 'FINANCIAL', createdAt: now,
  });
  assert.strictEqual(decision.status, 'PENDING');
});

test('HQDecisionRequest: DECIDE authority is structurally representable but never asserted by HQ-0 code (enforced in hqAuthority.js, not here)', () => {
  const decision = validateHQDecisionRequest({
    decisionId: 'hqdec_x_000001', title: 't', department: 'FINANCE', problem: 'p', impact: 'i',
    urgency: 'LOW', recommendedAction: 'a', riskLevel: 'LOW', confidence: 0.5,
    authorityRequired: 'DECIDE', approvalRequired: true, status: 'PENDING',
    contextScope: 'FINANCIAL', createdAt: now,
  });
  assert.strictEqual(decision.authorityRequired, 'DECIDE');
});

test('HQDepartmentSnapshot: DEGRADED status is representable (§75 — never fabricate health)', () => {
  const snapshot = validateHQDepartmentSnapshot({
    snapshotId: 'hqsnap_product_000001', department: 'PRODUCT', generatedAt: now, status: 'DEGRADED',
    confidence: 0.3, contextScope: 'COMPANY_INTERNAL', notes: 'ProductIntelligence timed out; using stale cache.',
  });
  assert.strictEqual(snapshot.status, 'DEGRADED');
});

test('HQBrief: valid brief with all seven §56 sections and department statuses', () => {
  const brief = validateHQBrief({
    briefId: 'hqbrief_000001', generatedAt: now,
    sections: {
      companyHealth: 'Stable.', finance: 'Margin pressure from AI cost.', product: 'Usage up.',
      infrastructure: 'Healthy.', security: 'No new findings.', support: 'Backlog steady.', growth: 'Amharic growing.',
    },
    departmentStatuses: { FINANCE: 'HEALTHY', PRODUCT: 'HEALTHY', SECURITY: 'HEALTHY' },
    riskRefs: ['hqrisk_sec_000001'], opportunityRefs: ['hqopp_growth_000001'],
    decisionRefs: ['hqdec_finance_000001'], whileYouWereAway: ['No incidents overnight.'],
    contextScope: 'COMPANY_INTERNAL', confidence: 0.7,
  });
  assert.strictEqual(Object.keys(brief.sections).length, 7);
});

test('HQBrief: an unsupported section key is rejected', () => {
  assert.throws(() => validateHQBrief({
    briefId: 'hqbrief_x_000001', generatedAt: now,
    sections: { legal: 'x' }, departmentStatuses: {}, contextScope: 'COMPANY_INTERNAL',
  }), ContractError);
});

test('HQBrief: an unknown department in departmentStatuses is rejected', () => {
  assert.throws(() => validateHQBrief({
    briefId: 'hqbrief_x_000002', generatedAt: now,
    sections: {}, departmentStatuses: { MARKETING: 'HEALTHY' }, contextScope: 'COMPANY_INTERNAL',
  }), ContractError);
});

console.log(pass + ' passed');
