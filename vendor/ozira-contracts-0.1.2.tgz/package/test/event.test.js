'use strict';
/* Proves EventEnvelope validation.
 * Run: node test/event.test.js   (zero dependencies) */

const assert = require('assert');
const { validateEventEnvelope, ContractError } = require('../src/index');

let pass = 0;
function test(name, fn) {
  try { fn(); console.log('  ok  ' + name); pass++; }
  catch (e) { console.error('FAIL  ' + name + '\n      ' + e.message); process.exitCode = 1; }
}

test('valid event passes', () => {
  const event = validateEventEnvelope({
    eventId: 'evt_abc123456', eventType: 'code.execution.completed', source: 'CODE',
    timestamp: new Date().toISOString(), payload: { executionId: 'exe_123' },
  });
  assert.strictEqual(event.eventType, 'code.execution.completed');
  assert.strictEqual(event.source, 'CODE');
});

test('missing event type is rejected', () => {
  assert.throws(() => validateEventEnvelope({
    eventId: 'evt_abc123456', source: 'CODE', timestamp: new Date().toISOString(), payload: {},
  }), ContractError);
});

test('malformed timestamp is rejected', () => {
  assert.throws(() => validateEventEnvelope({
    eventId: 'evt_abc123456', eventType: 'code.execution.completed', source: 'CODE',
    timestamp: 'not-a-date', payload: {},
  }), ContractError);
});

test('unknown source is rejected', () => {
  assert.throws(() => validateEventEnvelope({
    eventId: 'evt_abc123456', eventType: 'code.execution.completed', source: 'MOBILE',
    timestamp: new Date().toISOString(), payload: {},
  }), ContractError);
});

test('payload rejects raw secret values', () => {
  assert.throws(() => validateEventEnvelope({
    eventId: 'evt_abc123456', eventType: 'code.execution.completed', source: 'CODE',
    timestamp: new Date().toISOString(), payload: { note: 'key sk-proj-abcdefghijklmnopqrstuvwx' },
  }), ContractError);
});

console.log(pass + ' passed');
