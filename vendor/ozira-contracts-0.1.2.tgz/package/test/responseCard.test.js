'use strict';
const assert = require('assert');
const { validateResponseCard } = require('../src');

const base = {
  schemaVersion: 1, cardId: 'card_weather_123456', type: 'current_weather', lifecycle: 'success',
  title: 'Weather for Dubai', payload: { location: 'Dubai', temperatureC: 36 },
  fallbackText: 'Dubai is 36°C.', sources: [{ label: 'Weather provider', href: 'https://weather.example.test/today', verified: true }],
};

assert.strictEqual(validateResponseCard(base).type, 'current_weather');
assert.throws(() => validateResponseCard({ ...base, type: 'not-supported' }), /must be one of/);
assert.throws(() => validateResponseCard({ ...base, lifecycle: 'error', fallbackText: undefined }), /require fallbackText/);
assert.throws(() => validateResponseCard({ ...base, sources: [{ label: 'unsafe', href: 'javascript:alert(1)' }] }), /public HTTPS/);
assert.throws(() => validateResponseCard({ ...base, payload: { apiKey: 'secret' } }), /may not appear/);
console.log('responseCard contract tests: PASS');
