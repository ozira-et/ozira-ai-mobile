'use strict';
/* Proves Notification validation for an action-card style notification.
 * Run: node test/notification.test.js   (zero dependencies) */

const assert = require('assert');
const { validateNotification, ContractError } = require('../src/index');

let pass = 0;
function test(name, fn) {
  try { fn(); console.log('  ok  ' + name); pass++; }
  catch (e) { console.error('FAIL  ' + name + '\n      ' + e.message); process.exitCode = 1; }
}

const principal = { principalId: 'usr_abc123', subjectType: 'USER' };
const now = new Date().toISOString();

test('valid action-card notification passes', () => {
  const notification = validateNotification({
    notificationId: 'ntf_abc123456', principal, type: 'approval.requested',
    title: 'A deployment needs your approval', body: 'Railway deploy to production is awaiting review.',
    urgency: 'IMPORTANT', status: 'SENT',
    actions: [{ label: 'Review', actionId: 'apr_abc123456' }],
    relatedActionId: 'exe_abc123456', createdAt: now,
  });
  assert.strictEqual(notification.urgency, 'IMPORTANT');
  assert.strictEqual(notification.actions[0].label, 'Review');
});

test('unknown urgency is rejected', () => {
  assert.throws(() => validateNotification({
    notificationId: 'ntf_abc123456', principal, type: 'approval.requested', title: 't', body: 'b',
    urgency: 'URGENT', status: 'SENT', createdAt: now,
  }), ContractError);
});

test('too many actions is rejected', () => {
  const actions = Array.from({ length: 6 }, (_, i) => ({ label: 'A' + i, actionId: 'apr_abc12345' + i }));
  assert.throws(() => validateNotification({
    notificationId: 'ntf_abc123456', principal, type: 'approval.requested', title: 't', body: 'b',
    urgency: 'NORMAL', status: 'SENT', actions, createdAt: now,
  }), ContractError);
});

console.log(pass + ' passed');
