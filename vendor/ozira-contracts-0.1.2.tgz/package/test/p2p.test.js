'use strict';
/* Proves PAgentIntent / PAgentResponse validation, in particular the
 * structural minimum-necessary-disclosure guard: a meeting negotiation can
 * carry a proposed time and purpose, but never raw private context (a
 * reason, a calendar event, a memory blob, etc.).
 * Run: node test/p2p.test.js   (zero dependencies) */

const assert = require('assert');
const { validatePAgentIntent, validatePAgentResponse, ContractError } = require('../src/index');

let pass = 0;
function test(name, fn) {
  try { fn(); console.log('  ok  ' + name); pass++; }
  catch (e) { console.error('FAIL  ' + name + '\n      ' + e.message); process.exitCode = 1; }
}

const senderPrincipal = { principalId: 'p_user_a', subjectType: 'AGENT' };
const now = new Date().toISOString();

test('minimum-disclosure meeting request passes', () => {
  const intent = validatePAgentIntent({
    intentId: 'pin_abc123456', senderPrincipal, recipientRef: 'p_user_b', intentType: 'MEETING_REQUEST',
    disclosureScope: 'MINIMAL',
    payload: { purpose: 'lunch', proposedTime: '2026-08-20T10:30:00Z', timezone: 'Asia/Dubai' },
    status: 'PENDING', createdAt: now,
  });
  assert.strictEqual(intent.intentType, 'MEETING_REQUEST');
  assert.strictEqual(intent.payload.purpose, 'lunch');
});

test('malformed envelope fails: missing recipientRef', () => {
  assert.throws(() => validatePAgentIntent({
    intentId: 'pin_abc123456', senderPrincipal, intentType: 'MEETING_REQUEST', disclosureScope: 'MINIMAL',
    payload: { purpose: 'lunch' }, status: 'PENDING', createdAt: now,
  }), ContractError);
});

test('malformed envelope fails: nested object in payload (raw context smuggling)', () => {
  assert.throws(() => validatePAgentIntent({
    intentId: 'pin_abc123456', senderPrincipal, recipientRef: 'p_user_b', intentType: 'MEETING_REQUEST',
    disclosureScope: 'MINIMAL',
    payload: { purpose: 'lunch', calendarEvent: { title: 'Board meeting', attendees: ['ceo@x.com'] } },
    status: 'PENDING', createdAt: now,
  }), ContractError);
});

test('malformed envelope fails: too many payload fields', () => {
  const payload = {};
  for (let i = 0; i < 9; i += 1) payload['field' + i] = 'value';
  assert.throws(() => validatePAgentIntent({
    intentId: 'pin_abc123456', senderPrincipal, recipientRef: 'p_user_b', intentType: 'MEETING_REQUEST',
    disclosureScope: 'MINIMAL', payload, status: 'PENDING', createdAt: now,
  }), ContractError);
});

test('malformed envelope fails: secret-shaped payload value', () => {
  assert.throws(() => validatePAgentIntent({
    intentId: 'pin_abc123456', senderPrincipal, recipientRef: 'p_user_b', intentType: 'MEETING_REQUEST',
    disclosureScope: 'MINIMAL', payload: { note: 'sk-proj-abcdefghijklmnopqrstuvwx' },
    status: 'PENDING', createdAt: now,
  }), ContractError);
});

test('NONE disclosure scope requires an empty payload', () => {
  const intent = validatePAgentIntent({
    intentId: 'pin_abc123456', senderPrincipal, recipientRef: 'p_user_b', intentType: 'STATUS_PING',
    disclosureScope: 'NONE', payload: {}, status: 'PENDING', createdAt: now,
  });
  assert.deepStrictEqual(intent.payload, {});
  assert.throws(() => validatePAgentIntent({
    intentId: 'pin_abc123456', senderPrincipal, recipientRef: 'p_user_b', intentType: 'STATUS_PING',
    disclosureScope: 'NONE', payload: { purpose: 'lunch' }, status: 'PENDING', createdAt: now,
  }), ContractError);
});

test('minimum-disclosure alternative-time response passes', () => {
  const response = validatePAgentResponse({
    responseId: 'prs_abc123456', intentId: 'pin_abc123456', responderRef: 'p_user_b',
    responseType: 'ALTERNATIVE_TIME', disclosureScope: 'MINIMAL',
    payload: { proposedTime: '2026-08-20T10:45:00Z' }, status: 'FINAL', createdAt: now,
  });
  assert.strictEqual(response.payload.proposedTime, '2026-08-20T10:45:00Z');
});

test('malformed response fails: private reason field is structurally impossible to smuggle as extra keys, but a raw object still fails', () => {
  assert.throws(() => validatePAgentResponse({
    responseId: 'prs_abc123456', intentId: 'pin_abc123456', responderRef: 'p_user_b',
    responseType: 'ALTERNATIVE_TIME', disclosureScope: 'MINIMAL',
    payload: { proposedTime: '10:45', privateReason: { calendarConflict: 'Board meeting with CEO' } },
    status: 'FINAL', createdAt: now,
  }), ContractError);
});

test('malformed response fails: missing intentId', () => {
  assert.throws(() => validatePAgentResponse({
    responseId: 'prs_abc123456', responderRef: 'p_user_b', responseType: 'ALTERNATIVE_TIME',
    disclosureScope: 'MINIMAL', payload: { proposedTime: '10:45' }, status: 'FINAL', createdAt: now,
  }), ContractError);
});

console.log(pass + ' passed');
