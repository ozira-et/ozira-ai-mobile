'use strict';
/* Proves ConnectorExecution validation, including that raw OAuth/credential
 * fields can never be attached to a connector execution record.
 * Run: node test/connector.test.js   (zero dependencies) */

const assert = require('assert');
const { validateConnectorExecution, ContractError } = require('../src/index');

let pass = 0;
function test(name, fn) {
  try { fn(); console.log('  ok  ' + name); pass++; }
  catch (e) { console.error('FAIL  ' + name + '\n      ' + e.message); process.exitCode = 1; }
}

const now = new Date().toISOString();

test('pending connector execution passes without an external reference', () => {
  const execution = validateConnectorExecution({
    connectorExecutionId: 'cxe_abc123456', actionId: 'exe_abc123456', connectorType: 'calendar',
    capability: 'CREATE_EVENT', status: 'PENDING', idempotencyKey: 'idem-key-00000001', createdAt: now,
  });
  assert.strictEqual(execution.status, 'PENDING');
  assert.strictEqual(Object.prototype.hasOwnProperty.call(execution, 'externalReference'), false);
});

test('completed connector execution passes with an external reference', () => {
  const execution = validateConnectorExecution({
    connectorExecutionId: 'cxe_abc123456', actionId: 'exe_abc123456', connectorType: 'calendar',
    capability: 'CREATE_EVENT', status: 'SUCCEEDED', externalReference: 'evt_google_9182',
    idempotencyKey: 'idem-key-00000001', createdAt: now, completedAt: now,
  });
  assert.strictEqual(execution.externalReference, 'evt_google_9182');
});

test('externalReference is rejected while status is PENDING', () => {
  assert.throws(() => validateConnectorExecution({
    connectorExecutionId: 'cxe_abc123456', actionId: 'exe_abc123456', connectorType: 'calendar',
    capability: 'CREATE_EVENT', status: 'PENDING', externalReference: 'should-not-be-set',
    idempotencyKey: 'idem-key-00000001', createdAt: now,
  }), ContractError);
});

test('raw credential fields are rejected from resultMetadata', () => {
  for (const key of ['accessToken', 'refreshToken', 'clientSecret', 'oauthToken']) {
    assert.throws(() => validateConnectorExecution({
      connectorExecutionId: 'cxe_abc123456', actionId: 'exe_abc123456', connectorType: 'calendar',
      capability: 'CREATE_EVENT', status: 'SUCCEEDED', externalReference: 'evt_1',
      idempotencyKey: 'idem-key-00000001', createdAt: now,
      resultMetadata: { [key]: 'raw-value-should-never-appear' },
    }), ContractError, key + ' should be rejected');
  }
});

test('a credentialRef-style pointer is allowed (not a raw secret)', () => {
  const execution = validateConnectorExecution({
    connectorExecutionId: 'cxe_abc123456', actionId: 'exe_abc123456', connectorType: 'calendar',
    capability: 'CREATE_EVENT', status: 'SUCCEEDED', externalReference: 'evt_1',
    idempotencyKey: 'idem-key-00000001', createdAt: now,
    resultMetadata: { credentialRef: 'cred_ref_9182' },
  });
  assert.strictEqual(execution.resultMetadata.credentialRef, 'cred_ref_9182');
});

console.log(pass + ' passed');
