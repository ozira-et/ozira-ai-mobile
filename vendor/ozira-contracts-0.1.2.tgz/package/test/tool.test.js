'use strict';
/* Proves ToolInvocation / ToolResult validation, including secret-field
 * rejection.
 * Run: node test/tool.test.js   (zero dependencies) */

const assert = require('assert');
const { validateToolInvocation, validateToolResult, ContractError } = require('../src/index');

let pass = 0;
function test(name, fn) {
  try { fn(); console.log('  ok  ' + name); pass++; }
  catch (e) { console.error('FAIL  ' + name + '\n      ' + e.message); process.exitCode = 1; }
}

const principal = { principalId: 'usr_abc123', subjectType: 'USER' };

test('valid safe tool invocation passes', () => {
  const invocation = validateToolInvocation({
    invocationId: 'inv_abc123456', toolId: 'system.echo', principal, input: { text: 'hello' },
  });
  assert.strictEqual(invocation.toolId, 'system.echo');
});

test('malformed tool identifier is rejected', () => {
  assert.throws(() => validateToolInvocation({
    invocationId: 'inv_abc123456', toolId: 'not a tool id!', principal, input: {},
  }), ContractError);
  assert.throws(() => validateToolInvocation({
    invocationId: 'inv_abc123456', toolId: 'noNamespace', principal, input: {},
  }), ContractError);
});

test('secret-field rejection in input', () => {
  assert.throws(() => validateToolInvocation({
    invocationId: 'inv_abc123456', toolId: 'system.echo', principal, input: { apiKey: 'sk-proj-abcdefghijklmnopqrstuvwx' },
  }), ContractError);
});

test('ToolResult: valid result', () => {
  const result = validateToolResult({ invocationId: 'inv_abc123456', status: 'SUCCEEDED', output: { echoed: 'hello' } });
  assert.strictEqual(result.status, 'SUCCEEDED');
});

test('ToolResult: unknown status is rejected', () => {
  assert.throws(() => validateToolResult({ invocationId: 'inv_abc123456', status: 'MAYBE' }), ContractError);
});

test('ToolResult: secret-shaped output is rejected', () => {
  assert.throws(() => validateToolResult({
    invocationId: 'inv_abc123456', status: 'SUCCEEDED', output: { refreshToken: 'anything' },
  }), ContractError);
});

console.log(pass + ' passed');
