'use strict';
/* Proves ApprovalRequest validation across statuses.
 * Run: node test/approval.test.js   (zero dependencies) */

const assert = require('assert');
const { validateApprovalRequest, ContractError } = require('../src/index');

let pass = 0;
function test(name, fn) {
  try { fn(); console.log('  ok  ' + name); pass++; }
  catch (e) { console.error('FAIL  ' + name + '\n      ' + e.message); process.exitCode = 1; }
}

const principal = { principalId: 'usr_abc123', subjectType: 'USER' };
const now = new Date();
const iso = value => new Date(value).toISOString();

test('pending approval passes', () => {
  const approval = validateApprovalRequest({
    approvalId: 'apr_abc123456', actionId: 'exe_abc123456', principal, requestedAuthority: 'EXECUTE',
    reason: 'Deployments always require a human approval.', status: 'PENDING',
    createdAt: iso(now), expiresAt: iso(now.getTime() + 600000),
  });
  assert.strictEqual(approval.status, 'PENDING');
});

test('approved approval passes', () => {
  const approval = validateApprovalRequest({
    approvalId: 'apr_abc123456', actionId: 'exe_abc123456', principal, requestedAuthority: 'EXECUTE',
    reason: 'Reviewed and approved.', status: 'APPROVED', createdAt: iso(now),
  });
  assert.strictEqual(approval.status, 'APPROVED');
});

test('rejected and expired approvals pass', () => {
  for (const status of ['REJECTED', 'EXPIRED', 'CANCELLED']) {
    const approval = validateApprovalRequest({
      approvalId: 'apr_abc123456', actionId: 'exe_abc123456', principal, requestedAuthority: 'EXECUTE',
      reason: 'Decision recorded.', status, createdAt: iso(now),
    });
    assert.strictEqual(approval.status, status);
  }
});

test('unknown status is rejected', () => {
  assert.throws(() => validateApprovalRequest({
    approvalId: 'apr_abc123456', actionId: 'exe_abc123456', principal, requestedAuthority: 'EXECUTE',
    reason: 'x', status: 'MAYBE', createdAt: iso(now),
  }), ContractError);
});

test('expiresAt before createdAt is rejected', () => {
  assert.throws(() => validateApprovalRequest({
    approvalId: 'apr_abc123456', actionId: 'exe_abc123456', principal, requestedAuthority: 'EXECUTE',
    reason: 'x', status: 'PENDING', createdAt: iso(now), expiresAt: iso(now.getTime() - 1000),
  }), ContractError);
});

console.log(pass + ' passed');
