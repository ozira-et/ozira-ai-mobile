'use strict';
/* Proves Principal validation: valid shapes pass, invalid subject types are
 * rejected, and no token/secret field can ever survive validation.
 * Run: node test/principal.test.js   (zero dependencies) */

const assert = require('assert');
const { validatePrincipal, ContractError } = require('../src/index');

let pass = 0;
function test(name, fn) {
  try { fn(); console.log('  ok  ' + name); pass++; }
  catch (e) { console.error('FAIL  ' + name + '\n      ' + e.message); process.exitCode = 1; }
}

test('valid user principal passes', () => {
  const principal = validatePrincipal({ principalId: 'usr_abc123', subjectType: 'USER', tenantId: 'tnt_001', workspaceId: 'wsp_001', role: 'owner' });
  assert.strictEqual(principal.principalId, 'usr_abc123');
  assert.strictEqual(principal.subjectType, 'USER');
  assert.strictEqual(principal.schemaVersion, 1);
});

test('valid agent/system/service principals pass', () => {
  for (const subjectType of ['AGENT', 'SYSTEM', 'SERVICE']) {
    const principal = validatePrincipal({ principalId: 'id_' + subjectType.toLowerCase(), subjectType });
    assert.strictEqual(principal.subjectType, subjectType);
  }
});

test('invalid subject type is rejected', () => {
  assert.throws(() => validatePrincipal({ principalId: 'usr_abc123', subjectType: 'ADMIN' }), ContractError);
});

test('missing principalId is rejected', () => {
  assert.throws(() => validatePrincipal({ subjectType: 'USER' }), ContractError);
});

test('no token fields can survive validation', () => {
  assert.throws(() => validatePrincipal({ principalId: 'usr_abc123', subjectType: 'USER', accessToken: 'sk-abcdef1234567890' }), ContractError);
  const principal = validatePrincipal({ principalId: 'usr_abc123', subjectType: 'USER' });
  assert.strictEqual(Object.prototype.hasOwnProperty.call(principal, 'accessToken'), false);
  assert.strictEqual(Object.prototype.hasOwnProperty.call(principal, 'token'), false);
});

test('result is frozen', () => {
  const principal = validatePrincipal({ principalId: 'usr_abc123', subjectType: 'USER' });
  assert.throws(() => { principal.role = 'hacked'; }, TypeError);
});

console.log(pass + ' passed');
