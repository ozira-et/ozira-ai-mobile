'use strict';
/* Proves ActionRequest, ActionResult, and AuthorityDecision validation.
 * Run: node test/action.test.js   (zero dependencies) */

const assert = require('assert');
const {
  validateActionRequest, validateActionResult, validateAuthorityDecision, ContractError,
} = require('../src/index');

let pass = 0;
function test(name, fn) {
  try { fn(); console.log('  ok  ' + name); pass++; }
  catch (e) { console.error('FAIL  ' + name + '\n      ' + e.message); process.exitCode = 1; }
}

const principal = { principalId: 'usr_abc123', subjectType: 'USER' };

test('valid Code-style command action passes', () => {
  const request = validateActionRequest({
    actionId: 'exe_abc123456', actionType: 'code.terminal.run', source: 'CODE', principal,
    authorityRequired: 'EXECUTE', payload: { executable: 'npm', args: ['test'] },
    idempotencyKey: 'idem-key-00000001', createdAt: new Date().toISOString(),
  });
  assert.strictEqual(request.actionType, 'code.terminal.run');
  assert.strictEqual(request.authorityRequired, 'EXECUTE');
});

test('invalid authority is rejected', () => {
  assert.throws(() => validateActionRequest({
    actionId: 'exe_abc123456', actionType: 'code.terminal.run', source: 'CODE', principal,
    authorityRequired: 'SUPERUSER', payload: {}, idempotencyKey: 'idem-key-00000001',
    createdAt: new Date().toISOString(),
  }), ContractError);
});

test('missing idempotency identity is rejected', () => {
  assert.throws(() => validateActionRequest({
    actionId: 'exe_abc123456', actionType: 'code.terminal.run', source: 'CODE', principal,
    authorityRequired: 'EXECUTE', payload: {}, createdAt: new Date().toISOString(),
  }), ContractError);
});

test('malformed idempotency key is rejected', () => {
  assert.throws(() => validateActionRequest({
    actionId: 'exe_abc123456', actionType: 'code.terminal.run', source: 'CODE', principal,
    authorityRequired: 'EXECUTE', payload: {}, idempotencyKey: 'x', createdAt: new Date().toISOString(),
  }), ContractError);
});

test('payload structural validity does not imply trust (documented, not enforced here)', () => {
  // A structurally valid payload of arbitrary shape is still accepted — the
  // contract only proves the envelope is well-formed, never that the
  // contents are safe to act on without policy/authority evaluation.
  const request = validateActionRequest({
    actionId: 'exe_abc123456', actionType: 'code.terminal.run', source: 'CODE', principal,
    authorityRequired: 'EXECUTE', payload: { anything: 'goes-structurally' },
    idempotencyKey: 'idem-key-00000001', createdAt: new Date().toISOString(),
  });
  assert.ok(request.payload);
});

test('ActionResult: success', () => {
  const result = validateActionResult({ actionId: 'exe_abc123456', status: 'SUCCEEDED', result: { exitCode: 0 } });
  assert.strictEqual(result.status, 'SUCCEEDED');
});

test('ActionResult: failure', () => {
  const result = validateActionResult({ actionId: 'exe_abc123456', status: 'FAILED', error: { code: 'EXIT_NONZERO', message: 'boom' } });
  assert.strictEqual(result.status, 'FAILED');
  assert.strictEqual(result.error.code, 'EXIT_NONZERO');
});

test('ActionResult: malformed status is rejected', () => {
  assert.throws(() => validateActionResult({ actionId: 'exe_abc123456', status: 'DONE' }), ContractError);
});

test('AuthorityDecision: ALLOW', () => {
  const decision = validateAuthorityDecision({
    actionId: 'exe_abc123456', requiredAuthority: 'OBSERVE', decision: 'ALLOW',
    reason: 'Read-only command is allowed.', requiresHumanApproval: false,
  });
  assert.strictEqual(decision.decision, 'ALLOW');
});

test('AuthorityDecision: REQUIRE_APPROVAL', () => {
  const decision = validateAuthorityDecision({
    actionId: 'exe_abc123456', requiredAuthority: 'EXECUTE', decision: 'REQUIRE_APPROVAL',
    reason: 'Deployments always require a human approval.', requiresHumanApproval: true,
  });
  assert.strictEqual(decision.decision, 'REQUIRE_APPROVAL');
});

test('AuthorityDecision: DENY', () => {
  const decision = validateAuthorityDecision({
    actionId: 'exe_abc123456', requiredAuthority: 'DECIDE', decision: 'DENY',
    reason: 'Policy denied the command.', requiresHumanApproval: false,
  });
  assert.strictEqual(decision.decision, 'DENY');
});

test('AuthorityDecision: REQUIRE_APPROVAL without requiresHumanApproval is rejected', () => {
  assert.throws(() => validateAuthorityDecision({
    actionId: 'exe_abc123456', requiredAuthority: 'EXECUTE', decision: 'REQUIRE_APPROVAL',
    reason: 'Missing flag.', requiresHumanApproval: false,
  }), ContractError);
});

console.log(pass + ' passed');
