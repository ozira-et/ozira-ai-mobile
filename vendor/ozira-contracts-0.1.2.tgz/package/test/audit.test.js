'use strict';
/* Proves AuditEvent validation: traceability fields and secret-safe metadata.
 * Run: node test/audit.test.js   (zero dependencies) */

const assert = require('assert');
const { validateAuditEvent, ContractError } = require('../src/index');

let pass = 0;
function test(name, fn) {
  try { fn(); console.log('  ok  ' + name); pass++; }
  catch (e) { console.error('FAIL  ' + name + '\n      ' + e.message); process.exitCode = 1; }
}

const principal = { principalId: 'usr_abc123', subjectType: 'USER' };
const now = new Date().toISOString();

test('valid traceability fields pass', () => {
  const audit = validateAuditEvent({
    auditId: 'aud_abc123456', eventType: 'execution.approved_by_policy', principal,
    actionId: 'exe_abc123456', correlationId: 'exe_abc123456', timestamp: now, outcome: 'SUCCESS',
  });
  assert.strictEqual(audit.eventType, 'execution.approved_by_policy');
  assert.strictEqual(audit.outcome, 'SUCCESS');
});

test('unknown outcome is rejected', () => {
  assert.throws(() => validateAuditEvent({
    auditId: 'aud_abc123456', eventType: 'execution.approved_by_policy', principal, timestamp: now, outcome: 'MAYBE',
  }), ContractError);
});

test('metadata must be secret-safe', () => {
  assert.throws(() => validateAuditEvent({
    auditId: 'aud_abc123456', eventType: 'execution.approved_by_policy', principal, timestamp: now,
    outcome: 'SUCCESS', metadata: { password: 'hunter2' },
  }), ContractError);
});

console.log(pass + ' passed');
