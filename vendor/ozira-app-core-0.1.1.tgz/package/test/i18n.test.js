'use strict';

const assert = require('assert');
const {
  LANGUAGES, LANGUAGE_CODES, DEFAULT_LANGUAGE, RTL_LANGS,
  isRTL, isSupportedLanguage, langName, rtlStyles, rtlIconName, translate,
} = require('../src/i18n');

const tests = [];
function test(name, fn) { tests.push({ name, fn }); }

test('the shared language list matches ozira-mobile exactly (8 languages)', () => {
  assert.deepStrictEqual(LANGUAGE_CODES, ['en', 'am', 'om', 'ti', 'ar', 'sw', 'fr', 'ha']);
  assert.strictEqual(LANGUAGES.length, 8);
});

test('DEFAULT_LANGUAGE is English', () => {
  assert.strictEqual(DEFAULT_LANGUAGE, 'en');
});

test('only Arabic is RTL', () => {
  assert.deepStrictEqual(RTL_LANGS, ['ar']);
  assert.strictEqual(isRTL('ar'), true);
  for (const code of LANGUAGE_CODES.filter((c) => c !== 'ar')) {
    assert.strictEqual(isRTL(code), false, `${code} must not be RTL`);
  }
});

// --- LTR test (spec section 31) -----------------------------------------
test('LTR: an LTR language produces no directional overrides', () => {
  const styles = rtlStyles(isRTL('en'));
  assert.deepStrictEqual(styles.text, {});
  assert.deepStrictEqual(styles.row, {});
  assert.deepStrictEqual(styles.align, {});
  assert.strictEqual(rtlIconName('chevron-forward', isRTL('en')), 'chevron-forward');
});

// --- RTL test (spec section 31) -----------------------------------------
test('RTL: Arabic mirrors text, row direction, alignment, and directional icons', () => {
  const styles = rtlStyles(isRTL('ar'));
  assert.strictEqual(styles.text.textAlign, 'right');
  assert.strictEqual(styles.text.writingDirection, 'rtl');
  assert.strictEqual(styles.row.flexDirection, 'row-reverse');
  assert.strictEqual(styles.align.alignItems, 'flex-end');
  assert.strictEqual(rtlIconName('chevron-forward', true), 'chevron-back');
  assert.strictEqual(rtlIconName('arrow-back', true), 'arrow-forward');
});

test('isSupportedLanguage rejects codes outside the shared list', () => {
  assert.strictEqual(isSupportedLanguage('en'), true);
  assert.strictEqual(isSupportedLanguage('ar'), true);
  assert.strictEqual(isSupportedLanguage('zz'), false);
  assert.strictEqual(isSupportedLanguage(''), false);
});

test('langName returns the native name, falling back to English for unknown codes', () => {
  assert.strictEqual(langName('ar'), 'العربية');
  assert.strictEqual(langName('zz'), 'English');
});

test('translate falls back to the default language, then to the key itself', () => {
  const dict = { en: { hello: 'Hello' }, am: {} };
  assert.strictEqual(translate(dict, 'am', 'hello'), 'Hello'); // falls back to en
  assert.strictEqual(translate(dict, 'en', 'missing_key'), 'missing_key'); // falls back to the key
});

test('translate interpolates {vars}', () => {
  const dict = { en: { greeting: 'Hello {name}' } };
  assert.strictEqual(translate(dict, 'en', 'greeting', { name: 'Alice' }), 'Hello Alice');
});

test('the SAME algorithm serves any dictionary shape a surface supplies (no hard-coded strings here)', () => {
  const customDict = { en: { x: '1' }, fr: { x: 'un' } };
  assert.strictEqual(translate(customDict, 'fr', 'x'), 'un');
});

(async () => {
  let passed = 0;
  for (const item of tests) {
    try {
      await item.fn();
      passed += 1;
      console.log('  ok  ' + item.name);
    } catch (error) {
      console.error('FAIL  ' + item.name + '\n      ' + (error.stack || error.message));
      process.exitCode = 1;
    }
  }
  if (!process.exitCode) console.log(`\n${passed} i18n/RTL tests passed.`);
})();
