'use strict';

const assert = require('assert');
const {
  PRODUCT_IDS, MANIFESTS, getManifest, listManifests,
  manifestSurfacesTool, manifestRendererFor,
} = require('../src/productManifest');

const tests = [];
function test(name, fn) { tests.push({ name, fn }); }

test('exactly the five specialized products exist, in the spec order', () => {
  assert.deepStrictEqual(PRODUCT_IDS, ['assistant', 'code', 'design', 'p', 'forward']);
});

test('every product id has a manifest, and every manifest field is present', () => {
  const REQUIRED_FIELDS = [
    'productId', 'displayName', 'primaryObject', 'workspaceType', 'navigation',
    'artifactTypes', 'rendererMap', 'surfacedTools', 'composerCapabilities',
    'defaultAgentPolicy', 'modelRoutingPolicy', 'featureFlags', 'telemetryNamespace',
    'responsiveContract',
  ];
  for (const id of PRODUCT_IDS) {
    const manifest = getManifest(id);
    for (const field of REQUIRED_FIELDS) {
      assert.notStrictEqual(manifest[field], undefined, `${id} manifest is missing "${field}"`);
    }
    assert.strictEqual(manifest.productId, id);
  }
});

test('each product declares the correct primary work object (spec section 2)', () => {
  assert.strictEqual(getManifest('assistant').primaryObject, 'conversation');
  assert.strictEqual(getManifest('code').primaryObject, 'repository');
  assert.strictEqual(getManifest('design').primaryObject, 'canvas');
  assert.strictEqual(getManifest('p').primaryObject, 'evidence');
  assert.strictEqual(getManifest('forward').primaryObject, 'workflow');
});

test('getManifest throws on an unknown product rather than returning undefined', () => {
  assert.throws(() => getManifest('marketing'), /Unknown product/);
});

test('listManifests returns all five, in PRODUCT_IDS order', () => {
  const list = listManifests();
  assert.strictEqual(list.length, 5);
  assert.deepStrictEqual(list.map((m) => m.productId), PRODUCT_IDS);
});

test('every manifest is deep-frozen -- a consumer cannot mutate the shared source of truth', () => {
  for (const id of PRODUCT_IDS) {
    const manifest = getManifest(id);
    assert.throws(() => { manifest.displayName = 'Hacked'; }, TypeError);
    assert.throws(() => { manifest.navigation.push('x'); }, TypeError);
    assert.throws(() => { manifest.rendererMap.code = 'Evil'; }, TypeError);
  }
});

test('manifestSurfacesTool answers only whether the manifest offers to show a tool, not whether it is authorized', () => {
  assert.strictEqual(manifestSurfacesTool('code', 'terminal'), true);
  assert.strictEqual(manifestSurfacesTool('code', 'web-search'), false);
  assert.strictEqual(manifestSurfacesTool('assistant', 'connectors'), true);
  assert.strictEqual(typeof manifestSurfacesTool('assistant', 'connectors'), 'boolean');
});

test('manifestSurfacesTool throws for an unknown product rather than silently returning false', () => {
  assert.throws(() => manifestSurfacesTool('marketing', 'terminal'), /Unknown product/);
});

test('manifestRendererFor maps a declared artifact type to its renderer', () => {
  assert.strictEqual(manifestRendererFor('assistant', 'code'), 'CodeRenderer');
  assert.strictEqual(manifestRendererFor('design', 'design'), 'DesignRenderer');
  assert.strictEqual(manifestRendererFor('p', 'evidence'), 'EvidenceRenderer');
  assert.strictEqual(manifestRendererFor('forward', 'workflow'), 'ForwardRenderer');
});

test('manifestRendererFor returns null for an artifact type the product does not declare -- never a guess', () => {
  assert.strictEqual(manifestRendererFor('design', 'workflow'), null);
  assert.strictEqual(manifestRendererFor('p', 'code'), null);
});

test('every rendererMap entry covers every declared artifactType (no artifact type silently falls through to null)', () => {
  for (const id of PRODUCT_IDS) {
    const manifest = getManifest(id);
    for (const artifactType of manifest.artifactTypes) {
      assert.notStrictEqual(manifest.rendererMap[artifactType], undefined,
        `${id}: artifactType "${artifactType}" has no renderer mapped`);
    }
  }
});

test('CONTRACT: a manifest is display/capability-surfacing only -- it carries no authorization-shaped field', () => {
  // Guards against a future edit accidentally adding something that reads
  // like an authorization decision (spec: "Manifest != Authorization").
  const FORBIDDEN_FIELD_NAME_PATTERN = /authoriz|permission|grant|role|entitlement/i;
  for (const id of PRODUCT_IDS) {
    const manifest = getManifest(id);
    for (const field of Object.keys(manifest)) {
      assert.doesNotMatch(field, FORBIDDEN_FIELD_NAME_PATTERN,
        `${id} manifest field "${field}" reads as an authorization decision -- manifests must never decide authorization`);
    }
  }
});

test('MANIFESTS is frozen at the top level too', () => {
  assert.throws(() => { MANIFESTS.assistant = null; }, TypeError);
});

(async () => {
  let passed = 0;
  for (const item of tests) {
    try {
      await item.fn();
      passed += 1;
      console.log('  ok  ' + item.name);
    } catch (error) {
      console.error('FAIL  ' + item.name + '\n      ' + (error.stack || error.message));
      process.exitCode = 1;
    }
  }
  if (!process.exitCode) console.log(`\n${passed} product manifest tests passed.`);
})();
