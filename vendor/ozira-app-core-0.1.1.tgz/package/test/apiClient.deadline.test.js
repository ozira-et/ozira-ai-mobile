'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const fs = require('node:fs');
const path = require('node:path');
const { createRequire } = require('node:module');

function fixture(fetchImpl, extra = {}) {
  const timers = new Map();
  let next = 0;
  const filename = path.join(__dirname, '../src/apiClient.js');
  const context = { module: { exports: {} }, require: createRequire(filename), AbortController,
    setTimeout: fn => { const id = ++next; timers.set(id, fn); return id; },
    clearTimeout: id => timers.delete(id) };
  vm.runInNewContext(fs.readFileSync(filename, 'utf8'), context, { filename });
  const client = context.module.exports.createApiClient({ baseUrl: 'https://test.invalid', fetchImpl, ...extra });
  return { client, timers, expire: () => { for (const fn of [...timers.values()]) fn(); } };
}
const response = (status = 200) => ({ ok: status === 200, status, json: async () => ({ ok: true }) });
for (const mode of ['success', 'http-error', 'transport-error', 'retry', 'refresh']) {
  test(`deadline released after ${mode}`, async () => {
    let calls = 0;
    const f = fixture(async () => {
      calls++;
      if (mode === 'transport-error') throw new Error('offline');
      if (mode === 'http-error') return response(403);
      if (mode === 'retry' && calls === 1) return response(503);
      if (mode === 'refresh' && calls === 1) return response(401);
      return response();
    }, mode === 'refresh' ? { refreshToken: async () => true } : {});
    if (mode.endsWith('error')) await assert.rejects(f.client.call('/read'));
    else await f.client.call('/read', { retry: mode === 'retry' });
    assert.equal(calls, ['retry', 'refresh'].includes(mode) ? 2 : 1);
    assert.equal(f.timers.size, 0, 'no deadline retained after the logical request');
  });
}
test('a body deadline rejects with TIMEOUT and never retries a write', async () => {
  let bodyStarted;
  const ready = new Promise(resolve => { bodyStarted = resolve; });
  let calls = 0;
  const f = fixture(async () => {
    calls++;
    return { ok: true, status: 200, json: () => { bodyStarted(); return new Promise(() => {}); } };
  });
  const pending = f.client.call('/write', { method: 'POST', body: { test: true }, retry: true });
  const rejected = assert.rejects(pending, error => error.code === 'TIMEOUT');
  await ready;
  f.expire();
  await rejected;
  assert.equal(calls, 1);
  assert.equal(f.timers.size, 0);
});
