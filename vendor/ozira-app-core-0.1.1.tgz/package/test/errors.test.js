'use strict';

const assert = require('assert');
const { CODES, AppError, classifyHttpError, classifyTransportError } = require('../src/errors');

const tests = [];
function test(name, fn) { tests.push({ name, fn }); }

test('classifyHttpError maps standard HTTP statuses to the taxonomy', () => {
  assert.strictEqual(classifyHttpError(401, {}).code, CODES.UNAUTHENTICATED);
  assert.strictEqual(classifyHttpError(403, {}).code, CODES.FORBIDDEN);
  assert.strictEqual(classifyHttpError(404, {}).code, CODES.NOT_FOUND);
  assert.strictEqual(classifyHttpError(400, {}).code, CODES.VALIDATION);
  assert.strictEqual(classifyHttpError(422, {}).code, CODES.VALIDATION);
  assert.strictEqual(classifyHttpError(408, {}).code, CODES.TIMEOUT);
  assert.strictEqual(classifyHttpError(500, {}).code, CODES.TEMPORARY_SERVICE_FAILURE);
  assert.strictEqual(classifyHttpError(503, {}).code, CODES.TEMPORARY_SERVICE_FAILURE);
  assert.strictEqual(classifyHttpError(418, {}).code, CODES.UNKNOWN);
});

test('a server-provided machine-readable code wins over the HTTP status guess', () => {
  const error = classifyHttpError(500, { code: 'VALIDATION', message: 'bad input' });
  assert.strictEqual(error.code, CODES.VALIDATION);
});

test('an unrecognized server code falls back to status-based classification', () => {
  const error = classifyHttpError(403, { code: 'SOME_UNKNOWN_BACKEND_CODE' });
  assert.strictEqual(error.code, CODES.FORBIDDEN);
});

test('classifyTransportError distinguishes timeout (AbortError) from generic network failure', () => {
  const abort = new Error('aborted');
  abort.name = 'AbortError';
  assert.strictEqual(classifyTransportError(abort).code, CODES.TIMEOUT);
  assert.strictEqual(classifyTransportError(new Error('fetch failed')).code, CODES.NETWORK);
});

test('an AppError never exposes an internal stack trace to its own toJSON', () => {
  const error = new AppError('UNKNOWN', 'boom');
  const json = error.toJSON();
  assert.strictEqual(Object.prototype.hasOwnProperty.call(json, 'stack'), false);
});

test('safeDetails strips anything token/secret/credential-shaped from the body', () => {
  const error = classifyHttpError(400, {
    error: 'bad',
    token: 'should-not-appear',
    accessToken: 'should-not-appear',
    authorization: 'Bearer xyz',
    client_secret: 'nope',
    field: 'email',
  });
  const rendered = JSON.stringify(error.details).toLowerCase();
  assert.ok(!rendered.includes('should-not-appear'));
  assert.ok(!rendered.includes('bearer'));
  assert.strictEqual(error.details.field, 'email');
});

test('safeDetails drops oversized string values (no raw stack traces riding along)', () => {
  const error = classifyHttpError(500, { hint: 'x'.repeat(1000) });
  assert.strictEqual(error.details.hint, undefined);
});

test('an unknown AppError code is coerced to UNKNOWN rather than accepted silently', () => {
  const error = new AppError('NOT_A_REAL_CODE', 'whatever');
  assert.strictEqual(error.code, CODES.UNKNOWN);
});

(async () => {
  let passed = 0;
  for (const item of tests) {
    try {
      await item.fn();
      passed += 1;
      console.log('  ok  ' + item.name);
    } catch (error) {
      console.error('FAIL  ' + item.name + '\n      ' + (error.stack || error.message));
      process.exitCode = 1;
    }
  }
  if (!process.exitCode) console.log(`\n${passed} error taxonomy tests passed.`);
})();
