'use strict';

const assert = require('assert');
const { createTelemetryClient, redactProperties } = require('../src/telemetry');

const tests = [];
function test(name, fn) { tests.push({ name, fn }); }

test('track() shapes an event with platform/appVersion/timestamp', () => {
  const events = [];
  const t = createTelemetryClient({ sink: (e) => events.push(e), platform: 'web', appVersion: '1.0.0' });
  t.screenView('home');
  assert.strictEqual(events.length, 1);
  assert.strictEqual(events[0].type, 'screen_view');
  assert.strictEqual(events[0].platform, 'web');
  assert.strictEqual(events[0].appVersion, '1.0.0');
  assert.strictEqual(typeof events[0].timestamp, 'number');
  assert.strictEqual(events[0].properties.screen, 'home');
});

test('an unrecognized event type is silently dropped, not thrown', () => {
  const events = [];
  const t = createTelemetryClient({ sink: (e) => events.push(e), platform: 'web', appVersion: '1.0.0' });
  t.track('made_up_event', {});
  assert.strictEqual(events.length, 0);
});

test('PRIVACY: redactProperties strips token/secret/credential/jwt-shaped keys', () => {
  const clean = redactProperties({
    screen: 'chat',
    token: 'eyJabc',
    accessToken: 'eyJabc',
    client_secret: 'nope',
    authorization: 'Bearer x',
  });
  assert.deepStrictEqual(clean, { screen: 'chat' });
});

test('PRIVACY: redactProperties strips raw prompt/document/content payloads', () => {
  const clean = redactProperties({ feature: 'chat_send', prompt: 'sensitive user text', documentText: 'sensitive' });
  assert.deepStrictEqual(clean, { feature: 'chat_send' });
});

test('PRIVACY: redactProperties drops oversized string values (bulk content guard)', () => {
  const clean = redactProperties({ note: 'x'.repeat(500) });
  assert.strictEqual(clean.note, undefined);
});

test('all four platform event helpers route through the same redaction path', () => {
  const events = [];
  const t = createTelemetryClient({ sink: (e) => events.push(e), platform: 'desktop', appVersion: '1.0.0' });
  t.apiFailure('/api/x', 'NETWORK', { token: 'leak' });
  t.authFailure('expired', { token: 'leak' });
  t.crash('boom', { token: 'leak' });
  t.featureUsage('assistant', { token: 'leak' });
  for (const e of events) {
    assert.strictEqual(Object.prototype.hasOwnProperty.call(e.properties, 'token'), false);
  }
});

(async () => {
  let passed = 0;
  for (const item of tests) {
    try {
      await item.fn();
      passed += 1;
      console.log('  ok  ' + item.name);
    } catch (error) {
      console.error('FAIL  ' + item.name + '\n      ' + (error.stack || error.message));
      process.exitCode = 1;
    }
  }
  if (!process.exitCode) console.log(`\n${passed} telemetry tests passed.`);
})();
