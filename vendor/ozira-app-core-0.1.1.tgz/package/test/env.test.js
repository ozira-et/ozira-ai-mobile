'use strict';

const assert = require('assert');
const { ENVIRONMENTS, resolveEnvironment, selectConfig } = require('../src/env');

const tests = [];
function test(name, fn) { tests.push({ name, fn }); }

test('an explicit valid override always wins', () => {
  assert.strictEqual(resolveEnvironment({ explicit: 'staging', hostname: 'ozira.et' }), 'staging');
});

test('an explicit invalid override is ignored, falling through to hostname inference', () => {
  assert.strictEqual(resolveEnvironment({ explicit: 'not-real', hostname: 'localhost' }), 'development');
});

test('localhost/127.0.0.1 infer development', () => {
  assert.strictEqual(resolveEnvironment({ hostname: 'localhost' }), 'development');
  assert.strictEqual(resolveEnvironment({ hostname: '127.0.0.1' }), 'development');
});

test('a hostname containing "staging" infers staging', () => {
  assert.strictEqual(resolveEnvironment({ hostname: 'app-staging.ozira.et' }), 'staging');
});

test('anything else defaults to production -- never silently defaults to development', () => {
  assert.strictEqual(resolveEnvironment({ hostname: 'app.ozira.et' }), 'production');
  assert.strictEqual(resolveEnvironment({}), 'production');
});

test('selectConfig returns the entry for the resolved environment', () => {
  const map = { development: { apiBase: 'http://localhost:3000' }, staging: { apiBase: 'https://staging.example' }, production: { apiBase: 'https://prod.example' } };
  assert.strictEqual(selectConfig(map, 'staging').apiBase, 'https://staging.example');
});

test('selectConfig throws loudly on a missing environment rather than falling back to production', () => {
  const map = { development: { apiBase: 'http://localhost:3000' } };
  assert.throws(() => selectConfig(map, 'staging'), /No app config defined for environment "staging"/);
});

test('ENVIRONMENTS is exactly the three allowed names', () => {
  assert.deepStrictEqual(ENVIRONMENTS, ['development', 'staging', 'production']);
});

(async () => {
  let passed = 0;
  for (const item of tests) {
    try {
      await item.fn();
      passed += 1;
      console.log('  ok  ' + item.name);
    } catch (error) {
      console.error('FAIL  ' + item.name + '\n      ' + (error.stack || error.message));
      process.exitCode = 1;
    }
  }
  if (!process.exitCode) console.log(`\n${passed} environment model tests passed.`);
})();
