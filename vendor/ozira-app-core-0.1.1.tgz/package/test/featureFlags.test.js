'use strict';

const assert = require('assert');
const { createFeatureFlagClient } = require('../src/featureFlags');

const tests = [];
function test(name, fn) { tests.push({ name, fn }); }

test('a boolean flag evaluates directly', () => {
  const c = createFeatureFlagClient({ flags: { a: true, b: false }, platform: 'web', environment: 'development' });
  assert.strictEqual(c.isEnabled('a'), true);
  assert.strictEqual(c.isEnabled('b'), false);
});

test('an unknown flag is off, never throws', () => {
  const c = createFeatureFlagClient({ flags: {}, platform: 'web', environment: 'development' });
  assert.strictEqual(c.isEnabled('does-not-exist'), false);
});

test('a platform-restricted flag only applies to its listed platforms', () => {
  const flags = { newHome: { default: true, platforms: ['ios', 'android'] } };
  assert.strictEqual(createFeatureFlagClient({ flags, platform: 'ios', environment: 'development' }).isEnabled('newHome'), true);
  assert.strictEqual(createFeatureFlagClient({ flags, platform: 'web', environment: 'development' }).isEnabled('newHome'), false);
});

test('a tenant-restricted flag requires a matching tenantId in context', () => {
  const flags = { orgBeta: { default: true, tenants: ['team-a'] } };
  const c = createFeatureFlagClient({ flags, platform: 'web', environment: 'development' });
  assert.strictEqual(c.isEnabled('orgBeta', { tenantId: 'team-a' }), true);
  assert.strictEqual(c.isEnabled('orgBeta', { tenantId: 'team-b' }), false);
  assert.strictEqual(c.isEnabled('orgBeta'), false);
});

test('an environment-restricted flag respects the client environment', () => {
  const flags = { experimental: { default: true, environments: ['development'] } };
  assert.strictEqual(createFeatureFlagClient({ flags, platform: 'web', environment: 'development' }).isEnabled('experimental'), true);
  assert.strictEqual(createFeatureFlagClient({ flags, platform: 'web', environment: 'production' }).isEnabled('experimental'), false);
});

test('createFeatureFlagClient rejects an unknown platform rather than silently accepting typos', () => {
  assert.throws(() => createFeatureFlagClient({ flags: {}, platform: 'smarttv', environment: 'development' }));
});

(async () => {
  let passed = 0;
  for (const item of tests) {
    try {
      await item.fn();
      passed += 1;
      console.log('  ok  ' + item.name);
    } catch (error) {
      console.error('FAIL  ' + item.name + '\n      ' + (error.stack || error.message));
      process.exitCode = 1;
    }
  }
  if (!process.exitCode) console.log(`\n${passed} feature flag tests passed.`);
})();
