'use strict';

const assert = require('assert');
const { validatePrincipal, clientPrincipalFromWhoami } = require('../src/principal');

const tests = [];
function test(name, fn) { tests.push({ name, fn }); }

test('re-exports the SAME canonical Principal validator, not a new one', () => {
  const direct = require('../../ozira-contracts').validatePrincipal;
  assert.strictEqual(validatePrincipal, direct);
});

test('clientPrincipalFromWhoami derives an organization Principal from a real whoami response', () => {
  const principal = clientPrincipalFromWhoami({
    authenticated: true,
    principal_id: 'user-1',
    subject_type: 'USER',
    tenant_id: 'team-a',
    scope_type: 'organization',
    scope_id: 'team-a',
  });
  assert.strictEqual(principal.principalId, 'user-1');
  assert.strictEqual(principal.tenantId, 'team-a');
});

test('clientPrincipalFromWhoami derives a personal Principal for a team-less user', () => {
  const principal = clientPrincipalFromWhoami({
    authenticated: true,
    principal_id: 'user-1',
    subject_type: 'USER',
    tenant_id: null,
  });
  assert.strictEqual(principal.tenantId, undefined);
});

test('clientPrincipalFromWhoami returns null for an unauthenticated response', () => {
  assert.strictEqual(clientPrincipalFromWhoami({ authenticated: false }), null);
  assert.strictEqual(clientPrincipalFromWhoami(null), null);
  assert.strictEqual(clientPrincipalFromWhoami(undefined), null);
  assert.strictEqual(clientPrincipalFromWhoami({}), null);
});

test('clientPrincipalFromWhoami never throws on a malformed response -- returns null instead', () => {
  assert.strictEqual(clientPrincipalFromWhoami({ authenticated: true, principal_id: '' }), null);
  assert.strictEqual(clientPrincipalFromWhoami({ authenticated: true, principal_id: 123 }), null);
  assert.strictEqual(clientPrincipalFromWhoami('not-an-object'), null);
});

test('ATTACK: a whoami-shaped payload cannot smuggle authentication material through', () => {
  // Even if a compromised/forged response carried extra fields, validatePrincipal's
  // allowlist rejects unknown keys -- but this module doesn't even forward them.
  const principal = clientPrincipalFromWhoami({
    authenticated: true,
    principal_id: 'user-1',
    subject_type: 'USER',
    accessToken: 'should-not-matter',
  });
  assert.strictEqual(Object.prototype.hasOwnProperty.call(principal, 'accessToken'), false);
});

(async () => {
  let passed = 0;
  for (const item of tests) {
    try {
      await item.fn();
      passed += 1;
      console.log('  ok  ' + item.name);
    } catch (error) {
      console.error('FAIL  ' + item.name + '\n      ' + (error.stack || error.message));
      process.exitCode = 1;
    }
  }
  if (!process.exitCode) console.log(`\n${passed} principal tests passed.`);
})();
