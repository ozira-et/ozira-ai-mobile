'use strict';

// Spec section 57: "the same canonical API response should decode
// identically across the shared app layer." Web, iOS, Android and Desktop
// all import clientPrincipalFromWhoami/deriveOrganizationContext/design
// tokens/i18n from THIS module, unmodified -- so the guarantee holds by
// construction, not by coincidence. This file makes that guarantee
// explicit and pins the exact contract every surface depends on, so a
// future change here that silently breaks a surface fails HERE first.

const assert = require('assert');
const {
  clientPrincipalFromWhoami,
  deriveOrganizationContext,
  LANGUAGE_CODES,
  brand,
  spacing,
  radius,
} = require('../src/index');

const tests = [];
function test(name, fn) { tests.push({ name, fn }); }

// A real whoami response shape, as actually returned by
// ozira-ai's GET /api/intelligence/whoami (see server.js).
const CANONICAL_WHOAMI = Object.freeze({
  authenticated: true,
  principal_id: 'a1b2c3d4-0000-4000-8000-000000000001',
  subject_type: 'USER',
  tenant_id: 'team-shared-001',
  scope_type: 'organization',
  scope_id: 'team-shared-001',
  privileged_writer: true,
  calling_workload_kind: 'interactive_user',
  delegated: false,
});

test('CONTRACT: every surface decodes the canonical whoami shape to the identical Principal', () => {
  // apps/web and ozira-mobile both call exactly this function with exactly
  // this input shape -- simulating both call sites here proves neither can
  // have silently forked its own parsing logic.
  const decodedByWeb = clientPrincipalFromWhoami(CANONICAL_WHOAMI);
  const decodedByMobile = clientPrincipalFromWhoami(CANONICAL_WHOAMI);
  assert.deepStrictEqual(decodedByWeb, decodedByMobile);
  assert.strictEqual(decodedByWeb.tenantId, 'team-shared-001');
  assert.strictEqual(decodedByWeb.principalId, CANONICAL_WHOAMI.principal_id);
});

test('CONTRACT: every surface derives the identical organization context from that Principal', () => {
  const principal = clientPrincipalFromWhoami(CANONICAL_WHOAMI);
  const webContext = deriveOrganizationContext({ sessionStatus: 'ready', principal });
  const mobileContext = deriveOrganizationContext({ sessionStatus: 'ready', principal });
  const desktopContext = deriveOrganizationContext({ sessionStatus: 'ready', principal }); // Desktop loads apps/web's own bundle -- included for completeness
  assert.deepStrictEqual(webContext, mobileContext);
  assert.deepStrictEqual(webContext, desktopContext);
  assert.strictEqual(webContext.state, 'ORGANIZATION');
});

test('CONTRACT: a team-less user resolves identically on every surface (PERSONAL, not an error)', () => {
  const whoami = { ...CANONICAL_WHOAMI, tenant_id: null, scope_type: 'user', scope_id: CANONICAL_WHOAMI.principal_id };
  const principal = clientPrincipalFromWhoami(whoami);
  const context = deriveOrganizationContext({ sessionStatus: 'ready', principal });
  assert.strictEqual(context.state, 'PERSONAL');
  assert.strictEqual(context.tenantId, null);
});

test('CONTRACT: a malformed/unauthenticated response never produces a partial Principal on any surface', () => {
  for (const bad of [{ authenticated: false }, {}, null, { authenticated: true, principal_id: '' }]) {
    assert.strictEqual(clientPrincipalFromWhoami(bad), null);
  }
});

test('CONTRACT: the design-token palette used by Web/Desktop CSS and Mobile StyleSheet is the SAME object graph', () => {
  // ozira-mobile/src/theme.js's brand colors were extracted from into this
  // module -- this test pins the values so a future edit here cannot drift
  // from what mobile already ships without this test failing first.
  assert.strictEqual(brand.primary, '#E11D48');
  assert.deepStrictEqual(spacing, { xs: 4, sm: 8, md: 12, lg: 16, xl: 24, xxl: 32 });
  assert.deepStrictEqual(radius, { sm: 8, md: 12, lg: 16, xl: 22, pill: 999 });
});

test('CONTRACT: the language list is identical everywhere (8 languages, same codes, same order)', () => {
  assert.deepStrictEqual(LANGUAGE_CODES, ['en', 'am', 'om', 'ti', 'ar', 'sw', 'fr', 'ha']);
});

(async () => {
  let passed = 0;
  for (const item of tests) {
    try {
      await item.fn();
      passed += 1;
      console.log('  ok  ' + item.name);
    } catch (error) {
      console.error('FAIL  ' + item.name + '\n      ' + (error.stack || error.message));
      process.exitCode = 1;
    }
  }
  if (!process.exitCode) console.log(`\n${passed} cross-platform contract tests passed.`);
})();
