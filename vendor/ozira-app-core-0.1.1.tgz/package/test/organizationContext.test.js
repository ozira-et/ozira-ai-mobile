'use strict';

const assert = require('assert');
const { STATES, deriveOrganizationContext, hasResolvedScope } = require('../src/organizationContext');
const { clientPrincipalFromWhoami } = require('../src/principal');

const tests = [];
function test(name, fn) { tests.push({ name, fn }); }

function orgPrincipal(tenantId) {
  // principal_id must satisfy ozira-contracts' ID_PATTERN (min 6 chars) --
  // real Supabase user ids are UUIDs, far longer than this fixture.
  return clientPrincipalFromWhoami({ authenticated: true, principal_id: 'user-001', subject_type: 'USER', tenant_id: tenantId || null });
}

test('loading session -> LOADING state, regardless of principal', () => {
  const ctx = deriveOrganizationContext({ sessionStatus: 'loading', principal: null });
  assert.strictEqual(ctx.state, STATES.LOADING);
  assert.strictEqual(hasResolvedScope(ctx), false);
});

test('signed out / error session -> UNAUTHORIZED', () => {
  assert.strictEqual(deriveOrganizationContext({ sessionStatus: 'error', principal: null }).state, STATES.UNAUTHORIZED);
  assert.strictEqual(deriveOrganizationContext({ sessionStatus: 'ready', principal: null }).state, STATES.UNAUTHORIZED);
});

test('user with tenantId -> ORGANIZATION context carrying that exact tenantId', () => {
  const ctx = deriveOrganizationContext({ sessionStatus: 'ready', principal: orgPrincipal('team-a') });
  assert.strictEqual(ctx.state, STATES.ORGANIZATION);
  assert.strictEqual(ctx.tenantId, 'team-a');
  assert.strictEqual(hasResolvedScope(ctx), true);
});

test('team-less user -> PERSONAL context, not an error', () => {
  const ctx = deriveOrganizationContext({ sessionStatus: 'ready', principal: orgPrincipal(null) });
  assert.strictEqual(ctx.state, STATES.PERSONAL);
  assert.strictEqual(ctx.tenantId, null);
  assert.strictEqual(hasResolvedScope(ctx), true);
});

test('ATTACK: there is no parameter through which a raw tenantId reaches the context', () => {
  // The function signature only accepts {sessionStatus, principal} -- a caller
  // cannot pass tenantId directly, so "forging" a tenant means forging a whole
  // validated Principal, which clientPrincipalFromWhoami only ever produces
  // from a real backend response shape.
  const params = deriveOrganizationContext.length;
  assert.strictEqual(params, 1);
  const source = deriveOrganizationContext.toString();
  assert.ok(!source.includes('arguments[1]'), 'no hidden second parameter');
});

test('two different tenantIds never collide', () => {
  const a = deriveOrganizationContext({ sessionStatus: 'ready', principal: orgPrincipal('team-a') });
  const b = deriveOrganizationContext({ sessionStatus: 'ready', principal: orgPrincipal('team-b') });
  assert.notStrictEqual(a.tenantId, b.tenantId);
});

(async () => {
  let passed = 0;
  for (const item of tests) {
    try {
      await item.fn();
      passed += 1;
      console.log('  ok  ' + item.name);
    } catch (error) {
      console.error('FAIL  ' + item.name + '\n      ' + (error.stack || error.message));
      process.exitCode = 1;
    }
  }
  if (!process.exitCode) console.log(`\n${passed} organization context tests passed.`);
})();
