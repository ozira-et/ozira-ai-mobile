'use strict';

const assert = require('assert');
const { createApiClient } = require('../src/apiClient');
const { CODES } = require('../src/errors');

const tests = [];
function test(name, fn) { tests.push({ name, fn }); }

function jsonResponse(status, body) {
  return { ok: status >= 200 && status < 300, status, json: async () => body };
}

function client(fetchImpl, overrides) {
  return createApiClient({
    baseUrl: 'https://api.example.invalid',
    getToken: () => 'test-token',
    fetchImpl,
    ...overrides,
  });
}

test('a successful GET returns decoded data and a correlation id', async () => {
  let seenHeaders = null;
  const c = client(async (url, init) => {
    seenHeaders = init.headers;
    return jsonResponse(200, { ok: true, value: 42 });
  });
  const result = await c.call('/api/intelligence/whoami');
  assert.strictEqual(result.data.value, 42);
  assert.ok(result.correlationId.startsWith('req_'));
  assert.ok(seenHeaders['x-request-id']);
  assert.strictEqual(seenHeaders.authorization, 'Bearer test-token');
});

test('401 classifies as UNAUTHENTICATED', async () => {
  const c = client(async () => jsonResponse(401, { error: 'nope' }));
  await assert.rejects(() => c.call('/api/x'), (e) => e.code === CODES.UNAUTHENTICATED);
});

test('a 401 refreshes the session once and replays the rejected request', async () => {
  let calls = 0;
  let refreshes = 0;
  const c = client(async (url, init) => {
    calls += 1;
    if (calls === 1) {
      assert.strictEqual(init.headers.authorization, 'Bearer test-token');
      return jsonResponse(401, { error: 'expired' });
    }
    assert.strictEqual(init.headers.authorization, 'Bearer test-token');
    return jsonResponse(200, { recovered: true });
  }, {
    refreshToken: async () => { refreshes += 1; return 'refreshed-token'; },
  });
  const result = await c.call('/api/chat', { method: 'POST', body: { message: 'hello' } });
  assert.strictEqual(result.data.recovered, true);
  assert.strictEqual(calls, 2);
  assert.strictEqual(refreshes, 1);
});

test('a persistent 401 does not refresh or replay more than once', async () => {
  let calls = 0;
  let refreshes = 0;
  const c = client(async () => { calls += 1; return jsonResponse(401, {}); }, {
    refreshToken: async () => { refreshes += 1; return 'refreshed-token'; },
  });
  await assert.rejects(() => c.call('/api/chat', { method: 'POST', body: { message: 'hello' } }), (e) => e.code === CODES.UNAUTHENTICATED);
  assert.strictEqual(calls, 2);
  assert.strictEqual(refreshes, 1);
});

test('403 classifies as FORBIDDEN', async () => {
  const c = client(async () => jsonResponse(403, {}));
  await assert.rejects(() => c.call('/api/x'), (e) => e.code === CODES.FORBIDDEN);
});

test('404 classifies as NOT_FOUND', async () => {
  const c = client(async () => jsonResponse(404, {}));
  await assert.rejects(() => c.call('/api/x'), (e) => e.code === CODES.NOT_FOUND);
});

test('422 classifies as VALIDATION', async () => {
  const c = client(async () => jsonResponse(422, { error: 'bad field' }));
  await assert.rejects(() => c.call('/api/x'), (e) => e.code === CODES.VALIDATION && e.message === 'bad field');
});

test('a thrown network error classifies as NETWORK', async () => {
  const c = client(async () => { throw new TypeError('fetch failed'); });
  await assert.rejects(() => c.call('/api/x'), (e) => e.code === CODES.NETWORK);
});

test('offline: repeated network failure on a retry-eligible GET still surfaces NETWORK, not a crash', async () => {
  const c = client(async () => { throw new TypeError('fetch failed'); });
  await assert.rejects(() => c.call('/api/x', { retry: true }), (e) => e.code === CODES.NETWORK);
});

test('a transient 5xx on a retry-eligible GET is retried once and can succeed', async () => {
  let calls = 0;
  const c = client(async () => {
    calls += 1;
    if (calls === 1) return jsonResponse(503, { error: 'busy' });
    return jsonResponse(200, { ok: true });
  });
  const result = await c.call('/api/x', { retry: true });
  assert.strictEqual(calls, 2);
  assert.strictEqual(result.data.ok, true);
});

test('a persistent 5xx on a retry-eligible GET fails after the retry budget, not forever', async () => {
  let calls = 0;
  const c = client(async () => { calls += 1; return jsonResponse(503, {}); });
  await assert.rejects(() => c.call('/api/x', { retry: true }), (e) => e.code === CODES.TEMPORARY_SERVICE_FAILURE);
  assert.strictEqual(calls, 2);
});

test('NO UNSAFE AUTOMATIC RETRY: a POST is never retried even if `retry: true` is passed', async () => {
  let calls = 0;
  const c = client(async () => { calls += 1; return jsonResponse(503, {}); });
  await assert.rejects(
    () => c.call('/api/consequential', { method: 'POST', body: { x: 1 }, retry: true }),
    (e) => e.code === CODES.TEMPORARY_SERVICE_FAILURE,
  );
  assert.strictEqual(calls, 1, 'a write must attempt exactly once, retry flag notwithstanding');
});

test('a malformed (non-JSON) success response does not crash the client', async () => {
  const c = client(async () => ({
    ok: true, status: 200, json: async () => { throw new SyntaxError('Unexpected token'); },
  }));
  const result = await c.call('/api/x');
  assert.strictEqual(result.data, null);
});

test('a malformed (non-JSON) error response still classifies from the status code', async () => {
  const c = client(async () => ({
    ok: false, status: 500, json: async () => { throw new SyntaxError('Unexpected token'); },
  }));
  await assert.rejects(() => c.call('/api/x'), (e) => e.code === CODES.TEMPORARY_SERVICE_FAILURE);
});

test('a call can use a longer per-request timeout for provider fallback cycles', async () => {
  const c = client(async (_url, init) => await new Promise((resolve, reject) => {
    init.signal.addEventListener('abort', () => {
      const error = new Error('aborted');
      error.name = 'AbortError';
      reject(error);
    }, { once: true });
  }));
  await assert.rejects(() => c.call('/api/chat', { method: 'POST', body: { message: 'hello' }, timeoutMs: 10 }), (e) => e.code === CODES.TIMEOUT);
});

test('a hanging token lookup is bounded by the per-request timeout', async () => {
  const c = client(async () => jsonResponse(200, { ok: true }), {
    getToken: () => new Promise(() => {}),
  });
  await assert.rejects(() => c.call('/api/chat', { method: 'POST', body: { message: 'hello' }, timeoutMs: 10 }), (e) => e.code === CODES.TIMEOUT);
});

test('createApiClient refuses to construct without a baseUrl', () => {
  assert.throws(() => createApiClient({ getToken: () => null, fetchImpl: async () => {} }));
});

test('an unauthenticated caller (no token) sends no Authorization header at all', async () => {
  let seenHeaders = null;
  const c = client(async (url, init) => { seenHeaders = init.headers; return jsonResponse(200, {}); }, { getToken: () => null });
  await c.call('/api/x');
  assert.strictEqual(Object.prototype.hasOwnProperty.call(seenHeaders, 'authorization'), false);
});

(async () => {
  let passed = 0;
  for (const item of tests) {
    try {
      await item.fn();
      passed += 1;
      console.log('  ok  ' + item.name);
    } catch (error) {
      console.error('FAIL  ' + item.name + '\n      ' + (error.stack || error.message));
      process.exitCode = 1;
    }
  }
  if (!process.exitCode) console.log(`\n${passed} API client tests passed.`);
})();
