'use strict';

const assert = require('assert');
const { brand, darkColors, lightColors, getPalette, spacing, radius, typography, toCssVariables } = require('../src/designTokens');

const tests = [];
function test(name, fn) { tests.push({ name, fn }); }

test('brand colors match ozira-mobile/src/theme.js verbatim', () => {
  assert.strictEqual(brand.primary, '#E11D48');
  assert.strictEqual(brand.secondary, '#FF3D71');
  assert.strictEqual(brand.accent, '#7C3AED');
});

test('dark and light palettes both carry the brand colors unchanged', () => {
  assert.strictEqual(darkColors.primary, brand.primary);
  assert.strictEqual(lightColors.primary, brand.primary);
});

test('getPalette selects the correct mode, defaulting to dark', () => {
  assert.strictEqual(getPalette('light'), lightColors);
  assert.strictEqual(getPalette('dark'), darkColors);
  assert.strictEqual(getPalette(undefined), darkColors);
});

test('spacing and radius scales match ozira-mobile/src/theme.js verbatim', () => {
  assert.deepStrictEqual(spacing, { xs: 4, sm: 8, md: 12, lg: 16, xl: 24, xxl: 32 });
  assert.deepStrictEqual(radius, { sm: 8, md: 12, lg: 16, xl: 22, pill: 999 });
});

test('typography scale is ordered smallest to largest', () => {
  const values = Object.values(typography.scale);
  const sorted = [...values].sort((a, b) => a - b);
  assert.deepStrictEqual(values, sorted);
});

test('toCssVariables produces --ozira-prefixed custom properties for both modes', () => {
  const dark = toCssVariables('dark');
  const light = toCssVariables('light');
  assert.strictEqual(dark['--ozira-color-primary'], brand.primary);
  assert.strictEqual(dark['--ozira-color-bg'], darkColors.bg);
  assert.strictEqual(light['--ozira-color-bg'], lightColors.bg);
  assert.strictEqual(dark['--ozira-space-md'], '12px');
  assert.strictEqual(dark['--ozira-radius-pill'], '999px');
});

test('tokens are frozen -- a consuming surface cannot mutate the shared source of truth', () => {
  assert.throws(() => { brand.primary = '#000000'; });
  assert.strictEqual(brand.primary, '#E11D48');
});

(async () => {
  let passed = 0;
  for (const item of tests) {
    try {
      await item.fn();
      passed += 1;
      console.log('  ok  ' + item.name);
    } catch (error) {
      console.error('FAIL  ' + item.name + '\n      ' + (error.stack || error.message));
      process.exitCode = 1;
    }
  }
  if (!process.exitCode) console.log(`\n${passed} design token tests passed.`);
})();
