'use strict';

// Shared, machine-readable client error taxonomy (spec section 21).
// Every surface (Web/iOS/Android/Desktop) sees the SAME codes, so UI error
// handling is written once against this taxonomy rather than once per
// platform against raw HTTP status codes.

const CODES = Object.freeze({
  UNAUTHENTICATED: 'UNAUTHENTICATED',
  FORBIDDEN: 'FORBIDDEN',
  NOT_FOUND: 'NOT_FOUND',
  VALIDATION: 'VALIDATION',
  NETWORK: 'NETWORK',
  TIMEOUT: 'TIMEOUT',
  RATE_LIMITED: 'RATE_LIMITED',
  QUOTA_EXCEEDED: 'QUOTA_EXCEEDED',
  MAPS_DATA_UNAVAILABLE: 'MAPS_DATA_UNAVAILABLE',
  TEMPORARY_SERVICE_FAILURE: 'TEMPORARY_SERVICE_FAILURE',
  UNKNOWN: 'UNKNOWN',
});

class AppError extends Error {
  constructor(code, message, details) {
    super(message || code);
    this.name = 'AppError';
    this.code = CODES[code] ? code : CODES.UNKNOWN;
    // `details` is for UI/debug context only. Never place a token, header
    // value, or raw server stack trace here -- see the redaction rule
    // telemetry.js shares with this module.
    this.details = details && typeof details === 'object' ? details : {};
  }

  toJSON() {
    return { code: this.code, message: this.message, details: this.details };
  }
}

/** HTTP status -> taxonomy code. Server-provided `code` wins when present. */
function classifyHttpError(status, body) {
  const serverCode = body && typeof body === 'object' ? body.code : null;
  if (typeof serverCode === 'string' && CODES[serverCode]) {
    return new AppError(serverCode, (body && (body.message || body.error)) || serverCode, safeDetails(body));
  }
  if (status === 401) return new AppError('UNAUTHENTICATED', 'Sign in required.', safeDetails(body));
  if (status === 403) return new AppError('FORBIDDEN', 'Not permitted.', safeDetails(body));
  if (status === 404) return new AppError('NOT_FOUND', 'Not found.', safeDetails(body));
  if (status === 422 || status === 400) return new AppError('VALIDATION', (body && body.error) || 'Invalid request.', safeDetails(body));
  if (status === 408) return new AppError('TIMEOUT', 'The request timed out.', safeDetails(body));
  if (status >= 500) return new AppError('TEMPORARY_SERVICE_FAILURE', 'The service is temporarily unavailable.', safeDetails(body));
  return new AppError('UNKNOWN', (body && body.error) || `Request failed (${status}).`, safeDetails(body));
}

/** Network-layer failure (no HTTP response at all). */
function classifyTransportError(error) {
  if (error && error.name === 'AbortError') return new AppError('TIMEOUT', 'The request timed out.');
  return new AppError('NETWORK', 'Could not reach the OZIRA service.');
}

// Never let a stack trace, token, or authorization header ride along on an
// error surfaced to UI code -- only a small denylist-checked subset of the
// server body survives.
const FORBIDDEN_DETAIL_KEYS = /token|secret|password|authorization|credential/i;
function safeDetails(body) {
  if (!body || typeof body !== 'object') return {};
  const out = {};
  for (const [key, value] of Object.entries(body)) {
    if (key === 'error' || key === 'message' || key === 'code') continue;
    if (FORBIDDEN_DETAIL_KEYS.test(key)) continue;
    if (typeof value === 'string' && value.length > 500) continue; // no raw stacks
    out[key] = value;
  }
  return out;
}

module.exports = { CODES, AppError, classifyHttpError, classifyTransportError };
