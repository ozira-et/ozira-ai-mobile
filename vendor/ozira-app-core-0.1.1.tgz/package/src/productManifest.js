'use strict';

// Product Experience Manifests (Figma 61:218) -- the shared platform's
// declaration of what each specialized product LOOKS LIKE and OFFERS TO
// SHOW: its primary work object, navigation, artifact types, surfaced
// tools, composer shape, and routing/telemetry defaults.
//
// A manifest is a display/capability-surfacing contract only. It is NEVER
// authorization. Whether GitHub appears as a surfaced tool in Code is a
// manifest decision; whether the current Principal is allowed to use GitHub
// is a server-side policy decision made independently, every time, and a
// manifest entry existing must never be treated as proof of it.

const PRODUCT_IDS = Object.freeze(['assistant', 'code', 'design', 'p', 'forward']);

const MANIFESTS = Object.freeze({
  assistant: Object.freeze({
    productId: 'assistant',
    displayName: 'Assistant',
    primaryObject: 'conversation',
    workspaceType: 'conversation-thread',
    navigation: Object.freeze(['new-chat', 'search', 'projects', 'pinned', 'recent', 'archived']),
    artifactTypes: Object.freeze(['code', 'diff', 'image', 'document', 'report']),
    rendererMap: Object.freeze({
      code: 'CodeRenderer', diff: 'CodeRenderer', image: 'ImageRenderer',
      document: 'DocumentRenderer', report: 'DocumentRenderer',
    }),
    surfacedTools: Object.freeze(['web-search', 'image-generation', 'connectors', 'voice']),
    composerCapabilities: Object.freeze(['text', 'upload', 'connectors', 'voice', 'tools-menu']),
    defaultAgentPolicy: 'conversational',
    modelRoutingPolicy: 'auto',
    featureFlags: Object.freeze([]),
    telemetryNamespace: 'assistant',
    responsiveContract: 'sidebar-collapsible',
  }),
  code: Object.freeze({
    productId: 'code',
    displayName: 'Code',
    primaryObject: 'repository',
    workspaceType: 'repository-workspace',
    navigation: Object.freeze(['repository-explorer', 'editor', 'diff', 'agent']),
    artifactTypes: Object.freeze(['code', 'diff', 'deployment-result']),
    rendererMap: Object.freeze({ code: 'CodeRenderer', diff: 'CodeRenderer', 'deployment-result': 'CodeRenderer' }),
    surfacedTools: Object.freeze(['terminal', 'tests', 'deployments']),
    composerCapabilities: Object.freeze(['text', 'tools-menu']),
    defaultAgentPolicy: 'coding-agent',
    modelRoutingPolicy: 'code-optimized',
    featureFlags: Object.freeze([]),
    telemetryNamespace: 'code',
    responsiveContract: 'panes-stack-on-mobile',
  }),
  design: Object.freeze({
    productId: 'design',
    displayName: 'Design',
    primaryObject: 'canvas',
    workspaceType: 'canvas-workspace',
    navigation: Object.freeze(['pages', 'assets', 'canvas', 'layers', 'properties']),
    artifactTypes: Object.freeze(['design', 'image']),
    rendererMap: Object.freeze({ design: 'DesignRenderer', image: 'ImageRenderer' }),
    surfacedTools: Object.freeze(['export']),
    composerCapabilities: Object.freeze([]),
    defaultAgentPolicy: 'none',
    modelRoutingPolicy: 'image-optimized',
    featureFlags: Object.freeze([]),
    telemetryNamespace: 'design',
    responsiveContract: 'canvas-fullbleed-on-mobile',
  }),
  p: Object.freeze({
    productId: 'p',
    displayName: 'P',
    primaryObject: 'evidence',
    workspaceType: 'intelligence-workspace',
    navigation: Object.freeze(['sources', 'workspace', 'provenance']),
    artifactTypes: Object.freeze(['evidence', 'report']),
    rendererMap: Object.freeze({ evidence: 'EvidenceRenderer', report: 'EvidenceRenderer' }),
    surfacedTools: Object.freeze([]),
    composerCapabilities: Object.freeze([]),
    defaultAgentPolicy: 'none',
    modelRoutingPolicy: 'none',
    featureFlags: Object.freeze([]),
    telemetryNamespace: 'p',
    responsiveContract: 'panes-stack-on-mobile',
  }),
  forward: Object.freeze({
    productId: 'forward',
    displayName: 'Forward',
    primaryObject: 'workflow',
    workspaceType: 'workflow-workspace',
    navigation: Object.freeze(['plans', 'board', 'runs']),
    artifactTypes: Object.freeze(['workflow', 'task']),
    rendererMap: Object.freeze({ workflow: 'ForwardRenderer', task: 'ForwardRenderer' }),
    surfacedTools: Object.freeze([]),
    composerCapabilities: Object.freeze([]),
    defaultAgentPolicy: 'none',
    modelRoutingPolicy: 'none',
    featureFlags: Object.freeze([]),
    telemetryNamespace: 'forward',
    responsiveContract: 'panes-stack-on-mobile',
  }),
});

function getManifest(productId) {
  const manifest = MANIFESTS[productId];
  if (!manifest) throw new Error(`Unknown product: ${productId}`);
  return manifest;
}

function listManifests() {
  return PRODUCT_IDS.map((id) => MANIFESTS[id]);
}

// Answers only "does this product's manifest offer to show this tool" --
// deliberately narrow so callers can't mistake a true result for
// authorization. The real authorization check is a separate, server-side
// call that must still run before the tool is treated as usable.
function manifestSurfacesTool(productId, toolId) {
  return getManifest(productId).surfacedTools.includes(toolId);
}

function manifestRendererFor(productId, artifactType) {
  const manifest = getManifest(productId);
  if (!manifest.artifactTypes.includes(artifactType)) return null;
  return manifest.rendererMap[artifactType] || null;
}

module.exports = {
  PRODUCT_IDS,
  MANIFESTS,
  getManifest,
  listManifests,
  manifestSurfacesTool,
  manifestRendererFor,
};
