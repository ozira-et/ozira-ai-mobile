'use strict';

// Shared telemetry contracts (spec sections 38-39). This module shapes and
// redacts events; it does not transport them -- `sink(event)` is injected so
// each platform can point at whatever collector it uses (or none, in dev).

const EVENT_TYPES = Object.freeze([
  'app_start',
  'screen_view',
  'api_latency',
  'api_failure',
  'auth_failure',
  'crash',
  'feature_usage',
]);

// Applied to every event's `properties` before it reaches `sink`. Matches
// the same denylist spirit as errors.js's safeDetails -- independently
// enforced here because telemetry has a different, wider blast radius
// (it leaves the device) than an in-memory error object does.
const FORBIDDEN_PROPERTY_KEYS = /token|secret|password|authorization|credential|jwt|prompt|content|document/i;

function redactProperties(properties) {
  if (!properties || typeof properties !== 'object') return {};
  const out = {};
  for (const [key, value] of Object.entries(properties)) {
    if (FORBIDDEN_PROPERTY_KEYS.test(key)) continue;
    if (typeof value === 'string' && value.length > 200) continue; // no bulk content
    out[key] = value;
  }
  return out;
}

/**
 * @param {object} options
 * @param {(event: object) => void} options.sink
 * @param {'web'|'ios'|'android'|'desktop'} options.platform
 * @param {string} options.appVersion
 */
function createTelemetryClient(options) {
  const opts = options || {};
  const sink = typeof opts.sink === 'function' ? opts.sink : () => {};
  const platform = opts.platform;
  const appVersion = opts.appVersion || 'unknown';

  function track(type, properties) {
    if (!EVENT_TYPES.includes(type)) return; // unknown event types are silently dropped, not thrown
    sink({
      type,
      platform,
      appVersion,
      timestamp: Date.now(),
      properties: redactProperties(properties),
    });
  }

  return {
    track,
    appStart: (properties) => track('app_start', properties),
    screenView: (screenName, properties) => track('screen_view', { screen: screenName, ...properties }),
    apiLatency: (endpoint, durationMs, properties) => track('api_latency', { endpoint, durationMs, ...properties }),
    apiFailure: (endpoint, code, properties) => track('api_failure', { endpoint, code, ...properties }),
    authFailure: (reason, properties) => track('auth_failure', { reason, ...properties }),
    crash: (message, properties) => track('crash', { message, ...properties }),
    featureUsage: (feature, properties) => track('feature_usage', { feature, ...properties }),
  };
}

module.exports = { EVENT_TYPES, redactProperties, createTelemetryClient };
