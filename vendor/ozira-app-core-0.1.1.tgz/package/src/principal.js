'use strict';

// Client-side Principal handling.
//
// TRUST RULE (see docs/app-platform/adr/0001, section 16 of the phase spec):
// nothing in this module is security authority. `validatePrincipal` from
// ozira-contracts is the same shape-validation used server-side, but shape
// validity is not authentication -- only the backend's verified session
// (Supabase token -> resolveAuthUser -> Principal) is authoritative. A
// client that "validates" a Principal-shaped object it received from a
// server response is confirming the response is well-formed, not granting
// itself anything.
//
// There is deliberately no `WebPrincipal`/`MobilePrincipal`/`DesktopPrincipal`.
// Every surface understands the same shape.

const { validatePrincipal } = require('../../ozira-contracts');

/**
 * Derive a client-side Principal VIEW from the backend's `/api/intelligence/whoami`
 * response (or any endpoint returning the same shape). This is UI/context
 * information only -- see organizationContext.js for how it is consumed, and
 * note it is never re-sent to the backend as an authority claim.
 *
 * Returns null for a malformed/unauthenticated response rather than throwing,
 * because callers use this to decide UI state, not to gate a security check.
 */
function clientPrincipalFromWhoami(whoami) {
  if (!whoami || typeof whoami !== 'object' || whoami.authenticated !== true) return null;
  if (typeof whoami.principal_id !== 'string' || !whoami.principal_id) return null;

  const candidate = {
    schemaVersion: 1,
    principalId: whoami.principal_id,
    subjectType: whoami.subject_type || 'USER',
  };
  if (whoami.tenant_id) candidate.tenantId = whoami.tenant_id;
  if (whoami.role) candidate.role = whoami.role;

  try {
    return validatePrincipal(candidate);
  } catch (_) {
    // A malformed shape from the backend is a display problem, not a client
    // security event -- render "unknown" rather than crash the app.
    return null;
  }
}

module.exports = { validatePrincipal, clientPrincipalFromWhoami };
