'use strict';

// Shared organization/personal-context state machine (spec section 22).
//
// A client can never manufacture organization authority: this module only
// DERIVES a UI state from an already-resolved Principal view (see
// principal.js). It has no path that accepts a caller-supplied tenantId and
// treats it as real -- the only tenantId this module ever sees is the one
// already present on a Principal that came from the backend.

const STATES = Object.freeze({
  LOADING: 'LOADING',
  UNAUTHORIZED: 'UNAUTHORIZED',
  PERSONAL: 'PERSONAL',
  ORGANIZATION: 'ORGANIZATION',
  NO_ORGANIZATION: 'NO_ORGANIZATION',
});

/**
 * @param {object} params
 * @param {'idle'|'loading'|'ready'|'error'} params.sessionStatus
 * @param {object|null} params.principal - output of clientPrincipalFromWhoami(), or null
 */
function deriveOrganizationContext({ sessionStatus, principal }) {
  if (sessionStatus === 'loading' || sessionStatus === 'idle') {
    return { state: STATES.LOADING, tenantId: null, principal: null };
  }
  if (sessionStatus === 'error' || !principal) {
    return { state: STATES.UNAUTHORIZED, tenantId: null, principal: null };
  }
  if (principal.tenantId) {
    return { state: STATES.ORGANIZATION, tenantId: principal.tenantId, principal };
  }
  // A signed-in user with no tenantId is NOT an error state -- every OZIRA
  // producer writes `user.teamId || null`, so a team-less user is expected
  // and gets a valid personal scope (matches server-side IntelligenceScopeResolver).
  return { state: STATES.PERSONAL, tenantId: null, principal };
}

/**
 * True only when the derived context has a resolvable scope to act in.
 * NO_ORGANIZATION is reserved for a future explicit "org required, none
 * selected" flow -- deriveOrganizationContext never returns it today because
 * every current backend read path accepts a personal fallback. Kept in
 * STATES so a future gated feature can use it without a breaking change.
 */
function hasResolvedScope(context) {
  return context.state === STATES.PERSONAL || context.state === STATES.ORGANIZATION;
}

module.exports = { STATES, deriveOrganizationContext, hasResolvedScope };
