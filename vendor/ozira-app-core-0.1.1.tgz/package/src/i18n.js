'use strict';

// Shared i18n/RTL foundation (spec sections 30-32), generalized from the
// mature implementation already shipping in ozira-mobile/src/i18n.js. The
// LANGUAGE LIST, RTL determination, and lookup-with-fallback ALGORITHM are
// shared verbatim; each surface still supplies its own string dictionary
// (a Web/Desktop settings screen and a native mobile screen do not share
// enough UI text to make one giant cross-platform dictionary worthwhile at
// foundation stage -- forcing that now would be exactly the "fragile
// abstraction" spec section 48 warns against). What must never drift
// between platforms is *which* languages exist and *which* are RTL; that is
// what lives here.
//
// UI localization vs AI/model output language (section 32): this module is
// UI-only. What language the assistant chooses to reply in is a backend/
// model concern and has no dependency on anything in this file.

const LANGUAGES = Object.freeze([
  { code: 'en', label: 'English', native: 'English', flag: '🇬🇧' },
  { code: 'am', label: 'Amharic', native: 'አማርኛ', flag: '🇪🇹' },
  { code: 'om', label: 'Afaan Oromoo', native: 'Afaan Oromoo', flag: '🇪🇹' },
  { code: 'ti', label: 'Tigrinya', native: 'ትግርኛ', flag: '🇪🇹' },
  { code: 'ar', label: 'Arabic', native: 'العربية', flag: '🇸🇦' },
  { code: 'sw', label: 'Swahili', native: 'Kiswahili', flag: '🇰🇪' },
  { code: 'fr', label: 'French', native: 'Français', flag: '🇫🇷' },
  { code: 'ha', label: 'Hausa', native: 'Hausa', flag: '🇳🇬' },
]);

const LANGUAGE_CODES = Object.freeze(LANGUAGES.map((l) => l.code));
const DEFAULT_LANGUAGE = 'en';

// Same reasoning as ozira-mobile: RTL is applied per-element via style
// helpers, never via a native "force RTL + restart" mechanism, so a
// language switch is instant on every surface, not just mobile.
const RTL_LANGS = Object.freeze(['ar']);
function isRTL(lang) { return RTL_LANGS.includes(lang); }

function langName(code) {
  const found = LANGUAGES.find((l) => l.code === code);
  return found ? found.native : LANGUAGES.find((l) => l.code === DEFAULT_LANGUAGE).native;
}

/**
 * Generic RTL-aware directional-property helper. Returns plain objects with
 * LOGICAL keys (`flexDirection`, `textAlign`) that both React Native
 * StyleSheet objects and CSS-in-JS/inline-style objects understand
 * identically -- no platform-specific style API leaks into this module.
 */
function rtlStyles(rtl) {
  return {
    text: rtl ? { textAlign: 'right', writingDirection: 'rtl' } : {},
    row: rtl ? { flexDirection: 'row-reverse' } : {},
    align: rtl ? { alignItems: 'flex-end' } : {},
  };
}

/** Mirror a directional icon/glyph name (chevrons/arrows) for RTL. */
function rtlIconName(name, rtl) {
  if (!rtl || typeof name !== 'string') return name;
  if (name.includes('forward')) return name.replace('forward', 'back');
  if (name.includes('back')) return name.replace('back', 'forward');
  return name;
}

/**
 * Look up `key` in `dictionary[lang]`, falling back to `dictionary[DEFAULT_LANGUAGE]`,
 * then to the key itself so a missing translation is visible, not blank.
 * `vars` does simple `{name}` interpolation, matching the mobile convention.
 */
function translate(dictionary, lang, key, vars) {
  const dict = dictionary || {};
  const table = dict[lang] || dict[DEFAULT_LANGUAGE] || {};
  let value = table[key];
  if (value === undefined) value = (dict[DEFAULT_LANGUAGE] || {})[key];
  if (value === undefined) return key;
  if (!vars) return value;
  return Object.keys(vars).reduce(
    (acc, varName) => acc.split(`{${varName}}`).join(String(vars[varName])),
    value,
  );
}

function isSupportedLanguage(code) {
  return LANGUAGE_CODES.includes(code);
}

module.exports = {
  LANGUAGES,
  LANGUAGE_CODES,
  DEFAULT_LANGUAGE,
  RTL_LANGS,
  isRTL,
  isSupportedLanguage,
  langName,
  rtlStyles,
  rtlIconName,
  translate,
};
