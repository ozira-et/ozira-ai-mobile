'use strict';

// ozira-app-core — shared application-layer foundation reused across Web,
// iOS, Android and Desktop. See docs/app-platform/adr/0001 for why this
// package exists and what it deliberately excludes.

const principal = require('./principal');
const organizationContext = require('./organizationContext');
const errors = require('./errors');
const apiClient = require('./apiClient');
const featureFlags = require('./featureFlags');
const telemetry = require('./telemetry');
const i18n = require('./i18n');
const designTokens = require('./designTokens');
const env = require('./env');
const productManifest = require('./productManifest');

module.exports = {
  ...principal,
  ...organizationContext,
  ...errors,
  ...apiClient,
  ...featureFlags,
  ...telemetry,
  ...i18n,
  ...designTokens,
  ...env,
  ...productManifest,
};
