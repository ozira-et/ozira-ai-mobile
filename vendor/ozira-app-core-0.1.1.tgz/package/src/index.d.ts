// TypeScript's inference of the aggregate `module.exports = {...a, ...b, ...}`
// spread in index.js becomes unreliable as more source modules are added --
// TS silently drops later spread members from the inferred type rather than
// erroring, which is worse than a build failure. Re-exporting each module
// directly sidesteps that: every individual module here infers cleanly on
// its own (proven by every export before productManifest already working),
// this file just fans that out through the package's public entry point
// instead of forcing TS to re-derive it from a 10-way object spread.
export * from './principal';
export * from './organizationContext';
export * from './errors';
export * from './apiClient';
export * from './featureFlags';
export * from './telemetry';
export * from './i18n';
export * from './designTokens';
export * from './env';

// Hand-written, not inferred from productManifest.js: TypeScript's JS
// inference of that module's frozen, deeply-nested MANIFESTS object was
// silently failing to surface these members through re-export chains (every
// route tried -- export *, named re-export, direct .js inference through a
// paths alias -- hit the same "property does not exist" downstream). An
// explicit signature sidesteps whatever in that inference was failing,
// rather than continuing to chase it.
export type ProductId = 'assistant' | 'code' | 'design' | 'p' | 'forward';

export interface ProductManifest {
  productId: ProductId;
  displayName: string;
  primaryObject: string;
  workspaceType: string;
  navigation: readonly string[];
  artifactTypes: readonly string[];
  rendererMap: Readonly<Record<string, string>>;
  surfacedTools: readonly string[];
  composerCapabilities: readonly string[];
  defaultAgentPolicy: string;
  modelRoutingPolicy: string;
  featureFlags: readonly string[];
  telemetryNamespace: string;
  responsiveContract: string;
}

export const PRODUCT_IDS: readonly ProductId[];
export const MANIFESTS: Readonly<Record<ProductId, ProductManifest>>;
export function getManifest(productId: string): ProductManifest;
export function listManifests(): ProductManifest[];
export function manifestSurfacesTool(productId: string, toolId: string): boolean;
export function manifestRendererFor(productId: string, artifactType: string): string | null;
