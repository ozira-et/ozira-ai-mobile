'use strict';

// Shared environment model (spec section 40). No backend URL is hard-coded
// here -- each surface resolves its own config object and passes it in.
// This module only defines the three allowed environment names and a small
// resolution helper so "development"/"staging"/"production" mean the same
// thing everywhere.

const ENVIRONMENTS = Object.freeze(['development', 'staging', 'production']);

/**
 * @param {object} params
 * @param {string} [params.explicit] - an explicit override (env var / build config)
 * @param {string} [params.hostname] - e.g. window.location.hostname on Web
 */
function resolveEnvironment({ explicit, hostname } = {}) {
  if (explicit && ENVIRONMENTS.includes(explicit)) return explicit;
  if (typeof hostname === 'string') {
    if (hostname === 'localhost' || hostname === '127.0.0.1' || hostname.endsWith('.local')) return 'development';
    if (hostname.includes('staging')) return 'staging';
  }
  return 'production';
}

/**
 * Selects the entry matching the resolved environment from a config map.
 * Throws rather than silently falling back to production -- a missing
 * staging config should fail loudly during development, not quietly reach
 * production values.
 */
function selectConfig(configByEnvironment, environment) {
  const entry = configByEnvironment[environment];
  if (!entry) {
    throw new Error(`No app config defined for environment "${environment}"`);
  }
  return entry;
}

module.exports = { ENVIRONMENTS, resolveEnvironment, selectConfig };
