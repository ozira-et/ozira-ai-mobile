'use strict';

// Shared design tokens (spec section 26-27). Brand color VALUES are copied
// verbatim from the already-shipping ozira-mobile/src/theme.js -- OZIRA's
// established brand is preserved, not redesigned, per section 27.
//
// Framework-agnostic on purpose: plain numbers/hex strings. Web/Desktop map
// these to CSS custom properties; Mobile maps them into a React Native
// StyleSheet-compatible object (as ozira-mobile/src/theme.js already does).
// This module does not import React, React Native, or any CSS-in-JS library.

const brand = Object.freeze({
  primary: '#E11D48',
  secondary: '#FF3D71',
  accent: '#7C3AED',
  success: '#1FA855',
  gold: '#C8930A',
  danger: '#E5484D',
  white: '#FFFFFF',
});

const darkColors = Object.freeze({
  ...brand,
  bg: '#0B0B12',
  surface: '#161622',
  card: '#1C1C28',
  cardAlt: '#22222F',
  text: '#F2F2F7',
  muted: '#8A8A99',
  border: '#2A2A38',
});

const lightColors = Object.freeze({
  ...brand,
  bg: '#F6F7FB',
  surface: '#FFFFFF',
  card: '#EFEFF5',
  cardAlt: '#E7E7EF',
  text: '#15151C',
  muted: '#6A6A78',
  border: '#E3E3EB',
});

function getPalette(mode) {
  return mode === 'light' ? lightColors : darkColors;
}

// Spacing/radius scales are identical to ozira-mobile/src/theme.js.
const spacing = Object.freeze({ xs: 4, sm: 8, md: 12, lg: 16, xl: 24, xxl: 32 });
const radius = Object.freeze({ sm: 8, md: 12, lg: 16, xl: 22, pill: 999 });

// New tokens: mobile's theme.js does not define a type scale or elevation,
// because native screens style text ad hoc. Web/Desktop need them; values
// are chosen to be consistent with the existing brand, not a redesign.
const typography = Object.freeze({
  fontFamily: {
    regular: 'Poppins_400Regular, Poppins, system-ui, sans-serif',
    medium: 'Poppins_500Medium, Poppins, system-ui, sans-serif',
    semibold: 'Poppins_600SemiBold, Poppins, system-ui, sans-serif',
    bold: 'Poppins_700Bold, Poppins, system-ui, sans-serif',
  },
  scale: Object.freeze({
    xs: 12, sm: 14, md: 16, lg: 18, xl: 22, xxl: 28, display: 36,
  }),
});

const elevation = Object.freeze({
  none: 'none',
  sm: '0 1px 2px rgba(0,0,0,0.24)',
  md: '0 4px 12px rgba(0,0,0,0.28)',
  lg: '0 12px 32px rgba(0,0,0,0.32)',
});

/** Flatten a palette + the shared scales into CSS custom-property pairs. */
function toCssVariables(mode) {
  const palette = getPalette(mode);
  const out = {};
  for (const [key, value] of Object.entries(palette)) out[`--ozira-color-${kebab(key)}`] = value;
  for (const [key, value] of Object.entries(spacing)) out[`--ozira-space-${key}`] = `${value}px`;
  for (const [key, value] of Object.entries(radius)) out[`--ozira-radius-${key}`] = value === 999 ? '999px' : `${value}px`;
  for (const [key, value] of Object.entries(typography.scale)) out[`--ozira-font-size-${key}`] = `${value}px`;
  return out;
}

function kebab(str) {
  return str.replace(/([a-z0-9])([A-Z])/g, '$1-$2').toLowerCase();
}

module.exports = {
  brand,
  darkColors,
  lightColors,
  getPalette,
  spacing,
  radius,
  typography,
  elevation,
  toCssVariables,
};
