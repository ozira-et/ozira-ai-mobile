'use strict';

// One typed OZIRA API client, shared by every surface (spec section 19-20).
//
//   UI -> shared app/service hook -> this client -> ozira-ai
//
// Deliberately platform-agnostic: `fetchImpl` and `getToken` are injected,
// so this module contains no DOM, no React Native, no Electron code. Each
// surface supplies its own transport (global fetch on Web/Desktop/Node 18+,
// or a wrapped fetch on older RN) and its own token source (Supabase session
// on every surface today, but the client does not assume that).

const { classifyHttpError, classifyTransportError, AppError } = require('./errors');

const DEFAULT_TIMEOUT_MS = 15000;

function randomCorrelationId() {
  return 'req_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 10);
}

/**
 * @param {object} options
 * @param {string} options.baseUrl
 * @param {() => (string|null|Promise<string|null>)} options.getToken
 * @param {typeof fetch} [options.fetchImpl]
 * @param {() => string} [options.correlationIdFactory]
 * @param {number} [options.timeoutMs]
 * @param {Record<string,string>} [options.defaultHeaders] - platform identity headers (e.g. x-ozira-platform)
 */
function createApiClient(options) {
  const opts = options || {};
  if (!opts.baseUrl) throw new AppError('VALIDATION', 'createApiClient requires a baseUrl');
  const fetchImpl = opts.fetchImpl || (typeof fetch !== 'undefined' ? fetch : null);
  if (!fetchImpl) throw new AppError('VALIDATION', 'createApiClient requires a fetchImpl on this platform');
  const getToken = opts.getToken || (() => null);
  const refreshToken = opts.refreshToken || null;
  const correlationIdFactory = opts.correlationIdFactory || randomCorrelationId;
  const timeoutMs = opts.timeoutMs || DEFAULT_TIMEOUT_MS;
  const defaultHeaders = opts.defaultHeaders || {};

  /**
   * @param {string} path - e.g. '/api/intelligence/whoami'
   * @param {object} [init]
   * @param {'GET'|'POST'|'PUT'|'DELETE'} [init.method]
   * @param {object} [init.body]
   * @param {boolean} [init.retry] - only ever applies to GET; see note below
   */
  async function call(path, init) {
    const cfg = init || {};
    const method = cfg.method || (cfg.body ? 'POST' : 'GET');
    // NEVER retry a non-GET automatically: section 36 forbids retrying a
    // consequential write without proven idempotency, and this client has
    // no per-endpoint idempotency information to make that judgment safely.
    const allowRetry = Boolean(cfg.retry) && method === 'GET';
    const attempts = (allowRetry ? 2 : 1) + (refreshToken ? 1 : 0);
    let authRefreshAttempted = false;

    let lastError = null;
    for (let attempt = 0; attempt < attempts; attempt += 1) {
      const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
      const requestTimeoutMs = Number.isFinite(cfg.timeoutMs) && cfg.timeoutMs > 0 ? cfg.timeoutMs : timeoutMs;
      let rejectDeadline;
      const deadline = new Promise((_, reject) => { rejectDeadline = reject; });
      const timer = setTimeout(() => {
        if (controller) controller.abort();
        const timeoutError = new Error('Request timed out.');
        timeoutError.name = 'AbortError';
        timeoutError.code = 'ABORT_ERR';
        rejectDeadline(timeoutError);
      }, requestTimeoutMs);
      try {
        // Bound token acquisition and response decoding too. Supabase auth
        // can wait on an internal lock/network operation; aborting fetch alone
        // cannot unblock that await and leaves the composer permanently busy.
        const token = await Promise.race([Promise.resolve().then(() => getToken()), deadline]);
        const correlationId = correlationIdFactory();
        const response = await Promise.race([fetchImpl(baseUrlJoin(opts.baseUrl, path), {
          method,
          headers: {
            'content-type': 'application/json',
            'x-request-id': correlationId,
            ...defaultHeaders,
            ...(token ? { authorization: `Bearer ${token}` } : {}),
          },
          body: cfg.body !== undefined ? JSON.stringify(cfg.body) : undefined,
          signal: controller ? controller.signal : undefined,
        }), deadline]);

        let payload = null;
        try { payload = await Promise.race([response.json(), deadline]); } catch (error) {
          // A deadline is a failed request, not a successful empty response.
          if (error && error.name === 'AbortError') throw error;
          payload = null;
        }

        if (!response.ok) {
          const error = classifyHttpError(response.status, payload);
          // A Supabase access token can expire while the shell remains open.
          // Refresh once, then replay the rejected request with the new token.
          // This is not a general write retry: the server rejected the first
          // request with 401, so no consequential operation was accepted.
          if (response.status === 401 && !authRefreshAttempted && refreshToken) {
            authRefreshAttempted = true;
            try {
              const refreshed = await Promise.race([Promise.resolve().then(() => refreshToken()), deadline]);
              if (refreshed) continue;
            } catch (_) { /* preserve the original unauthenticated error */ }
          }
          // Only a transient class is worth a second attempt at all.
          if (allowRetry && attempt === 0 && error.code === 'TEMPORARY_SERVICE_FAILURE') {
            lastError = error;
            continue;
          }
          throw error;
        }
        return { data: payload, correlationId, status: response.status };
      } catch (error) {
        if (error instanceof AppError) throw error;
        const classified = classifyTransportError(error);
        if (allowRetry && attempt === 0 && classified.code === 'TIMEOUT') {
          lastError = classified;
          continue;
        }
        throw classified;
      } finally {
        // Also runs before retry/refresh continues and before a successful return.
        clearTimeout(timer);
      }
    }
    throw lastError || new AppError('UNKNOWN', 'Request failed with no further detail.');
  }

  return { call };
}

function baseUrlJoin(baseUrl, path) {
  const base = baseUrl.replace(/\/+$/, '');
  const suffix = path.startsWith('/') ? path : `/${path}`;
  return base + suffix;
}

module.exports = { createApiClient };
