'use strict';

// Shared feature-flag abstraction (spec section 37). Deliberately tiny: a
// synchronous evaluator over a flag map already fetched/embedded by the
// caller. This module does not fetch flags itself -- remote flag delivery
// is a backend integration for a later phase, not this foundation.

const PLATFORMS = Object.freeze(['web', 'ios', 'android', 'desktop']);

/**
 * @param {object} options
 * @param {Record<string, boolean|{default:boolean, platforms?:string[], tenants?:string[], users?:string[]}>} options.flags
 * @param {'web'|'ios'|'android'|'desktop'} options.platform
 * @param {'development'|'staging'|'production'} options.environment
 */
function createFeatureFlagClient(options) {
  const opts = options || {};
  const flags = opts.flags || {};
  const platform = opts.platform;
  if (!PLATFORMS.includes(platform)) {
    throw new Error(`createFeatureFlagClient requires a known platform, got: ${platform}`);
  }
  const environment = opts.environment || 'development';

  function isEnabled(name, context) {
    const entry = flags[name];
    if (entry === undefined) return false; // unknown flag = off, never throws
    if (typeof entry === 'boolean') return entry;

    if (Array.isArray(entry.platforms) && !entry.platforms.includes(platform)) return false;
    const ctx = context || {};
    if (Array.isArray(entry.tenants) && entry.tenants.length) {
      if (!ctx.tenantId || !entry.tenants.includes(ctx.tenantId)) return false;
    }
    if (Array.isArray(entry.users) && entry.users.length) {
      if (!ctx.userId || !entry.users.includes(ctx.userId)) return false;
    }
    if (Array.isArray(entry.environments) && entry.environments.length) {
      if (!entry.environments.includes(environment)) return false;
    }
    return Boolean(entry.default);
  }

  return { isEnabled, platform, environment };
}

module.exports = { PLATFORMS, createFeatureFlagClient };
